import puppeteer from "puppeteer-core";

const browser = await puppeteer.launch({
  executablePath: "/usr/bin/chromium",
  headless: "new",
  args: ["--no-sandbox", "--disable-gpu", "--window-size=1440,810"],
});
const page = await browser.newPage();
await page.setViewport({ width: 1440, height: 810, deviceScaleFactor: 1 });

async function shot(t, name) {
  await page.goto(`http://127.0.0.1:4173/?t=${t}&pause=1`, { waitUntil: "domcontentloaded", timeout: 30000 });
  await page.waitForSelector("canvas[data-ready='1']", { timeout: 30000 });
  await page.evaluate((time) => {
    const g = window.__gatsby;
    if (!g) throw new Error("no engine");
    g.seek(time);
    g.pause();
  }, t);
  // two frames so the seek is painted
  await page.evaluate(() => new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r))));
  await new Promise((r) => setTimeout(r, 250));
  await page.screenshot({ path: `/home/user/sandbox/public/shots/${name}.png` });
  const clock = await page.evaluate(() => document.querySelector(".clock")?.textContent);
  console.log(name, "clock", clock);
}

await shot(1.1, "open");
await shot(5.8, "lift");
await shot(12.5, "rise");
await shot(16.5, "city");
await shot(25.2, "quote");
await browser.close();
