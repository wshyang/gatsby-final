import { useEffect, useRef, useState } from "react";
import "@fontsource/cormorant-garamond/500.css";
import "@fontsource/cormorant-garamond/500-italic.css";
import "@fontsource/cormorant-garamond/600.css";
import "@fontsource/special-elite/400.css";
import { GatsbyEngine } from "./gatsby/engine";
import { PHASES, TIMELINE } from "./gatsby/config";

function formatTime(t: number) {
  const m = Math.floor(t / 60);
  const s = t - m * 60;
  return `${m}:${s.toFixed(1).padStart(4, "0")}`;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rangeRef = useRef<HTMLInputElement>(null);
  const timeRef = useRef<HTMLSpanElement>(null);
  const phaseLabelRef = useRef<HTMLParagraphElement>(null);
  const phaseTextRef = useRef<HTMLParagraphElement>(null);
  const quoteRef = useRef<HTMLParagraphElement>(null);
  const engineRef = useRef<GatsbyEngine | null>(null);
  const scrubbing = useRef(false);
  const resume = useRef(true);

  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);
  const [playing, setPlaying] = useState(true);
  const [mark, setMark] = useState(false);
  const [glyphs, setGlyphs] = useState(0);
  const [members, setMembers] = useState(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let dead = false;
    let engine: GatsbyEngine | null = null;

    GatsbyEngine.create(canvas)
      .then((e) => {
        if (dead) {
          e.dispose();
          return;
        }
        engine = e;
        engineRef.current = e;
        setGlyphs(e.info.glyphs);
        setMembers(e.info.members);
        const params = new URLSearchParams(window.location.search);
        const start = Number(params.get("t"));
        if (Number.isFinite(start) && start > 0) e.seek(start);
        if (params.get("pause") === "1") {
          e.pause();
          setPlaying(false);
        }
        (window as unknown as { __gatsby?: GatsbyEngine }).__gatsby = e;
        canvas.setAttribute("data-ready", "1");
        setReady(true);
        e.onTick = (t) => {
          if (!scrubbing.current && rangeRef.current) rangeRef.current.value = String(t);
          if (timeRef.current) timeRef.current.textContent = formatTime(t);
          const ph = e.phase();
          if (phaseLabelRef.current) phaseLabelRef.current.textContent = ph.label;
          if (phaseTextRef.current) phaseTextRef.current.textContent = ph.text;
          if (quoteRef.current) {
            const show = t > 23.2 && t < 30.6;
            quoteRef.current.style.opacity = show ? "1" : "0";
          }
        };
      })
      .catch(() => {
        if (!dead) setFailed(true);
      });

    const onKey = (ev: KeyboardEvent) => {
      const eng = engineRef.current;
      if (!eng) return;
      if (ev.code === "Space") {
        ev.preventDefault();
        eng.toggle();
        setPlaying(eng.playing);
      } else if (ev.key === "r" || ev.key === "R") {
        eng.seek(0);
        eng.play();
        setPlaying(true);
      } else if (ev.key === "m" || ev.key === "M") {
        const next = !eng.mark;
        eng.setMark(next);
        setMark(next);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => {
      dead = true;
      window.removeEventListener("keydown", onKey);
      engine?.dispose();
      engineRef.current = null;
    };
  }, []);

  const seek = (t: number) => engineRef.current?.seek(t);

  return (
    <div className="stage">
      <canvas ref={canvasRef} aria-label="Typewriter letters lift off the page and assemble into a quote above New York" />

      <header className="topbar">
        <div className="brand">
          <span className="diamond" aria-hidden />
          <span>West Egg</span>
          <span className="dot">·</span>
          <span>A WebGL study</span>
        </div>
        <h1>
          The Great Gatsby
          <em>particle typography</em>
        </h1>
        <div className="meta">
          <span>1925</span>
          <span className="rule" />
          <span>2013</span>
        </div>
      </header>

      <footer className="dock">
        <div className="dock-copy">
          <p ref={phaseLabelRef} className="phase">
            I · The Source
          </p>
          <p ref={phaseTextRef} className="blurb">
            Every character is ink sitting on a real sheet of paper.
          </p>
          <p ref={quoteRef} className="caption">
            After Gatsby&apos;s death, New York was haunted for me...
          </p>
        </div>

        <div className="transport">
          <button
            className="play"
            aria-label={playing ? "Pause" : "Play"}
            onClick={() => {
              const eng = engineRef.current;
              if (!eng) return;
              eng.toggle();
              setPlaying(eng.playing);
            }}
          >
            {playing ? (
              <svg viewBox="0 0 24 24" aria-hidden>
                <rect x="6" y="5" width="4" height="14" />
                <rect x="14" y="5" width="4" height="14" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" aria-hidden>
                <path d="M8 5.5v13l11-6.5z" />
              </svg>
            )}
          </button>

          <div className="scrub">
            <div className="ticks" aria-hidden>
              {PHASES.map((p) => (
                <button
                  key={p.id}
                  className="tick"
                  style={{ left: `${(p.at / TIMELINE.duration) * 100}%` }}
                  title={p.label}
                  onClick={() => {
                    seek(p.at);
                    engineRef.current?.play();
                    setPlaying(true);
                  }}
                />
              ))}
            </div>
            <input
              ref={rangeRef}
              type="range"
              min={0}
              max={TIMELINE.duration}
              step={0.01}
              defaultValue={0}
              aria-label="Timeline"
              onPointerDown={() => {
                scrubbing.current = true;
                resume.current = engineRef.current?.playing ?? true;
                engineRef.current?.pause();
                setPlaying(false);
              }}
              onPointerUp={() => {
                scrubbing.current = false;
                if (resume.current) {
                  engineRef.current?.play();
                  setPlaying(true);
                }
              }}
              onChange={(e) => seek(parseFloat(e.target.value))}
            />
          </div>

          <span ref={timeRef} className="clock">
            0:00.0
          </span>

          <button
            className="ghost"
            onClick={() => {
              engineRef.current?.seek(0);
              engineRef.current?.play();
              setPlaying(true);
            }}
          >
            Replay
          </button>
          <button
            className={`ghost ${mark ? "on" : ""}`}
            aria-pressed={mark}
            onClick={() => {
              const next = !mark;
              setMark(next);
              engineRef.current?.setMark(next);
            }}
          >
            Trace origins
          </button>
        </div>

        <div className="ledger">
          <span>
            {glyphs.toLocaleString()} glyphs born on paper
          </span>
          <span className="dot">·</span>
          <span>{members} reserved for the quote, matched by character</span>
          <span className="dot">·</span>
          <span className="keys">space play · R restart · M trace</span>
        </div>
      </footer>

      {!ready && !failed && (
        <div className="loader">
          <p className="loader-kicker">Setting the type</p>
          <h2>
            After Gatsby&apos;s death<span className="cursor">|</span>
          </h2>
          <p className="loader-sub">letters leaving the page</p>
        </div>
      )}
      {failed && (
        <div className="loader">
          <h2>This sequence needs WebGL.</h2>
        </div>
      )}
    </div>
  );
}
