import "@fontsource/special-elite/400.css";
import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import cityUrl from "../assets/city.jpg";
import deskUrl from "../assets/desk.jpg";
import lacquerUrl from "../assets/lacquer.jpg";
import { buildGlyphAtlas } from "./atlas";
import { poseAt, setCloseAnchor, vfovFor } from "./camera";
import { City } from "./city";
import { PALETTE, TIMELINE, phaseAt } from "./config";
import { buildDesk, makePagePoses, paperTexture } from "./desk";
import { createGlyphMesh } from "./glyphs";
import { buildGlyphBuffers } from "./mapping";
import { Typewriter } from "./typewriter";

/**
 * Render graph
 * ────────────
 *   cityScene  (far camera)  → rtCity → half-res separable blur → rtBlur
 *   deskScene  (near camera) → rtDesk
 *   composite  city focus-pull + desk dissolve          → rtComp
 *   glyphs     instanced, drawn over the composite      → rtComp
 *   grade      warm desk → teal city, vignette, grain   → screen
 *
 * Two cameras share one pose. The desk lives at metre scale (near 0.03 m);
 * the city lives hundreds of metres away (near 4 m). A single frustum cannot
 * hold both without chewing the typewriter's depth. Glyphs use the near
 * camera: the sea is placed inside that frustum, in front of the aerial pose.
 */

const quadVert = /* glsl */ `
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = vec4(position.xy, 0.0, 1.0);
}
`;

const blurFrag = /* glsl */ `
uniform sampler2D tDiffuse;
uniform vec2 uDir;
uniform float uRadius;
varying vec2 vUv;
void main() {
  vec2 texel = uDir * uRadius;
  vec3 c = texture2D(tDiffuse, vUv).rgb * 0.227027;
  c += texture2D(tDiffuse, vUv + texel * 1.384615).rgb * 0.316216;
  c += texture2D(tDiffuse, vUv - texel * 1.384615).rgb * 0.316216;
  c += texture2D(tDiffuse, vUv + texel * 3.230769).rgb * 0.070270;
  c += texture2D(tDiffuse, vUv - texel * 3.230769).rgb * 0.070270;
  gl_FragColor = vec4(c, 1.0);
}
`;

const compFrag = /* glsl */ `
uniform sampler2D tCity;
uniform sampler2D tBlur;
uniform sampler2D tDesk;
uniform float uFocus;
uniform float uCity;
uniform float uDesk;
uniform vec3 uDeskBg;
varying vec2 vUv;
void main() {
  vec3 sharp = texture2D(tCity, vUv).rgb;
  vec3 soft = texture2D(tBlur, vUv).rgb;
  vec3 city = mix(soft, sharp, uFocus);
  vec4 desk = texture2D(tDesk, vUv);
  vec3 col = mix(uDeskBg, city, uCity);
  float cover = desk.a * uDesk;
  // Desk is metre-scale and physically lit; lift it so the page reads without blowing the city.
  col = mix(col, desk.rgb * 1.35, cover);
  gl_FragColor = vec4(col, 1.0);
}
`;

const gradeFrag = /* glsl */ `
uniform sampler2D tDiffuse;
uniform float uTime;
uniform float uCity;
uniform float uAlpha;
varying vec2 vUv;
vec3 aces(vec3 x) {
  const float a = 2.51, b = 0.03, c = 2.43, d = 0.59, e = 0.14;
  return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}
float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
void main() {
  vec3 col = texture2D(tDiffuse, vUv).rgb;
  col *= mix(1.05, 1.12, uCity);
  float l = dot(col, vec3(0.2126, 0.7152, 0.0722));
  vec3 teal = vec3(0.55, 0.78, 0.82);
  vec3 warm = vec3(1.05, 0.94, 0.82);
  vec3 grade = mix(warm, teal, uCity);
  col = mix(col, col * mix(teal, warm, smoothstep(0.08, 0.55, l)), 0.22 * uCity);
  col = mix(col, col * grade, 0.18);
  col = aces(col);
  float vig = smoothstep(1.15, 0.35, length((vUv - 0.5) * vec2(1.15, 1.35)));
  col *= mix(0.62, 1.0, vig);
  float g = hash(vUv * vec2(1920.0, 1080.0) + fract(uTime) * 17.0) - 0.5;
  col += g * 0.04;
  col = pow(max(col, 0.0), vec3(1.0 / 2.2));
  gl_FragColor = vec4(col * uAlpha, 1.0);
}
`;

function smoother(a: number, b: number, x: number) {
  const t = THREE.MathUtils.clamp((x - a) / (b - a), 0, 1);
  return t * t * t * (t * (t * 6 - 15) + 10);
}

function makeRT(w: number, h: number) {
  const rt = new THREE.WebGLRenderTarget(w, h, {
    type: THREE.HalfFloatType,
    format: THREE.RGBAFormat,
    colorSpace: THREE.LinearSRGBColorSpace,
    depthBuffer: true,
    magFilter: THREE.LinearFilter,
    minFilter: THREE.LinearFilter,
  });
  return rt;
}

export interface EngineInfo {
  glyphs: number;
  members: number;
}

export class GatsbyEngine {
  readonly renderer: THREE.WebGLRenderer;
  readonly info: EngineInfo;
  readonly duration = TIMELINE.duration;
  time = 0;
  playing = true;
  mark = false;
  onTick?: (t: number) => void;

  private deskScene = new THREE.Scene();
  private glyphScene = new THREE.Scene();
  private camNear = new THREE.PerspectiveCamera(36, 1, 0.035, 55);
  private camFar = new THREE.PerspectiveCamera(36, 1, 4, 9000);
  private city: City;
  private tw: Typewriter;
  private glyphs: ReturnType<typeof createGlyphMesh>;
  private rtCity!: THREE.WebGLRenderTarget;
  private rtDesk!: THREE.WebGLRenderTarget;
  private rtBlurA!: THREE.WebGLRenderTarget;
  private rtBlurB!: THREE.WebGLRenderTarget;
  private rtComp!: THREE.WebGLRenderTarget;
  private quadScene = new THREE.Scene();
  private quadCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  private quad: THREE.Mesh;
  private blurMat: THREE.ShaderMaterial;
  private compMat: THREE.ShaderMaterial;
  private gradeMat: THREE.ShaderMaterial;
  private raf = 0;
  private last = 0;
  private ro: ResizeObserver;
  private disposed = false;
  private pos = new THREE.Vector3();
  private quat = new THREE.Quaternion();

  static async create(canvas: HTMLCanvasElement) {
    await Promise.all([
      document.fonts.load('86px "Special Elite"'),
      document.fonts.load('30px "Special Elite"'),
      document.fonts.ready,
    ]);
    const loader = new THREE.TextureLoader();
    const [cityTex, deskTex, lacquerTex] = await Promise.all([
      loader.loadAsync(cityUrl),
      loader.loadAsync(deskUrl),
      loader.loadAsync(lacquerUrl),
    ]);
    return new GatsbyEngine(canvas, cityTex, deskTex, lacquerTex);
  }

  private constructor(
    private canvas: HTMLCanvasElement,
    cityTex: THREE.Texture,
    deskTex: THREE.Texture,
    lacquerTex: THREE.Texture,
  ) {
    const r = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false, powerPreference: "high-performance" });
    r.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    r.outputColorSpace = THREE.LinearSRGBColorSpace;
    r.toneMapping = THREE.NoToneMapping;
    r.shadowMap.enabled = true;
    r.shadowMap.type = THREE.PCFShadowMap;
    r.autoClear = false;
    this.renderer = r;

    const pmrem = new THREE.PMREMGenerator(r);
    this.deskScene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    this.deskScene.environmentIntensity = 1.15;
    pmrem.dispose();
    r.setRenderTarget(null);

    this.deskScene.background = null;
    this.deskScene.fog = new THREE.FogExp2(PALETTE.deskFog, 0.11);

    this.tw = new Typewriter(lacquerTex);
    this.tw.group.position.set(0, 0, 0);
    this.tw.group.rotation.y = 0.04;
    this.deskScene.add(this.tw.group);

    const pages = makePagePoses();
    const paper = paperTexture(11);
    this.tw.paperMaterial.map = paper;
    this.tw.paperMaterial.color.set(0xfff8ee);
    this.tw.paperMaterial.emissive = new THREE.Color(0x4a3b2a);
    this.tw.paperMaterial.emissiveIntensity = 0.28;
    this.tw.paperMaterial.needsUpdate = true;
    buildDesk(this.deskScene, deskTex, pages, this.tw.paperMaterial);

    const atlas = buildGlyphAtlas();
    const buffers = buildGlyphBuffers(pages, this.tw, atlas);
    this.info = { glyphs: buffers.count, members: buffers.members };
    this.glyphs = createGlyphMesh(atlas, buffers);
    this.glyphScene.add(this.glyphs.mesh);

    this.city = new City(cityTex);

    const focus = this.tw.focusPoint();
    setCloseAnchor(focus.world, focus.normal, new THREE.Vector3(0, 1, 0));

    this.blurMat = new THREE.ShaderMaterial({
      uniforms: {
        tDiffuse: { value: null },
        uDir: { value: new THREE.Vector2(1, 0) },
        uRadius: { value: 1 },
      },
      vertexShader: quadVert,
      fragmentShader: blurFrag,
      depthTest: false,
      depthWrite: false,
    });
    this.compMat = new THREE.ShaderMaterial({
      uniforms: {
        tCity: { value: null },
        tBlur: { value: null },
        tDesk: { value: null },
        uFocus: { value: 0 },
        uCity: { value: 0 },
        uDesk: { value: 1 },
        uDeskBg: { value: new THREE.Color(PALETTE.warmBg) },
      },
      vertexShader: quadVert,
      fragmentShader: compFrag,
      depthTest: false,
      depthWrite: false,
    });
    this.gradeMat = new THREE.ShaderMaterial({
      uniforms: {
        tDiffuse: { value: null },
        uTime: { value: 0 },
        uCity: { value: 0 },
        uAlpha: { value: 1 },
      },
      vertexShader: quadVert,
      fragmentShader: gradeFrag,
      depthTest: false,
      depthWrite: false,
    });
    this.quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), this.blurMat);
    this.quadScene.add(this.quad);

    this.resize();
    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(canvas.parentElement ?? canvas);
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  private resize = () => {
    const parent = this.canvas.parentElement;
    const w = Math.max(2, parent?.clientWidth ?? window.innerWidth);
    const h = Math.max(2, parent?.clientHeight ?? window.innerHeight);
    const pr = this.renderer.getPixelRatio();
    this.renderer.setSize(w, h, false);
    const aspect = w / h;
    const fov = vfovFor(aspect);
    for (const cam of [this.camNear, this.camFar]) {
      cam.aspect = aspect;
      cam.fov = fov;
      cam.updateProjectionMatrix();
    }
    const W = Math.floor(w * pr);
    const H = Math.floor(h * pr);
    this.rtCity?.dispose();
    this.rtDesk?.dispose();
    this.rtBlurA?.dispose();
    this.rtBlurB?.dispose();
    this.rtComp?.dispose();
    this.rtCity = makeRT(W, H);
    this.rtDesk = makeRT(W, H);
    this.rtComp = makeRT(W, H);
    this.rtBlurA = makeRT(Math.max(2, W >> 1), Math.max(2, H >> 1));
    this.rtBlurB = makeRT(Math.max(2, W >> 1), Math.max(2, H >> 1));
  };

  private blit(material: THREE.ShaderMaterial, target: THREE.WebGLRenderTarget | null) {
    this.quad.material = material;
    this.renderer.setRenderTarget(target);
    this.renderer.clear(true, true, true);
    this.renderer.render(this.quadScene, this.quadCam);
  }

  private frame() {
    const t = this.time;
    poseAt(t, this.pos, this.quat);
    for (const cam of [this.camNear, this.camFar]) {
      cam.position.copy(this.pos);
      cam.quaternion.copy(this.quat);
      cam.updateMatrixWorld();
    }

    this.tw.update(t);
    this.glyphs.uniforms.uTime.value = t;
    this.glyphs.uniforms.uCarriageX.value = this.tw.carriageX(t);
    this.glyphs.uniforms.uAxis.value.copy(this.tw.carriageAxis());
    this.glyphs.uniforms.uMark.value = this.mark ? 1 : 0;
    const fadeIn = smoother(TIMELINE.fadeIn[0], TIMELINE.fadeIn[1], t);
    const fadeOut = 1 - smoother(TIMELINE.fadeOut[0], TIMELINE.fadeOut[1], t);
    this.glyphs.uniforms.uFade.value = fadeIn * fadeOut;

    this.city.update(t, this.camFar);

    const cityAmt = smoother(TIMELINE.cityFade[0], TIMELINE.cityFade[1], t);
    const deskAmt = 1 - smoother(TIMELINE.deskFade[0], TIMELINE.deskFade[1], t);
    const focus = smoother(TIMELINE.cityFocus[0], TIMELINE.cityFocus[1], t);

    // city
    this.renderer.setRenderTarget(this.rtCity);
    this.renderer.setClearColor(this.city.fog, 1);
    this.renderer.clear(true, true, true);
    this.renderer.render(this.city.scene, this.camFar);

    // separable blur, two iterations, half res — the rack-focus source
    const bw = this.rtBlurA.width;
    const bh = this.rtBlurA.height;
    const radius = THREE.MathUtils.lerp(5.5, 0.35, focus);
    this.blurMat.uniforms.uRadius.value = radius / bw;
    this.blurMat.uniforms.tDiffuse.value = this.rtCity.texture;
    (this.blurMat.uniforms.uDir.value as THREE.Vector2).set(1, 0);
    this.blit(this.blurMat, this.rtBlurA);
    this.blurMat.uniforms.tDiffuse.value = this.rtBlurA.texture;
    this.blurMat.uniforms.uRadius.value = radius / bh;
    (this.blurMat.uniforms.uDir.value as THREE.Vector2).set(0, 1);
    this.blit(this.blurMat, this.rtBlurB);
    // second pass for a softer opening
    this.blurMat.uniforms.tDiffuse.value = this.rtBlurB.texture;
    this.blurMat.uniforms.uRadius.value = (radius * 0.65) / bw;
    (this.blurMat.uniforms.uDir.value as THREE.Vector2).set(1, 0);
    this.blit(this.blurMat, this.rtBlurA);
    this.blurMat.uniforms.tDiffuse.value = this.rtBlurA.texture;
    this.blurMat.uniforms.uRadius.value = (radius * 0.65) / bh;
    (this.blurMat.uniforms.uDir.value as THREE.Vector2).set(0, 1);
    this.blit(this.blurMat, this.rtBlurB);

    // desk
    this.renderer.setRenderTarget(this.rtDesk);
    this.renderer.setClearColor(0x000000, 0);
    this.renderer.clear(true, true, true);
    this.renderer.render(this.deskScene, this.camNear);

    // composite
    this.compMat.uniforms.tCity.value = this.rtCity.texture;
    this.compMat.uniforms.tBlur.value = this.rtBlurB.texture;
    this.compMat.uniforms.tDesk.value = this.rtDesk.texture;
    this.compMat.uniforms.uFocus.value = focus;
    this.compMat.uniforms.uCity.value = cityAmt;
    this.compMat.uniforms.uDesk.value = deskAmt;
    this.blit(this.compMat, this.rtComp);

    // glyphs over the composite
    this.renderer.setRenderTarget(this.rtComp);
    this.renderer.clearDepth();
    this.renderer.render(this.glyphScene, this.camNear);

    // grade to screen
    this.gradeMat.uniforms.tDiffuse.value = this.rtComp.texture;
    this.gradeMat.uniforms.uTime.value = t;
    this.gradeMat.uniforms.uCity.value = cityAmt;
    this.gradeMat.uniforms.uAlpha.value = fadeIn * fadeOut;
    this.blit(this.gradeMat, null);
  }

  private loop = (now: number) => {
    if (this.disposed) return;
    const dt = Math.min(0.05, (now - this.last) / 1000 || 0);
    this.last = now;
    if (this.playing) {
      this.time += dt;
      if (this.time >= this.duration) this.time = 0;
    }
    this.frame();
    this.onTick?.(this.time);
    this.raf = requestAnimationFrame(this.loop);
  };

  play() {
    this.playing = true;
  }
  pause() {
    this.playing = false;
  }
  toggle() {
    this.playing = !this.playing;
  }
  seek(t: number) {
    this.time = THREE.MathUtils.clamp(t, 0, this.duration - 0.001);
    this.last = performance.now();
  }
  setMark(on: boolean) {
    this.mark = on;
  }
  phase() {
    return phaseAt(this.time);
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.ro.disconnect();
    this.renderer.dispose();
    this.rtCity?.dispose();
    this.rtDesk?.dispose();
    this.rtBlurA?.dispose();
    this.rtBlurB?.dispose();
    this.rtComp?.dispose();
  }
}
