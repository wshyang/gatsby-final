import * as THREE from "three";
import { TYPE } from "./config";
import { rng } from "./texts";

/**
 * Desk + scattered manuscript pages.
 *
 * A page is a rigid sheet. PagePose is the ONE transform used both to place
 * the paper mesh and to place every glyph printed on it, so a particle's
 * origin is, by construction, a point on that mesh.
 *
 * Page-local frame: origin at the page centre, +x along the typed line,
 * +y up the page, +z out of the paper. Desk top is y = 0.
 */

export interface PagePose {
  position: THREE.Vector3;
  quaternion: THREE.Quaternion;
  width: number;
  height: number;
  lines: number;
  /** Which passage to wrap onto this sheet. */
  passage: number;
}

/** Hand-placed so the pull-back reads the whole desk, none hidden under the machine. */
const LAYOUT: { x: number; z: number; yaw: number; lines: number; passage: number }[] = [
  { x: -0.48, z: 0.04, yaw: 0.2, lines: 15, passage: 0 },
  { x: 0.5, z: 0.0, yaw: -0.16, lines: 15, passage: 1 },
  { x: -0.32, z: 0.44, yaw: 0.55, lines: 14, passage: 2 },
  { x: 0.34, z: 0.46, yaw: -0.42, lines: 14, passage: 6 },
  { x: -0.44, z: -0.36, yaw: -0.08, lines: 13, passage: 9 },
  { x: 0.46, z: -0.34, yaw: 0.26, lines: 15, passage: 12 },
];

function flatQuat(yaw: number) {
  const q = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), -Math.PI / 2);
  q.premultiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), yaw));
  return q;
}

export function makePagePoses(): PagePose[] {
  return LAYOUT.map((p, i) => ({
    position: new THREE.Vector3(p.x, 0.0012 + i * 0.00035, p.z),
    quaternion: flatQuat(p.yaw),
    width: TYPE.pageW,
    height: TYPE.pageH,
    lines: p.lines,
    passage: p.passage,
  }));
}

/** Aged bond: fibres, foxing, a deckled rim. Blank — the glyphs ARE the typing. */
export function paperTexture(seed = 4): THREE.CanvasTexture {
  const w = 512;
  const h = 662;
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const g = c.getContext("2d")!;
  const r = rng(seed);
  g.fillStyle = "#f4ead6";
  g.fillRect(0, 0, w, h);
  for (let i = 0; i < 700; i++) {
    const x = r() * w;
    const y = r() * h;
    const rad = 6 + r() * 28;
    const grd = g.createRadialGradient(x, y, 0, x, y, rad);
    const a = 0.015 + r() * 0.04;
    grd.addColorStop(0, r() < 0.55 ? `rgba(150,120,80,${a})` : `rgba(255,252,240,${a})`);
    grd.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = grd;
    g.beginPath();
    g.arc(x, y, rad, 0, Math.PI * 2);
    g.fill();
  }
  g.strokeStyle = "rgba(90,70,40,0.05)";
  g.lineWidth = 0.6;
  for (let i = 0; i < 80; i++) {
    g.beginPath();
    const x = r() * w;
    const y = r() * h;
    g.moveTo(x, y);
    g.lineTo(x + (r() - 0.5) * 40, y + (r() - 0.5) * 8);
    g.stroke();
  }
  // deckle
  const edge = g.createLinearGradient(0, 0, 18, 0);
  edge.addColorStop(0, "rgba(80,60,30,0.35)");
  edge.addColorStop(1, "rgba(80,60,30,0)");
  g.fillStyle = edge;
  g.fillRect(0, 0, 18, h);
  g.save();
  g.translate(w, 0);
  g.scale(-1, 1);
  g.fillRect(0, 0, 18, h);
  g.restore();
  g.fillStyle = "rgba(70,50,25,0.18)";
  g.fillRect(0, 0, w, 10);
  g.fillRect(0, h - 12, w, 12);

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  return tex;
}

export function buildDesk(
  scene: THREE.Scene,
  woodMap: THREE.Texture,
  pages: PagePose[],
  paperMat: THREE.Material,
) {
  woodMap.colorSpace = THREE.SRGBColorSpace;
  woodMap.wrapS = woodMap.wrapT = THREE.RepeatWrapping;
  woodMap.repeat.set(2.2, 1.5);
  woodMap.anisotropy = 8;

  const top = new THREE.Mesh(
    new THREE.BoxGeometry(2.5, 0.055, 1.7),
    new THREE.MeshStandardMaterial({ map: woodMap, roughness: 0.55, metalness: 0.06, color: 0xffffff }),
  );
  top.position.set(0, -0.028, 0.02);
  top.receiveShadow = true;
  top.castShadow = true;
  scene.add(top);

  // oxblood blotter under the machine
  const blotter = new THREE.Mesh(
    new THREE.BoxGeometry(0.72, 0.004, 0.5),
    new THREE.MeshStandardMaterial({ color: 0x4a1c1a, roughness: 0.84, metalness: 0.05 }),
  );
  blotter.position.set(0.0, 0.002, 0.02);
  blotter.receiveShadow = true;
  scene.add(blotter);

  const paper = paperMat;
  for (const p of pages) {
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(p.width, p.height), paper);
    mesh.position.copy(p.position);
    mesh.quaternion.copy(p.quaternion);
    mesh.receiveShadow = true;
    mesh.castShadow = true;
    scene.add(mesh);
  }

  // lamp — the practical that lights the opening
  const brass = new THREE.MeshStandardMaterial({ color: 0xb8914a, metalness: 1, roughness: 0.32, envMapIntensity: 1.1 });
  const shadeMat = new THREE.MeshStandardMaterial({
    color: 0x2a2118,
    roughness: 0.7,
    metalness: 0.2,
    side: THREE.DoubleSide,
    emissive: 0x3a2a14,
    emissiveIntensity: 0.35,
  });
  const lamp = new THREE.Group();
  lamp.position.set(-0.72, 0, 0.18);
  const base = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.06, 0.012, 24), brass);
  base.position.y = 0.008;
  const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.42, 12), brass);
  stem.position.set(0.02, 0.22, -0.02);
  stem.rotation.z = 0.18;
  const shade = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.08, 24, 1, true), shadeMat);
  shade.position.set(0.07, 0.44, -0.05);
  shade.rotation.z = 0.35;
  lamp.add(base, stem, shade);
  base.castShadow = stem.castShadow = shade.castShadow = true;
  scene.add(lamp);

  // Intensities are physical (candela / lux). The close-up has to read the page.
  const spot = new THREE.SpotLight(0xffc98a, 280, 8, 0.7, 0.45, 1.4);
  spot.position.set(-0.55, 0.72, 0.28);
  spot.target.position.set(0.02, 0.12, -0.04);
  spot.castShadow = true;
  spot.shadow.mapSize.set(1024, 1024);
  spot.shadow.camera.near = 0.12;
  spot.shadow.camera.far = 3.2;
  spot.shadow.bias = -0.0008;
  scene.add(spot, spot.target);

  const bulb = new THREE.PointLight(0xffe0b0, 18, 2.4, 2);
  bulb.position.set(-0.48, 0.55, 0.16);
  scene.add(bulb);

  const pageLight = new THREE.PointLight(0xfff3df, 12, 1.4, 2);
  pageLight.position.set(0.08, 0.38, 0.16);
  scene.add(pageLight);

  scene.add(new THREE.AmbientLight(0xffe6cc, 0.72));
  scene.add(new THREE.HemisphereLight(0xfff0dc, 0x3a2a1c, 0.55));
  const fill = new THREE.DirectionalLight(0xfff6ea, 3.4);
  fill.position.set(0.6, 1.4, 0.9);
  scene.add(fill);
  const rim = new THREE.DirectionalLight(0xffe1b0, 1.6);
  rim.position.set(-0.5, 0.9, -0.8);
  scene.add(rim);

  // ink bottle
  const bottle = new THREE.Group();
  bottle.position.set(0.42, 0, 0.22);
  const glass = new THREE.Mesh(
    new THREE.CylinderGeometry(0.016, 0.018, 0.055, 16),
    new THREE.MeshPhysicalMaterial({ color: 0x1a120e, roughness: 0.25, metalness: 0.1, clearcoat: 0.6, transmission: 0.15 }),
  );
  glass.position.y = 0.03;
  const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.012, 12), brass);
  cap.position.y = 0.062;
  bottle.add(glass, cap);
  glass.castShadow = true;
  scene.add(bottle);

  return { spot, bulb };
}
