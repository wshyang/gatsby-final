import * as THREE from "three";
import { WORLD } from "./config";
import { rng } from "./texts";

/**
 * 1920s Manhattan from a few hundred metres up, in teal fog.
 *
 *  reviews.txt wanted both things: a real 3D city (not only a photograph)
 *  and the blur-into-focus trick that made the photograph work. The painting
 *  is a camera-locked backdrop pinned to the horizon; the blocks, the river
 *  and the bridge are geometry in front of it. Fog is the seam.
 *
 *  Window lights are computed from world position, so they stay a constant
 *  size no matter how a tower is scaled — a stretched UV map was the thing
 *  that made earlier skylines look like toys.
 */

const G = WORLD.cityGround;
const FOG = new THREE.Color("#24383e");

const fogChunk = /* glsl */ `
uniform vec3 uFog;
uniform float uDensity;
vec3 applyFog(vec3 col, vec3 wp, vec3 cam) {
  float d = length(wp - cam);
  float f = 1.0 - exp(-pow(d * uDensity, 2.0));
  float mist = exp(-max(wp.y - ${G.toFixed(1)}, 0.0) / 42.0) * 0.5 * smoothstep(80.0, 700.0, d);
  f = clamp(f + (1.0 - f) * mist, 0.0, 1.0);
  return mix(col, uFog, f);
}
`;

const buildingVert = /* glsl */ `
varying vec3 vWorld;
varying vec3 vNormal;
varying vec3 vColor;
void main() {
  vColor = instanceColor;
  vec4 w = modelMatrix * instanceMatrix * vec4(position, 1.0);
  vWorld = w.xyz;
  vNormal = normalize(mat3(modelMatrix * instanceMatrix) * normal);
  gl_Position = projectionMatrix * viewMatrix * w;
}
`;

const buildingFrag = /* glsl */ `
precision highp float;
uniform vec3 uFog;
uniform float uDensity;
uniform float uTime;
varying vec3 vWorld;
varying vec3 vNormal;
varying vec3 vColor;
${fogChunk}
float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
void main() {
  vec3 n = normalize(vNormal);
  float fx = abs(n.x) > abs(n.z) ? vWorld.z : vWorld.x;
  vec2 cell = vec2(3.4, 4.8);
  vec2 id = floor(vec2(fx, vWorld.y) / cell);
  vec2 g = fract(vec2(fx, vWorld.y) / cell);
  float win = step(0.16, g.x) * step(g.x, 0.84) * step(0.2, g.y) * step(g.y, 0.78);
  float h = hash(id + vColor.xy * 19.0);
  float lit = step(0.46, h) * win;
  float flicker = 0.85 + 0.15 * sin(uTime * (1.5 + h * 3.0) + h * 20.0);
  vec3 wall = mix(vec3(0.045, 0.05, 0.055), vec3(0.09, 0.095, 0.1), vColor.r);
  vec3 glow = mix(vec3(1.0, 0.72, 0.36), vec3(0.62, 0.8, 0.78), step(0.88, h));
  vec3 col = mix(wall, glow * flicker, lit);
  col = mix(col, wall * 0.55, smoothstep(0.65, 0.95, n.y));
  // setback cornice
  float corn = smoothstep(0.02, 0.0, abs(fract(vWorld.y / 18.0) - 0.02));
  col += corn * 0.05;
  col = applyFog(col, vWorld, cameraPosition);
  gl_FragColor = vec4(col, 1.0);
}
`;

export class City {
  readonly scene = new THREE.Scene();
  private backdrop: THREE.Mesh;
  private water: THREE.ShaderMaterial;
  private buildings: THREE.ShaderMaterial;
  private boats: THREE.Object3D[] = [];
  readonly fog = FOG.clone();

  constructor(painting: THREE.Texture) {
    this.scene.background = this.fog.clone();
    this.scene.fog = null;
    this.buildGround();
    this.buildings = this.buildBuildings();
    this.buildBridge(-520);
    this.water = this.buildWater();
    this.buildBoats();
    this.backdrop = this.buildBackdrop(painting);

    const hemi = new THREE.HemisphereLight(0x9bb4be, 0x1a2428, 0.45);
    const moon = new THREE.DirectionalLight(0xd5e2ea, 0.55);
    moon.position.set(-400, 800, 200);
    this.scene.add(hemi, moon);
  }

  private buildGround() {
    const mat = new THREE.ShaderMaterial({
      uniforms: { uFog: { value: this.fog }, uDensity: { value: 0.00105 } },
      vertexShader: `varying vec3 vW; void main(){ vec4 w = modelMatrix*vec4(position,1.0); vW=w.xyz; gl_Position=projectionMatrix*viewMatrix*w; }`,
      fragmentShader: `${fogChunk}
        varying vec3 vW;
        void main() {
          vec2 g = abs(fract(vW.xz / vec2(220.0, 70.0)) - 0.5);
          float street = step(0.46, max(g.x, g.y * 1.4));
          vec3 col = mix(vec3(0.05, 0.055, 0.058), vec3(0.11, 0.12, 0.125), street);
          gl_FragColor = vec4(applyFog(col, vW, cameraPosition), 1.0);
        }`,
    });
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(6000, 6000), mat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.set(0, G, -900);
    this.scene.add(ground);
  }

  private buildBuildings() {
    const R = rng(1925);
    const dummy = new THREE.Object3D();
    const geo = new THREE.BoxGeometry(1, 1, 1);
    geo.translate(0, 0.5, 0);
    const mat = new THREE.ShaderMaterial({
      uniforms: { uFog: { value: this.fog }, uDensity: { value: 0.00105 }, uTime: { value: 0 } },
      vertexShader: buildingVert,
      fragmentShader: buildingFrag,
    });

    type B = { x: number; z: number; w: number; d: number; y: number; h: number; tint: number };
    const list: B[] = [];
    const cluster = (x: number, z: number, cx: number, cz: number, r: number) =>
      Math.exp(-((x - cx) ** 2 + (z - cz) ** 2) / (r * r));

    // River gap runs down the view, slightly left of centre.
    const river = (z: number) => -40 + 0.08 * (z + 400);

    for (let z = -80; z > -1900; z -= 46) {
      for (let x = -720; x < 780; x += 42) {
        const rx = river(z);
        if (Math.abs(x - rx) < 130) continue;
        if (R() < 0.18) continue;
        const w = 16 + R() * 22;
        const d = 18 + R() * 20;
        const downtown = cluster(x, z, 80, -1100, 420);
        const midtown = cluster(x, z, -40, -620, 260);
        let h = 12 + R() * 28;
        h += downtown * (70 + R() * 130);
        h += midtown * (30 + R() * 60);
        if (R() < 0.04) h += 40 + R() * 50;
        list.push({ x: x + (R() - 0.5) * 6, z, w, d, y: G, h, tint: R() });
        if (h > 90) {
          let y = G + h;
          let tw = w * 0.68;
          let td = d * 0.68;
          const tiers = 1 + Math.floor(R() * 3);
          for (let k = 0; k < tiers; k++) {
            const th = 12 + R() * 22;
            list.push({ x, z, w: tw, d: td, y, h: th, tint: R() });
            y += th;
            tw *= 0.7;
            td *= 0.7;
          }
          if (R() < 0.5) {
            list.push({ x, z, w: tw * 0.28, d: td * 0.28, y, h: 16 + R() * 36, tint: R() });
          }
        }
      }
    }

    const mesh = new THREE.InstancedMesh(geo, mat, list.length);
    const color = new THREE.Color();
    list.forEach((b, i) => {
      dummy.position.set(b.x, b.y, b.z);
      dummy.scale.set(b.w, b.h, b.d);
      dummy.rotation.set(0, 0, 0);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
      color.setRGB(b.tint, 0.2 + b.tint * 0.3, 0.25);
      mesh.setColorAt(i, color);
    });
    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    this.scene.add(mesh);
    return mat;
  }

  private buildBridge(z0: number) {
    const stone = new THREE.MeshStandardMaterial({ color: 0x6d7370, roughness: 0.82, metalness: 0.08 });
    const group = new THREE.Group();
    const deckY = G + 18;
    const towerH = 72;
    const half = 150;
    for (const tx of [-half * 0.55, half * 0.55]) {
      for (const lz of [-8, 8]) {
        const leg = new THREE.Mesh(new THREE.BoxGeometry(8, towerH, 6), stone);
        leg.position.set(tx, G + towerH / 2, z0 + lz);
        group.add(leg);
      }
      const cap = new THREE.Mesh(new THREE.BoxGeometry(12, 8, 22), stone);
      cap.position.set(tx, G + towerH - 4, z0);
      group.add(cap);
    }
    const deck = new THREE.Mesh(new THREE.BoxGeometry(half * 2, 2.4, 16), stone);
    deck.position.set(0, deckY, z0);
    group.add(deck);
    const pts: number[] = [];
    const t1 = -half * 0.55;
    const t2 = half * 0.55;
    const top = G + towerH - 2;
    const cable = (x: number) => {
      if (x < t1) return THREE.MathUtils.lerp(deckY + 4, top, (x + half) / (t1 + half));
      if (x > t2) return THREE.MathUtils.lerp(top, deckY + 4, (x - t2) / (half - t2));
      const u = (x - t1) / (t2 - t1);
      return top - (top - deckY - 6) * 4 * u * (1 - u);
    };
    for (const lz of [-7, 7]) {
      for (let x = -half; x < half; x += 8) {
        pts.push(x, cable(x), z0 + lz, x + 8, cable(x + 8), z0 + lz);
        if (x > t1 && x < t2) pts.push(x, cable(x), z0 + lz, x, deckY + 1, z0 + lz);
      }
    }
    const lg = new THREE.BufferGeometry();
    lg.setAttribute("position", new THREE.Float32BufferAttribute(pts, 3));
    group.add(new THREE.LineSegments(lg, new THREE.LineBasicMaterial({ color: 0x8a9294, transparent: true, opacity: 0.7 })));
    this.scene.add(group);
  }

  private buildWater() {
    const mat = new THREE.ShaderMaterial({
      uniforms: { uFog: { value: this.fog }, uDensity: { value: 0.00105 }, uTime: { value: 0 } },
      vertexShader: `varying vec3 vW; void main(){ vec4 w = modelMatrix*vec4(position,1.0); vW=w.xyz; gl_Position=projectionMatrix*viewMatrix*w; }`,
      fragmentShader: `${fogChunk}
        uniform float uTime; varying vec3 vW;
        void main() {
          vec3 v = normalize(cameraPosition - vW);
          float fres = pow(1.0 - max(v.y, 0.0), 3.0);
          float rip = sin(vW.z * 0.08 + uTime * 0.4) * sin(vW.x * 0.05 - uTime * 0.25);
          vec3 col = mix(vec3(0.05, 0.08, 0.09), vec3(0.28, 0.36, 0.38), clamp(fres * 0.7 + rip * 0.04, 0.0, 1.0));
          gl_FragColor = vec4(applyFog(col, vW, cameraPosition), 1.0);
        }`,
    });
    const water = new THREE.Mesh(new THREE.PlaneGeometry(260, 2200), mat);
    water.rotation.x = -Math.PI / 2;
    water.position.set(-20, G + 0.4, -1000);
    this.scene.add(water);
    return mat;
  }

  private buildBoats() {
    const R = rng(77);
    const hullMat = new THREE.MeshStandardMaterial({ color: 0x1c2022, roughness: 0.7 });
    for (let i = 0; i < 5; i++) {
      const b = new THREE.Group();
      const hull = new THREE.Mesh(new THREE.BoxGeometry(7, 2.4, 22), hullMat);
      const cab = new THREE.Mesh(new THREE.BoxGeometry(5, 4, 7), hullMat);
      cab.position.set(0, 3, 2);
      b.add(hull, cab);
      b.userData = { z: -200 - R() * 1400, x: -40 + (R() - 0.5) * 80, speed: 8 + R() * 10 };
      this.scene.add(b);
      this.boats.push(b);
    }
  }

  private buildBackdrop(tex: THREE.Texture) {
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 8;
    const mat = new THREE.ShaderMaterial({
      uniforms: { uMap: { value: tex }, uFog: { value: this.fog } },
      depthWrite: false,
      depthTest: false,
      vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
      fragmentShader: /* glsl */ `
        uniform sampler2D uMap; uniform vec3 uFog; varying vec2 vUv;
        void main() {
          vec3 c = texture2D(uMap, vUv).rgb;
          float l = dot(c, vec3(0.299, 0.587, 0.114));
          c = mix(vec3(l), c, 0.78);
          c *= vec3(0.82, 0.94, 1.0);
          float intoFog = smoothstep(0.52, 0.18, vUv.y);
          c = mix(c, uFog, intoFog * 0.88);
          gl_FragColor = vec4(c, 1.0);
        }`,
    });
    const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), mat);
    m.renderOrder = -20;
    m.frustumCulled = false;
    this.scene.add(m);
    return m;
  }

  /**
   * Pin the painting's skyline row to the true horizon, whatever the pitch,
   * so the photograph reads as the far city rather than a floating poster.
   * skylineV is the image v (0 bottom, 1 top) where sky meets towers.
   */
  update(t: number, cam: THREE.PerspectiveCamera) {
    this.water.uniforms.uTime.value = t;
    this.buildings.uniforms.uTime.value = t;
    for (const b of this.boats) {
      const z = ((b.userData.z as number) - t * (b.userData.speed as number)) % 1600;
      b.position.set(b.userData.x as number, G + 2.2, z > -80 ? z - 1600 : z);
    }
    const D = 6400;
    const e = new THREE.Euler().setFromQuaternion(cam.quaternion, "YXZ");
    const vt = Math.tan(THREE.MathUtils.degToRad(cam.fov / 2));
    const H = 2 * D * vt * 1.55;
    const W = Math.max(H * (16 / 9), 2 * D * vt * cam.aspect * 1.2);
    const skylineV = 0.58;
    const horizonY = D * Math.tan(-e.x);
    const centerY = horizonY + (0.5 - skylineV) * H;
    this.backdrop.scale.set(W, H, 1);
    this.backdrop.position.set(0, centerY, -D).applyQuaternion(cam.quaternion).add(cam.position);
    this.backdrop.quaternion.copy(cam.quaternion);
  }
}
