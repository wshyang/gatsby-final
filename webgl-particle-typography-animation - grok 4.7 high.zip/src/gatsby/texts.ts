/**
 * Manuscript copy for the scattered pages.
 * F. Scott Fitzgerald, The Great Gatsby (1925) — public domain.
 * Every glyph the particle system will ever show is printed from one of these
 * passages or from the sheet in the typewriter. Nothing is invented in the air.
 */

export const PASSAGES: string[] = [
  "In my younger and more vulnerable years my father gave me some advice that I've been turning over in my mind ever since. Whenever you feel like criticizing any one, he told me, just remember that all the people in this world haven't had the advantages that you've had.",
  "He didn't say any more, but we've always been unusually communicative in a reserved way, and I understood that he meant a great deal more than that. In consequence, I'm inclined to reserve all judgments.",
  "When I came back from the East last autumn I felt that I wanted the world to be in uniform and at a sort of moral attention forever. Only Gatsby, the man who gives his name to this book, was exempt from my reaction.",
  "If personality is an unbroken series of successful gestures, then there was something gorgeous about him, some heightened sensitivity to the promises of life, as if he were related to one of those intricate machines that register earthquakes ten thousand miles away.",
  "It was an extraordinary gift for hope, a romantic readiness such as I have never found in any other person and which it is not likely I shall ever find again. No — Gatsby turned out all right at the end.",
  "There was music from my neighbor's house through the summer nights. In his blue gardens men and girls came and went like moths among the whisperings and the champagne and the stars.",
  "The city seen from the Queensboro Bridge is always the city seen for the first time, in its first wild promise of all the mystery and the beauty in the world.",
  "He had thrown himself into it with a creative passion, adding to it all the time, decking it out with every bright feather that drifted his way. And his heart was in a constant, turbulent riot.",
  "Gatsby believed in the green light, the orgastic future that year by year recedes before us. It eluded us then, but that's no matter — tomorrow we will run faster, stretch out our arms farther.",
  "So we beat on, boats against the current, borne back ceaselessly into the past. Most of the big shore places were closed now and there were hardly any lights except the shadowy, moving glow of a ferryboat across the Sound.",
  "West Egg, especially, still figures in my more fantastic dreams. I see it as a night scene by El Greco: a hundred houses, at once conventional and grotesque, crouching under a sullen, overhanging sky and a lustreless moon.",
  "In the foreground four solemn men in dress suits are walking along the sidewalk with a stretcher on which lies a drunken woman in a white evening dress. Gravely the men turn in at a house — the wrong house. But no one knows the woman's name, and no one cares.",
  "After Gatsby's death the East was haunted for me like that, distorted beyond my eyes' power of correction. So when the blue smoke of brittle leaves was in the air and the wind blew the wet laundry stiff on the line I decided to come back home.",
];

/** Lines already on the sheet, above the quote. Row increases up the page. */
export const SHEET_ABOVE = [
  "and a lustreless moon. In the foreground",
  "four solemn men in dress suits are walking",
  "along the sidewalk with a stretcher on which",
  "lies a drunken woman in a white evening dress.",
  "Gravely the men turn in at a house — the wrong",
  "house. But no one knows the woman's name,",
];

export function wrap(text: string, cols: number): string[] {
  const out: string[] = [];
  let line = "";
  for (const word of text.split(/\s+/)) {
    if (!word) continue;
    if (line.length === 0) line = word;
    else if (line.length + 1 + word.length <= cols) line += " " + word;
    else {
      out.push(line);
      line = word;
    }
  }
  if (line) out.push(line);
  return out;
}

/** mulberry32 — the scene is identical every run. */
export function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
