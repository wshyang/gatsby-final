import * as THREE from "three";
import { TIMELINE } from "./config";
import type { GlyphAtlas } from "./atlas";
import type { GlyphBuffers } from "./mapping";

/**
 * One instanced draw for every typewritten character: sitting on the page,
 * peeling, hovering, rising, drifting in the sea, condensing into a word,
 * dissolving again.
 *
 *  CINEMATIC CURVE  (this is the pacing, not a linear lerp)
 *  ────────────────────────────────────────────────────────
 *   peel      1.7 s   ease-out cubic     fibres let go; the letter curls up
 *   hover     0.45–1.45 s  ~zero speed   the suspension beat
 *   ascent    6.6–9.0 s   double-smooth  very slow start, long glide, soft land
 *   sea       ongoing sine + snowfall    dense, modest, never frozen
 *   condense  1.85 s  quintic then back  hesitates, accelerates, snaps, settles
 *   leave     2.3 s   ease-in quad       drifts back into the fog
 *
 *  mimo's rejected assembly was a single smoothstep from page to slot.
 *  Here the slot is unreachable until the letter has already joined the sea.
 */

const PEEL = TIMELINE.peel.toFixed(3);

const vertexShader = /* glsl */ `
attribute vec3 aOrigin;
attribute vec4 aOriginQuat;
attribute vec3 aSea;
attribute vec3 aSlot;
attribute float aGlyph;
attribute vec4 aTime0;   // appear, lift, hover, ascent
attribute vec4 aTime1;   // arrive, condense, leave, member
attribute vec3 aSize;    // paper, sea, slot
attribute vec4 aSeed;
attribute float aCarriage;

uniform float uTime;
uniform float uCarriageX;
uniform vec3  uAxis;
uniform vec2  uGrid;
uniform float uMark;
uniform float uFade;

varying vec2 vUv;
varying float vAlpha;
varying float vAir;
varying float vQuote;
varying float vFlash;
varying float vMember;

const float PEEL = ${PEEL};
const float PI = 3.14159265;

vec3 qrot(vec4 q, vec3 v) { return v + 2.0 * cross(q.xyz, cross(q.xyz, v) + q.w * v); }
vec4 qaxis(vec3 ax, float an) { float h = an * 0.5; return vec4(normalize(ax) * sin(h), cos(h)); }
vec3 bez(vec3 a, vec3 b, vec3 c, vec3 d, float t) {
  float u = 1.0 - t;
  return u*u*u*a + 3.0*u*u*t*b + 3.0*u*t*t*c + t*t*t*d;
}
float sstep(float x) { x = clamp(x, 0.0, 1.0); return x * x * (3.0 - 2.0 * x); }
float ascentEase(float x) { float s = sstep(x); return mix(s, sstep(s), 0.62); }
float quint(float x) { return x < 0.5 ? 16.0*x*x*x*x*x : 1.0 - pow(-2.0*x + 2.0, 5.0) * 0.5; }
/* Hesitation, then a magnetic snap with a few percent of overshoot. */
float snapEase(float x) {
  x = clamp(x, 0.0, 1.0);
  // Stay in the sea for a breath, then lock. Avoids a long messy mid-air scramble.
  float t = smoothstep(0.12, 1.0, x);
  t = t * t * (3.0 - 2.0 * t);
  float c = 1.25;
  return 1.0 + (c + 1.0) * pow(t - 1.0, 3.0) + c * pow(t - 1.0, 2.0);
}

vec3 seaDrift(vec3 base, float t, vec4 s) {
  float tt = t - 12.0;
  vec3 drift = vec3(
    sin(t * (0.12 + 0.05 * s.x) + s.y * 31.0),
    sin(t * (0.09 + 0.04 * s.z) + s.w * 27.0) * 0.65,
    cos(t * (0.11 + 0.04 * s.y) + s.x * 23.0)
  ) * 0.42;
  drift.y -= 0.015 * tt * (0.35 + s.z);
  drift.x -= 0.01 * tt * (0.4 + s.x * 0.3);
  return base + drift;
}

void main() {
  float t = uTime;
  float appear = aTime0.x;
  float lift = aTime0.y;
  float hover = aTime0.z;
  float ascent = aTime0.w;
  float arrive = aTime1.x;
  float cdur = aTime1.y;
  float leave = aTime1.z;
  float member = aTime1.w;

  vec3 origin = aOrigin + uAxis * (uCarriageX * aCarriage);
  vec4 oq = normalize(aOriginQuat);
  vec3 nrm = qrot(oq, vec3(0.0, 0.0, 1.0));

  float pk = clamp((t - lift) / PEEL, 0.0, 1.0);
  float peelE = 1.0 - pow(1.0 - pk, 3.0);
  float peelH = 0.0035 + 0.007 * aSeed.x;
  vec3 wob = vec3(
    sin(t * 1.6 + aSeed.y * 20.0),
    sin(t * 2.1 + aSeed.w * 14.0) * 0.5,
    cos(t * 1.3 + aSeed.z * 18.0)
  ) * 0.0012 * peelE;
  vec3 peelPos = origin + nrm * peelH * peelE + wob;

  float a0 = lift + PEEL + hover;
  float ap = clamp((t - a0) / max(ascent, 0.001), 0.0, 1.0);
  float ae = ascentEase(ap);
  vec3 seaNow = seaDrift(aSea, t, aSeed);

  vec3 up = vec3(0.0, 1.0, 0.0);
  vec3 span = seaNow - peelPos;
  float dist = max(length(span), 0.001);
  vec3 dir = span / dist;
  vec3 side = normalize(cross(dir, abs(dir.y) > 0.92 ? vec3(1.0, 0.0, 0.0) : up));
  vec3 c1 = peelPos + nrm * (0.05 + 0.16 * aSeed.y) + up * (0.22 + 0.65 * aSeed.z);
  vec3 c2 = mix(peelPos, seaNow, 0.58) + up * (0.35 + 0.9 * aSeed.w) + side * (aSeed.x - 0.5) * dist * 0.42;
  vec3 ascendPos = bez(peelPos, c1, c2, seaNow, ae);
  float air = sin(ap * PI);
  ascendPos += side * sin(t * 1.15 + aSeed.y * 12.0) * 0.18 * air;
  ascendPos.y += cos(t * 1.4 + aSeed.z * 9.0) * 0.08 * air;

  vec3 pos = peelPos;
  float flown = 0.0;
  if (t >= a0) { pos = ascendPos; flown = ae; }
  if (ap >= 1.0) { pos = seaNow; flown = 1.0; }

  float qk = 0.0;
  float flash = 0.0;
  float ce = 0.0;
  if (member > 0.5 && t >= arrive && t < leave) {
    float c = clamp((t - arrive) / cdur, 0.0, 1.0);
    ce = snapEase(c);
    vec3 from = seaDrift(aSea, arrive, aSeed);
    pos = mix(from, aSlot, ce);
    qk = smoothstep(0.15, 0.85, c);
    flash = smoothstep(0.78, 0.9, c) * (1.0 - smoothstep(0.9, 1.0, c));
    flown = 1.0;
  }
  if (member > 0.5 && t >= leave) {
    float k = clamp((t - leave) / 2.3, 0.0, 1.0);
    float ke = k * k;
    pos = mix(aSlot, seaDrift(aSea, t, aSeed) + vec3(0.0, 0.55 * k, 0.0), ke);
    qk = 1.0 - ke;
    flown = 1.0;
  }

  float vis = appear < 0.0 ? 1.0 : smoothstep(0.0, 0.045, t - appear);
  float pop = appear < 0.0 ? 1.0 : smoothstep(0.0, 0.07, t - appear);

  float sz = mix(aSize.x, aSize.y, flown);
  if (member > 0.5 && t >= arrive && t < leave) {
    float c = clamp((t - arrive) / cdur, 0.0, 1.0);
    sz = mix(aSize.y, aSize.z, clamp(snapEase(c), 0.0, 1.15));
    sz *= 1.0 + flash * 0.1;
  } else if (member > 0.5 && t >= leave) {
    float k = clamp((t - leave) / 2.3, 0.0, 1.0);
    sz = mix(aSize.z, aSize.y, k * k);
  }
  if (t < lift) sz = aSize.x * pop;

  vec3 right = normalize(vec3(viewMatrix[0][0], viewMatrix[1][0], viewMatrix[2][0]));
  vec3 cup = normalize(vec3(viewMatrix[0][1], viewMatrix[1][1], viewMatrix[2][1]));

  vec3 paperLocal = qrot(oq, vec3(position.xy, 0.0) * aSize.x * pop);
  float curl = peelE * (aSeed.z - 0.5) * 0.55;
  paperLocal = qrot(qaxis(vec3(1.0, 0.0, 0.0), curl), paperLocal);

  float turns = 1.0 + floor(aSeed.y * 2.0);
  float spin = sin(min(ap, 1.0) * PI) * turns * 6.28318 * (aSeed.x > 0.5 ? 1.0 : -1.0);
  float sway = (flown > 0.95 && qk < 0.25) ? sin(t * 0.55 + aSeed.w * 8.0) * 0.28 : 0.0;
  vec3 axis = normalize(vec3(aSeed.x - 0.5, 0.25 + aSeed.y, aSeed.z - 0.5));
  vec3 bill = right * position.x * sz + cup * position.y * sz;
  bill = qrot(qaxis(axis, spin * (1.0 - qk) + sway * (1.0 - qk)), bill);

  float airborne = t < a0 ? 0.0 : smoothstep(0.04, 0.4, ap);
  if (qk > 0.4) airborne = 1.0;
  vec3 local = mix(paperLocal, bill, airborne);

  gl_Position = projectionMatrix * viewMatrix * vec4(pos + local, 1.0);

  float col = mod(aGlyph, uGrid.x);
  float row = floor(aGlyph / uGrid.x);
  vUv = (vec2(col, uGrid.y - 1.0 - row) + uv) / uGrid;

  float endFade = 1.0;
  if (t >= leave && member < 0.5) endFade = 1.0;
  vAlpha = vis * uFade * endFade;
  vAir = airborne;
  vQuote = qk;
  vFlash = flash;
  vMember = member;
}
`;

const fragmentShader = /* glsl */ `
precision highp float;
uniform sampler2D uAtlas;
uniform float uMark;
uniform float uTime;
varying vec2 vUv;
varying float vAlpha;
varying float vAir;
varying float vQuote;
varying float vFlash;
varying float vMember;

void main() {
  float a = texture2D(uAtlas, vUv).a;
  if (a < 0.12) discard;
  float edge = smoothstep(0.12, 0.42, a);
  float core = smoothstep(0.42, 0.78, a);
  vec3 ink = vec3(0.07, 0.055, 0.045);
  vec3 air = vec3(0.93, 0.90, 0.84);
  vec3 quote = vec3(0.98, 0.95, 0.90);
  vec3 gold = vec3(0.86, 0.70, 0.38);
  vec3 col = mix(ink, air, smoothstep(0.02, 0.55, vAir));
  col = mix(col * 0.78, col, mix(1.0, core, vAir));
  col = mix(col, quote, vQuote);
  if (uMark > 0.5 && vMember > 0.5) {
    float pulse = 0.42 + 0.16 * sin(uTime * 2.4);
    col = mix(col, gold, pulse);
  }
  col += vFlash * 0.45;
  float rib = 0.9 + 0.1 * sin(vUv.y * 160.0);
  col *= mix(rib, 1.0, max(vAir, vQuote));
  float alpha = edge * vAlpha;
  alpha *= mix(1.0, 0.8, vAir * (1.0 - vQuote));
  if (alpha < 0.04) discard;
  gl_FragColor = vec4(col, alpha);
}
`;

export function createGlyphMesh(atlas: GlyphAtlas, data: GlyphBuffers) {
  const geo = new THREE.InstancedBufferGeometry();
  const plane = new THREE.PlaneGeometry(1, 1);
  geo.index = plane.index;
  geo.setAttribute("position", plane.getAttribute("position"));
  geo.setAttribute("uv", plane.getAttribute("uv"));
  const inst = (arr: Float32Array, size: number) => new THREE.InstancedBufferAttribute(arr, size);
  geo.setAttribute("aOrigin", inst(data.origin, 3));
  geo.setAttribute("aOriginQuat", inst(data.originQuat, 4));
  geo.setAttribute("aSea", inst(data.sea, 3));
  geo.setAttribute("aSlot", inst(data.slot, 3));
  geo.setAttribute("aGlyph", inst(data.glyph, 1));
  geo.setAttribute("aTime0", inst(data.time0, 4));
  geo.setAttribute("aTime1", inst(data.time1, 4));
  geo.setAttribute("aSize", inst(data.size, 3));
  geo.setAttribute("aSeed", inst(data.seed, 4));
  geo.setAttribute("aCarriage", inst(data.carriage, 1));
  geo.instanceCount = data.count;

  const uniforms = {
    uTime: { value: 0 },
    uCarriageX: { value: 0 },
    uAxis: { value: new THREE.Vector3(1, 0, 0) },
    uGrid: { value: new THREE.Vector2(atlas.cols, atlas.rows) },
    uAtlas: { value: atlas.texture },
    uMark: { value: 0 },
    uFade: { value: 1 },
  };

  const material = new THREE.ShaderMaterial({
    uniforms,
    vertexShader,
    fragmentShader,
    transparent: true,
    depthWrite: false,
    depthTest: true,
    side: THREE.DoubleSide,
  });

  const mesh = new THREE.Mesh(geo, material);
  mesh.frustumCulled = false;
  mesh.renderOrder = 5;
  return { mesh, uniforms };
}

export type GlyphUniforms = ReturnType<typeof createGlyphMesh>["uniforms"];
