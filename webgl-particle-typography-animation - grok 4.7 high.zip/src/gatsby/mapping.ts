import * as THREE from "three";
import { glyphIndex, type GlyphAtlas } from "./atlas";
import { referencePose } from "./camera";
import {
  CONDENSE,
  LETTER_STAGGER,
  QUOTE,
  QUOTE_ADVANCE,
  QUOTE_DEPTH,
  QUOTE_GAP,
  SHEET_LINE_DEATH,
  SHEET_LINE_HAUNTED,
  TIMELINE,
  TYPE,
  TYPED_LINE,
} from "./config";
import type { PagePose } from "./desk";
import { PASSAGES, rng, SHEET_ABOVE, wrap } from "./texts";
import { Typewriter } from "./typewriter";

/**
 * ============================================================================
 *  DATA MAPPING  —  paper cell  →  sea of letters  →  quote slot
 * ============================================================================
 *
 *  One row of these buffers is one character that is physically printed on a
 *  sheet. The GPU never invents a position: the vertex shader only evaluates
 *  curves between the points stored here. That is the "no spawning out of
 *  nowhere" rule.
 *
 *    1. SOURCE   aOrigin / aOriginQuat
 *         World position and orientation of the character cell, computed with
 *         the same transform that places the paper mesh (PagePose for the
 *         scattered sheets, Typewriter.sheetGlyph for the sheet in the
 *         machine). Carriage glyphs also carry aCarriage = 1 so they slide
 *         with the platen while the line is being typed.
 *
 *    2. SEA      aSea
 *         A resting point inside the reference aerial frustum, sized so every
 *         letter reads as a similar small snowflake (fable low's sea size)
 *         but packed densely enough that the air looks haunted (reviews.txt
 *         called the earlier sea too sparse). The shader adds a slow drift.
 *
 *    3. QUOTE    aSlot   (members only; others keep their sea point)
 *         "After Gatsby's death,", "New York was haunted" and "for me..." are
 *         mapped 1:1 from the three lines on the sheet in the typewriter —
 *         one of them typed live in the opening. The continuation
 *         ("distorted beyond my eyes' power of correction.") is harvested by
 *         matching glyph from the nearest scattered pages. Same character,
 *         a real cell, never a synthesised one.
 *
 *    TIMING
 *         aTime0 = (appear, lift, hover, ascent)
 *         aTime1 = (arrive, condense, leave, isMember)
 *         Lift is a radial wave from the typewriter plus jitter, so ALL
 *         letters on ALL visible pages leave the paper (reviews.txt). Quote
 *         members peel first, off the line the camera is reading. Flight is
 *         clamped to finish before that letter's arrive time, so condensation
 *         always begins from the sea — not from a half-finished lerp, which
 *         was the assembly reviews.txt rejected.
 */

export interface GlyphBuffers {
  count: number;
  members: number;
  origin: Float32Array;
  originQuat: Float32Array;
  sea: Float32Array;
  slot: Float32Array;
  glyph: Float32Array;
  time0: Float32Array;
  time1: Float32Array;
  size: Float32Array;
  seed: Float32Array;
  carriage: Float32Array;
}

interface Source {
  ch: string;
  pos: THREE.Vector3;
  quat: THREE.Quaternion;
  carriage: boolean;
  appear: number;
  /** 0, 1, 2 for the three quote lines on the sheet, else -1. */
  sheetLine: -1 | 0 | 1 | 2;
  col: number;
  dist: number;
}

interface Slot {
  ch: string;
  pos: THREE.Vector3;
  size: number;
  arrive: number;
  leave: number;
  sheetLine: -1 | 0 | 1 | 2;
  col: number;
}

const rand = rng(2013);
const between = (a: number, b: number) => a + rand() * (b - a);

function collectSources(pages: PagePose[], tw: Typewriter, atlas: GlyphAtlas): Source[] {
  const out: Source[] = [];
  const tmp = new THREE.Vector3();
  const center = new THREE.Vector3(0, 0, 0);

  // Scattered pages. Row 0 is the top of the page.
  for (const page of pages) {
    const lines = wrap(PASSAGES[page.passage % PASSAGES.length], TYPE.columns).slice(0, page.lines);
    lines.forEach((text, row) => {
      for (let col = 0; col < text.length; col++) {
        const ch = text[col];
        if (ch === " " || !atlas.index.has(ch)) continue;
        const x = -page.width / 2 + TYPE.marginX + col * TYPE.cell + (rand() - 0.5) * 0.00025;
        const y = page.height / 2 - TYPE.marginTop - row * TYPE.line + (rand() - 0.5) * 0.0002;
        tmp.set(x, y, 0.0007).applyQuaternion(page.quaternion).add(page.position);
        // Skip anything that would rise through the machine.
        const dx = tmp.x - center.x;
        const dz = tmp.z - center.z;
        if (dx * dx + dz * dz < 0.2 * 0.2 && tmp.y < 0.08) continue;
        const jitter = (rand() - 0.5) * 0.01;
        const quat = page.quaternion.clone().multiply(
          new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 0, 1), jitter),
        );
        out.push({
          ch,
          pos: tmp.clone(),
          quat,
          carriage: false,
          appear: -1,
          sheetLine: -1,
          col,
          dist: Math.hypot(tmp.x, tmp.z),
        });
      }
    });
  }

  // Sheet in the machine. Row 0 is the live line at the bail.
  const sheetLines: { row: number; text: string; live: boolean; sheetLine: -1 | 0 | 1 | 2 }[] = [
    { row: 0, text: TYPED_LINE, live: true, sheetLine: 0 },
    { row: 2, text: SHEET_LINE_HAUNTED, live: false, sheetLine: 1 },
    { row: 4, text: SHEET_LINE_DEATH, live: false, sheetLine: 2 },
  ];
  SHEET_ABOVE.forEach((text, i) => {
    sheetLines.push({ row: 6 + i * 2, text, live: false, sheetLine: -1 });
  });

  for (const line of sheetLines) {
    for (let col = 0; col < line.text.length; col++) {
      const ch = line.text[col];
      if (ch === " " || !atlas.index.has(ch)) continue;
      const g = tw.sheetGlyph(line.row, col);
      const appear = line.live ? (tw.strokes[col]?.t ?? TIMELINE.typingStart) : -1;
      out.push({
        ch,
        pos: g.world,
        quat: g.quat,
        carriage: true,
        appear,
        sheetLine: line.sheetLine,
        col,
        dist: 0.02,
      });
    }
  }
  return out;
}

function collectSlots(atlas: GlyphAtlas): Slot[] {
  const ref = referencePose();
  const slots: Slot[] = [];
  for (const line of QUOTE) {
    const depth = QUOTE_DEPTH + (line.depth ?? 0);
    const height = 0.34;
    // Measure the line so it can be centred on line.at[0].
    let width = 0;
    line.words.forEach((w, wi) => {
      const h = height * (w.scale ?? 1);
      const chars = [...w.text].filter((c) => c !== " ").length;
      const spaces = w.text.length - chars;
      width += chars * h * QUOTE_ADVANCE + spaces * h * QUOTE_ADVANCE * 0.55;
      if (wi < line.words.length - 1) width += h * QUOTE_GAP;
    });
    const halfH = ref.tanHalf * depth;
    let cursor = line.at[0] - width / halfH / 2;
    // Column in the reconstructed full line (words joined by single spaces),
    // so a slot can be matched 1:1 to the character cell on the sheet.
    let lineCol = 0;
    line.words.forEach((w, wi) => {
      const h = height * (w.scale ?? 1);
      const adv = (h * QUOTE_ADVANCE) / halfH;
      let letter = 0;
      for (let i = 0; i < w.text.length; i++) {
        const ch = w.text[i];
        if (ch !== " " && atlas.index.has(ch)) {
          const arrive = w.arrive + letter * LETTER_STAGGER;
          const pos = ref.frameToWorld(cursor + adv * 0.5, line.at[1], depth);
          slots.push({
            ch,
            pos,
            size: h,
            arrive,
            leave: w.leave,
            sheetLine: line.sheetLine ?? -1,
            col: lineCol,
          });
          cursor += adv;
          letter++;
        } else {
          cursor += adv * 0.55;
        }
        lineCol++;
      }
      if (wi < line.words.length - 1) {
        cursor += (h * QUOTE_GAP) / halfH;
        lineCol++;
      }
    });
  }
  return slots;
}

function seaPoint(ref: ReturnType<typeof referencePose>, aspect: number) {
  // Concentrate the cloud in the aerial frustum so the frame fills, rather
  // than scattering letters across the whole world (that read as "sparse").
  const depth = between(3.4, 14.5);
  const fy = (rand() - 0.48) * 1.85;
  const fx = (rand() - 0.5) * aspect * 1.9;
  const pos = ref.frameToWorld(fx, fy, depth);
  // Screen-constant size: fable low's sea-letter scale, with a little variation.
  const size = depth * ref.tanHalf * 2 * between(0.018, 0.028);
  return { pos, size };
}

export function buildGlyphBuffers(pages: PagePose[], tw: Typewriter, atlas: GlyphAtlas): GlyphBuffers {
  const sources = collectSources(pages, tw, atlas);
  const slots = collectSlots(atlas);
  const ref = referencePose();
  const n = sources.length;

  const origin = new Float32Array(n * 3);
  const originQuat = new Float32Array(n * 4);
  const sea = new Float32Array(n * 3);
  const slot = new Float32Array(n * 3);
  const glyph = new Float32Array(n);
  const time0 = new Float32Array(n * 4);
  const time1 = new Float32Array(n * 4);
  const size = new Float32Array(n * 3);
  const seed = new Float32Array(n * 4);
  const carriage = new Float32Array(n);

  const used = new Set<number>();

  // 1:1 from the typed sheet, then character-matched harvest for the rest.
  const memberOf = new Array<number>(n).fill(-1);
  const claim = (pred: (s: Source, i: number) => boolean, slotIndex: number) => {
    let best = -1;
    let bestD = Infinity;
    for (let i = 0; i < n; i++) {
      if (used.has(i)) continue;
      if (!pred(sources[i], i)) continue;
      if (sources[i].dist < bestD) {
        bestD = sources[i].dist;
        best = i;
      }
    }
    if (best < 0) return false;
    used.add(best);
    memberOf[best] = slotIndex;
    return true;
  };

  slots.forEach((sl, si) => {
    if (sl.sheetLine >= 0) {
      const ok = claim((s) => s.sheetLine === sl.sheetLine && s.col === sl.col && s.ch === sl.ch, si);
      if (ok) return;
    }
    claim((s) => s.ch === sl.ch, si);
  });

  let members = 0;
  for (let i = 0; i < n; i++) {
    const s = sources[i];
    const seaP = seaPoint(ref, 16 / 9);
    origin[i * 3] = s.pos.x;
    origin[i * 3 + 1] = s.pos.y;
    origin[i * 3 + 2] = s.pos.z;
    originQuat[i * 4] = s.quat.x;
    originQuat[i * 4 + 1] = s.quat.y;
    originQuat[i * 4 + 2] = s.quat.z;
    originQuat[i * 4 + 3] = s.quat.w;
    sea[i * 3] = seaP.pos.x;
    sea[i * 3 + 1] = seaP.pos.y;
    sea[i * 3 + 2] = seaP.pos.z;
    glyph[i] = glyphIndex(atlas, s.ch);
    carriage[i] = s.carriage ? 1 : 0;
    seed[i * 4] = rand();
    seed[i * 4 + 1] = rand();
    seed[i * 4 + 2] = rand();
    seed[i * 4 + 3] = rand();

    // Radial wave from the machine. Members on the sheet leave first.
    const wave = THREE.MathUtils.clamp(s.dist / 0.72, 0, 1);
    let lift = TIMELINE.liftStart + wave * TIMELINE.liftSpread + rand() * TIMELINE.liftJitter;
    if (s.sheetLine >= 0) lift = TIMELINE.liftStart + rand() * 0.7 + s.sheetLine * 0.08;
    let hover = between(TIMELINE.hover[0], TIMELINE.hover[1]);
    let ascent = between(TIMELINE.ascent[0], TIMELINE.ascent[1]);

    const mi = memberOf[i];
    let arrive = 0;
    let leave = 999;
    let slotSize = seaP.size;
    let member = 0;
    if (mi >= 0) {
      const sl = slots[mi];
      member = 1;
      members++;
      arrive = sl.arrive;
      leave = sl.leave;
      slotSize = sl.size;
      slot[i * 3] = sl.pos.x;
      slot[i * 3 + 1] = sl.pos.y;
      slot[i * 3 + 2] = sl.pos.z;
      // Condensation must start from the sea, not mid-flight.
      const budget = arrive - 1.05 - lift - TIMELINE.peel;
      if (hover + ascent > budget) {
        hover = Math.min(hover, Math.max(0.2, budget * 0.22));
        ascent = Math.max(2.4, budget - hover);
      }
    } else {
      slot[i * 3] = seaP.pos.x;
      slot[i * 3 + 1] = seaP.pos.y;
      slot[i * 3 + 2] = seaP.pos.z;
    }

    time0[i * 4] = s.appear;
    time0[i * 4 + 1] = lift;
    time0[i * 4 + 2] = hover;
    time0[i * 4 + 3] = ascent;
    time1[i * 4] = arrive;
    time1[i * 4 + 1] = CONDENSE;
    time1[i * 4 + 2] = leave;
    time1[i * 4 + 3] = member;

    const paperSize = TYPE.cell * TYPE.quad;
    size[i * 3] = paperSize;
    size[i * 3 + 1] = seaP.size;
    size[i * 3 + 2] = slotSize;
  }

  return { count: n, members, origin, originQuat, sea, slot, glyph, time0, time1, size, seed, carriage };
}
