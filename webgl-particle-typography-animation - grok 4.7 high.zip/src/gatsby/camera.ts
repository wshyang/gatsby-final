import * as THREE from "three";
import { REF_ASPECT, REF_TIME, TIMELINE, VFOV } from "./config";

/**
 * Camera rig — a pure function of time.
 *
 *  Close pose   : a few centimetres off the sheet in the typewriter, so the
 *                 typed quote is legible and clearly the source of the letters.
 *  High pose    : a slow overhead pull-back (reviews.txt: do not zoom fast)
 *                 with a slight roll, the way the film climbs off the desk.
 *  Aerial pose  : oblique view over the city, drifting just enough that the
 *                 quote breathes but stays framed.
 *
 *  Close → high is a long smootherstep. High → aerial is a second, slower
 *  blend while the desk dissolves. Nothing is linear.
 */

const ease = (x: number) => 0.5 - 0.5 * Math.cos(Math.PI * THREE.MathUtils.clamp(x, 0, 1));
const span = (t: number, r: readonly [number, number]) => (t - r[0]) / (r[1] - r[0]);

const closePos = new THREE.Vector3(0.03, 0.4, 0.18);
const closeLook = new THREE.Vector3(0, 0.18, -0.04);
const highPos = new THREE.Vector3(0.04, 2.55, 0.38);
const highLook = new THREE.Vector3(0.0, 0.04, -0.04);

const tmpObj = new THREE.Object3D();
const pA = new THREE.Vector3();
const pB = new THREE.Vector3();
const qA = new THREE.Quaternion();
const qB = new THREE.Quaternion();

function lookQuat(pos: THREE.Vector3, look: THREE.Vector3, roll: number, out: THREE.Quaternion) {
  tmpObj.position.copy(pos);
  tmpObj.up.set(0, 1, 0);
  tmpObj.lookAt(look);
  tmpObj.rotateZ(roll);
  out.copy(tmpObj.quaternion);
}

/** Called once the typewriter exists, so the opening frame sits on the sheet. */
export function setCloseAnchor(focus: THREE.Vector3, normal: THREE.Vector3, up: THREE.Vector3) {
  closeLook.copy(focus);
  closePos.copy(focus).addScaledVector(normal, 0.2).addScaledVector(up, 0.02);
  closePos.x += 0.01;
  closePos.y += 0.018;
}

function overhead(t: number, pos: THREE.Vector3, quat: THREE.Quaternion) {
  const k = ease(span(t, TIMELINE.cameraRise));
  pos.lerpVectors(closePos, highPos, k);
  const breathe = Math.sin(t * 0.55) * 0.0035;
  pos.y += breathe;
  const roll = THREE.MathUtils.lerp(0.02, -0.07, k);
  lookQuat(closePos, closeLook, 0.02, qA);
  lookQuat(highPos, highLook, -0.07, qB);
  quat.slerpQuaternions(qA, qB, k);
  // re-apply a touch of roll so the slerp doesn't flatten it
  tmpObj.quaternion.copy(quat);
  tmpObj.rotateZ(roll * 0.15);
  quat.copy(tmpObj.quaternion);
}

/** Oblique aerial. Pitch is positive X in YXZ order — looks down. */
export function aerialPose(t: number, pos: THREE.Vector3, quat: THREE.Quaternion) {
  const d = t - REF_TIME;
  pos.set(0.1 + 0.022 * d, 4.62 - 0.006 * d, 1.28 - 0.018 * d);
  pos.x += Math.sin(t * 0.31) * 0.006;
  pos.y += Math.sin(t * 0.23) * 0.004;
  const yaw = -0.025 + 0.0014 * d;
  const pitch = 0.2;
  const roll = -0.012;
  quat.setFromEuler(new THREE.Euler(pitch, yaw, roll, "YXZ"));
}

export function poseAt(t: number, pos: THREE.Vector3, quat: THREE.Quaternion) {
  const w = ease(span(t, TIMELINE.cameraTilt));
  overhead(t, pA, qA);
  aerialPose(t, pB, qB);
  pos.lerpVectors(pA, pB, w);
  quat.slerpQuaternions(qA, qB, w);
}

export function vfovFor(aspect: number) {
  if (aspect >= REF_ASPECT) return VFOV;
  const h = Math.tan(THREE.MathUtils.degToRad(VFOV / 2)) * REF_ASPECT;
  return THREE.MathUtils.radToDeg(2 * Math.atan(h / aspect));
}

export interface RefPose {
  position: THREE.Vector3;
  quaternion: THREE.Quaternion;
  tanHalf: number;
  /** fx, fy in half-height units (y = ±1 is the frame edge) at `depth` metres. */
  frameToWorld: (fx: number, fy: number, depth: number) => THREE.Vector3;
}

export function referencePose(): RefPose {
  const position = new THREE.Vector3();
  const quaternion = new THREE.Quaternion();
  aerialPose(REF_TIME, position, quaternion);
  const tanHalf = Math.tan(THREE.MathUtils.degToRad(VFOV / 2));
  const frameToWorld = (fx: number, fy: number, depth: number) =>
    new THREE.Vector3(fx * tanHalf * depth, fy * tanHalf * depth, -depth).applyQuaternion(quaternion).add(position);
  return { position, quaternion, tanHalf, frameToWorld };
}
