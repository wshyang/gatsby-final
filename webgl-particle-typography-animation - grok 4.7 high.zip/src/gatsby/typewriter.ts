import * as THREE from "three";
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js";
import { TIMELINE, TYPE, TYPED_LINE } from "./config";

/**
 * Textured 1920s front-strike machine.
 *
 * reviews.txt: the favourite build's typewriter read as a flat untextured
 * prop; another build had corrupted type-bar strikers. This one keeps the
 * strikers honest (every bar pivots on the segment arc and lands on the same
 * printing point) and wears a real lacquer map, clearcoat, chrome and brass
 * under an environment map so the close-up has something to catch the lamp.
 *
 * Local frame: +x right, +y up, +z toward the typist.
 *
 * TYPE-BAR GEOMETRY
 *   Pivot sits on a circle of radius R0 around basket centre C.
 *   Bar length L. A strike rotates the bar about its own tangent by
 *   STRIKE = acos(-R0 / L), which parks every slug at
 *   C + (0, sqrt(L² − R0²), 0) — one printing point, no intersecting mess.
 */

const KEY_ROWS = ["1234567890-", "QWERTYUIOP", "ASDFGHJKL;'", "ZXCVBNM,./"];

const C = new THREE.Vector3(0, 0.068, -0.01);
const R0 = 0.032;
const L = 0.07;
const STRIKE = Math.acos(-R0 / L);
const REST = 0.085;
const PRINT_Y = C.y + Math.sqrt(L * L - R0 * R0);
const PLATEN_R = 0.0195;
const SHEET_TILT = THREE.MathUtils.degToRad(40);
const SHEET_LEN = 0.232;
const COL0_X = -TYPE.pageW / 2 + TYPE.marginX;

export interface Keystroke {
  ch: string;
  t: number;
}

export class Typewriter {
  readonly group = new THREE.Group();
  readonly carriage = new THREE.Group();
  readonly strokes: Keystroke[] = [];

  private bars: THREE.Group[] = [];
  private keys = new Map<string, THREE.Object3D>();
  private spaceBar!: THREE.Mesh;
  private barIndex = new Map<string, number>();
  private ribbonVibe!: THREE.Mesh;

  constructor(lacquerMap: THREE.Texture) {
    let prev = TIMELINE.typingStart - TIMELINE.typingInterval;
    for (let i = 0; i < TYPED_LINE.length; i++) {
      const ch = TYPED_LINE[i];
      const pause = ch === " " ? 0.07 : TYPED_LINE[i - 1] === " " ? 0.04 : 0;
      const jitter = Math.sin(i * 12.9898) * 0.012;
      const t = Math.max(prev + 0.09, TIMELINE.typingStart + i * TIMELINE.typingInterval + pause + jitter);
      this.strokes.push({ ch, t });
      prev = t;
    }
    this.build(lacquerMap);
  }

  private build(lacquerMap: THREE.Texture) {
    lacquerMap.wrapS = lacquerMap.wrapT = THREE.RepeatWrapping;
    lacquerMap.repeat.set(1.6, 1.4);
    lacquerMap.colorSpace = THREE.SRGBColorSpace;
    lacquerMap.anisotropy = 8;

    const lacquer = new THREE.MeshPhysicalMaterial({
      map: lacquerMap,
      color: 0xffffff,
      roughness: 0.32,
      metalness: 0.28,
      clearcoat: 1,
      clearcoatRoughness: 0.12,
      envMapIntensity: 1.15,
    });
    const lacquerDark = new THREE.MeshPhysicalMaterial({
      color: 0x0c0c0e,
      roughness: 0.46,
      metalness: 0.18,
      clearcoat: 0.7,
      clearcoatRoughness: 0.22,
      envMapIntensity: 0.55,
    });
    const chrome = new THREE.MeshStandardMaterial({
      color: 0xe4e4e8,
      metalness: 1,
      roughness: 0.16,
      envMapIntensity: 1.35,
    });
    const steel = new THREE.MeshStandardMaterial({
      color: 0x8a8d92,
      metalness: 0.92,
      roughness: 0.34,
      envMapIntensity: 1.05,
    });
    const brass = new THREE.MeshStandardMaterial({
      color: 0xc6a15a,
      metalness: 1,
      roughness: 0.28,
      envMapIntensity: 1.15,
    });
    const rubber = new THREE.MeshStandardMaterial({ color: 0x141414, roughness: 0.78, metalness: 0.02 });
    const felt = new THREE.MeshStandardMaterial({ color: 0x1a1512, roughness: 1 });
    const ribbonMat = new THREE.MeshStandardMaterial({ color: 0x6e1c22, roughness: 0.72 });
    const keyGlass = new THREE.MeshPhysicalMaterial({
      color: 0x141416,
      roughness: 0.18,
      metalness: 0.12,
      clearcoat: 1,
      clearcoatRoughness: 0.08,
      envMapIntensity: 1.1,
    });

    const g = this.group;
    const add = (mesh: THREE.Mesh, parent: THREE.Object3D = g) => {
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      parent.add(mesh);
      return mesh;
    };
    const rbox = (w: number, h: number, d: number, r: number, mat: THREE.Material) =>
      new THREE.Mesh(new RoundedBoxGeometry(w, h, d, 3, r), mat);

    /* ---- body: lacquered, panelled, not a single slab ------------------ */
    add(rbox(0.34, 0.048, 0.30, 0.012, lacquer)).position.set(0, 0.028, 0.02);
    add(rbox(0.30, 0.02, 0.26, 0.006, lacquerDark)).position.set(0, 0.056, 0.01);
    const cheekL = add(rbox(0.028, 0.11, 0.16, 0.008, lacquer));
    cheekL.position.set(-0.155, 0.07, -0.03);
    const cheekR = cheekL.clone();
    cheekR.position.x = 0.155;
    add(cheekR);
    add(rbox(0.31, 0.04, 0.055, 0.008, lacquer)).position.set(0, 0.078, -0.095);
    // front apron
    add(rbox(0.30, 0.036, 0.02, 0.004, lacquer)).position.set(0, 0.03, 0.168);
    // gold pinstripes — the detail that stops the body reading as a black box
    add(new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.0014, 0.0014), brass)).position.set(0, 0.042, 0.1785);
    add(new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.0014, 0.0014), brass)).position.set(0, 0.016, 0.1785);
    add(new THREE.Mesh(new THREE.BoxGeometry(0.0012, 0.0014, 0.22), brass)).position.set(-0.148, 0.052, 0.02);
    add(new THREE.Mesh(new THREE.BoxGeometry(0.0012, 0.0014, 0.22), brass)).position.set(0.148, 0.052, 0.02);

    // brand plate
    const plate = add(new THREE.Mesh(new THREE.BoxGeometry(0.072, 0.018, 0.0016), this.brandMaterial()));
    plate.position.set(0, 0.03, 0.179);

    // corner screws
    const screw = new THREE.CylinderGeometry(0.0032, 0.0032, 0.002, 10);
    for (const [sx, sz] of [
      [-0.145, 0.145],
      [0.145, 0.145],
      [-0.145, -0.1],
      [0.145, -0.1],
    ] as const) {
      const s = add(new THREE.Mesh(screw, chrome));
      s.position.set(sx, 0.053, sz);
    }

    // feet
    for (const [sx, sz] of [
      [-0.13, 0.12],
      [0.13, 0.12],
      [-0.13, -0.1],
      [0.13, -0.1],
    ] as const) {
      const f = add(new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.014, 0.008, 16), rubber));
      f.position.set(sx, 0.004, sz);
    }

    // keyboard deck
    const deck = add(rbox(0.28, 0.012, 0.13, 0.004, lacquerDark));
    deck.position.set(0, 0.052, 0.118);
    deck.rotation.x = 0.28;

    // basket floor + segment
    const floor = add(new THREE.Mesh(new THREE.CircleGeometry(0.1, 40, -Math.PI / 2 - 1.35, 2.7), felt));
    floor.rotation.x = -Math.PI / 2;
    floor.position.set(C.x, 0.058, C.z);
    const seg = add(new THREE.Mesh(new THREE.TorusGeometry(R0, 0.0032, 8, 40, 2.85), chrome));
    seg.rotation.set(Math.PI / 2, 0, 0.14);
    seg.position.set(C.x, C.y - 0.001, C.z);

    /* ---- type bars: one Object3D each, so the strike can't corrupt ---- */
    const all = KEY_ROWS.join("");
    const barGeo = new THREE.BoxGeometry(0.0022, 0.00115, L);
    barGeo.translate(0, 0, L / 2);
    const slugGeo = new THREE.BoxGeometry(0.0036, 0.0042, 0.005);
    slugGeo.translate(0, 0.0014, L - 0.0026);
    for (let i = 0; i < all.length; i++) {
      const theta = -1.28 + (2.56 * i) / (all.length - 1);
      const dir = new THREE.Vector3(Math.sin(theta), 0, Math.cos(theta));
      const pivot = new THREE.Group();
      pivot.position.copy(C).addScaledVector(dir, R0);
      pivot.rotation.order = "YXZ";
      pivot.rotation.y = theta;
      pivot.rotation.x = REST;
      const bar = new THREE.Mesh(barGeo, steel);
      const slug = new THREE.Mesh(slugGeo, steel);
      bar.castShadow = true;
      pivot.add(bar, slug);
      g.add(pivot);
      this.bars.push(pivot);
      this.barIndex.set(all[i], i);
    }

    /* ---- keys ---------------------------------------------------------- */
    const legend = this.legendTexture(all);
    const capGeo = new THREE.CylinderGeometry(0.0074, 0.0076, 0.0034, 24);
    const ringGeo = new THREE.TorusGeometry(0.0076, 0.00085, 8, 24);
    const stemGeo = new THREE.CylinderGeometry(0.0011, 0.0011, 0.028, 6);
    const discGeo = new THREE.CircleGeometry(0.0056, 20);
    let idx = 0;
    KEY_ROWS.forEach((row, r) => {
      const z = 0.092 + r * 0.022;
      const y = 0.084 - r * 0.0064;
      const x0 = -((row.length - 1) * 0.0188) / 2 + (r - 1.5) * 0.004;
      for (let k = 0; k < row.length; k++) {
        const key = new THREE.Group();
        const cap = new THREE.Mesh(capGeo, keyGlass);
        cap.castShadow = true;
        const ring = new THREE.Mesh(ringGeo, chrome);
        ring.rotation.x = Math.PI / 2;
        ring.position.y = 0.0016;
        const stem = new THREE.Mesh(stemGeo, steel);
        stem.position.y = -0.014;
        const tex = legend.clone();
        tex.repeat.set(1 / 8, 1 / 6);
        tex.offset.set((idx % 8) / 8, 1 - (Math.floor(idx / 8) + 1) / 6);
        tex.needsUpdate = true;
        const discMat = new THREE.MeshBasicMaterial({ map: tex, transparent: true });
        const disc = new THREE.Mesh(discGeo, discMat);
        disc.rotation.x = -Math.PI / 2;
        disc.position.y = 0.0019;
        key.add(cap, ring, stem, disc);
        key.position.set(x0 + k * 0.0188, y, z);
        key.userData.y = y;
        g.add(key);
        this.keys.set(row[k], key);
        idx++;
      }
    });
    this.spaceBar = add(rbox(0.118, 0.006, 0.012, 0.0026, lacquerDark));
    this.spaceBar.position.set(0, 0.056, 0.178);
    this.spaceBar.userData.y = 0.056;

    /* ---- ribbon -------------------------------------------------------- */
    for (const sx of [-0.1, 0.1]) {
      add(new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.003, 28), chrome)).position.set(sx, 0.092, -0.07);
      add(new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.016, 0.01, 28), ribbonMat)).position.set(sx, 0.098, -0.07);
      add(new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.004, 0.014, 12), chrome)).position.set(sx, 0.104, -0.07);
    }
    this.ribbonVibe = add(new THREE.Mesh(new THREE.BoxGeometry(0.016, 0.014, 0.0014), ribbonMat));
    this.ribbonVibe.position.set(0, PRINT_Y - 0.002, C.z + 0.001);
    this.ribbonVibe.userData.y = this.ribbonVibe.position.y;

    /* ---- carriage, platen, paper --------------------------------------- */
    const car = this.carriage;
    g.add(car);
    const platenZ = C.z - PLATEN_R * 0.15;
    const platen = add(new THREE.Mesh(new THREE.CylinderGeometry(PLATEN_R, PLATEN_R, 0.32, 36), rubber), car);
    platen.rotation.z = Math.PI / 2;
    platen.position.set(0, PRINT_Y, platenZ);
    // knurled chrome knobs
    for (const sx of [-1, 1]) {
      const knob = add(new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.016, 0.018, 28), chrome), car);
      knob.rotation.z = Math.PI / 2;
      knob.position.set(sx * 0.178, PRINT_Y, platenZ);
      const knurl = add(new THREE.Mesh(new THREE.CylinderGeometry(0.0172, 0.0172, 0.007, 20), rubber), car);
      knurl.rotation.z = Math.PI / 2;
      knurl.position.set(sx * 0.186, PRINT_Y, platenZ);
      const endplate = add(rbox(0.01, 0.052, 0.07, 0.003, lacquer), car);
      endplate.position.set(sx * 0.162, PRINT_Y - 0.01, platenZ - 0.01);
    }
    // rails
    for (const rz of [-0.055, -0.07]) {
      const rail = add(new THREE.Mesh(new THREE.CylinderGeometry(0.0026, 0.0026, 0.4, 12), chrome));
      rail.rotation.z = Math.PI / 2;
      rail.position.set(0, PRINT_Y - 0.028, rz);
    }
    // paper bail
    const bail = add(new THREE.Mesh(new THREE.CylinderGeometry(0.0016, 0.0016, 0.28, 10), chrome), car);
    bail.rotation.z = Math.PI / 2;
    bail.position.set(0, PRINT_Y + PLATEN_R * 0.72, platenZ + 0.008);
    for (const bx of [-0.06, 0.05]) {
      const roller = add(new THREE.Mesh(new THREE.CylinderGeometry(0.0036, 0.0036, 0.012, 14), rubber), car);
      roller.rotation.z = Math.PI / 2;
      roller.position.set(bx, bail.position.y, bail.position.z);
    }
    // return lever
    const lever = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.162, PRINT_Y + 0.004, platenZ),
      new THREE.Vector3(-0.198, PRINT_Y + 0.02, platenZ + 0.02),
      new THREE.Vector3(-0.208, PRINT_Y + 0.028, platenZ + 0.07),
    ]);
    add(new THREE.Mesh(new THREE.TubeGeometry(lever, 20, 0.0022, 8, false), chrome), car);
    const tip = add(new THREE.Mesh(new THREE.SphereGeometry(0.0042, 14, 10), chrome), car);
    tip.position.set(-0.208, PRINT_Y + 0.028, platenZ + 0.072);

    // paper wrap + leaning sheet (the source surface)
    const paperMat = new THREE.MeshStandardMaterial({
      color: 0xf3ead7,
      roughness: 0.92,
      metalness: 0,
      side: THREE.DoubleSide,
    });
    this.paperMaterial = paperMat;
    const wrap = add(
      new THREE.Mesh(new THREE.CylinderGeometry(PLATEN_R + 0.0005, PLATEN_R + 0.0005, TYPE.pageW * 0.96, 28, 1, true, -0.15, 1.7), paperMat),
      car,
    );
    wrap.rotation.z = Math.PI / 2;
    wrap.position.set(0, PRINT_Y, platenZ);
    const pose = this.sheetFrame();
    const sheet = add(new THREE.Mesh(new THREE.PlaneGeometry(TYPE.pageW, SHEET_LEN), paperMat), car);
    sheet.position.copy(pose.origin).addScaledVector(pose.up, SHEET_LEN / 2);
    sheet.quaternion.copy(pose.quat);
    sheet.receiveShadow = true;
  }

  paperMaterial!: THREE.MeshStandardMaterial;

  private brandMaterial() {
    const c = document.createElement("canvas");
    c.width = 512;
    c.height = 160;
    const g = c.getContext("2d")!;
    g.fillStyle = "#140f0a";
    g.fillRect(0, 0, 512, 160);
    g.strokeStyle = "#c6a15a";
    g.lineWidth = 6;
    g.strokeRect(10, 10, 492, 140);
    g.fillStyle = "#e4c78a";
    g.font = "600 46px Georgia, 'Times New Roman', serif";
    g.textAlign = "center";
    g.textBaseline = "middle";
    g.fillText("CONTINENTAL", 256, 68);
    g.font = "22px Georgia, serif";
    g.fillStyle = "#b89a62";
    g.fillText("Nº  5", 256, 112);
    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    return new THREE.MeshStandardMaterial({ map: tex, roughness: 0.45, metalness: 0.4 });
  }

  private legendTexture(chars: string) {
    const c = document.createElement("canvas");
    c.width = 8 * 64;
    c.height = 6 * 64;
    const ctx = c.getContext("2d")!;
    ctx.clearRect(0, 0, c.width, c.height);
    ctx.fillStyle = "#f4efe4";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.font = "bold 30px \"Special Elite\", Georgia, serif";
    [...chars].forEach((ch, i) => {
      const cx = (i % 8) * 64 + 32;
      const cy = Math.floor(i / 8) * 64 + 34;
      ctx.fillText(ch, cx, cy);
    });
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }

  /** Carriage-local frame of the visible sheet. Bottom-centre origin. */
  sheetFrame() {
    const up = new THREE.Vector3(0, Math.sin(SHEET_TILT), -Math.cos(SHEET_TILT));
    const normal = new THREE.Vector3(0, Math.cos(SHEET_TILT), Math.sin(SHEET_TILT));
    const right = new THREE.Vector3(1, 0, 0);
    const quat = new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(right, up, normal));
    const origin = new THREE.Vector3(0, PRINT_Y + PLATEN_R * 0.72, C.z - PLATEN_R * 0.85);
    return { up, normal, right, quat, origin };
  }

  static carriageFor(col: number) {
    return -(COL0_X + col * TYPE.cell);
  }

  /**
   * World pose of a character cell on the sheet, carriage at offset 0.
   * row 0 = the live line, just above the bail. Higher rows sit further up the page.
   */
  sheetGlyph(row: number, col: number) {
    const f = this.sheetFrame();
    const local = f.origin
      .clone()
      .addScaledVector(f.up, 0.012 + row * TYPE.line)
      .addScaledVector(f.right, COL0_X + col * TYPE.cell)
      .addScaledVector(f.normal, 0.00055);
    this.group.updateMatrixWorld(true);
    const world = this.group.localToWorld(local);
    const quat = this.group.quaternion.clone().multiply(f.quat);
    return { world, quat, normal: f.normal.clone().applyQuaternion(this.group.quaternion) };
  }

  carriageAxis() {
    return new THREE.Vector3(1, 0, 0).applyQuaternion(this.group.quaternion);
  }

  /** A point on the sheet the opening camera should read. */
  focusPoint() {
    return this.sheetGlyph(3, 16);
  }

  carriageX(t: number) {
    let x = Typewriter.carriageFor(0);
    for (const s of this.strokes) {
      const k = THREE.MathUtils.smoothstep(s.t + 0.02, s.t + 0.09, t);
      x -= TYPE.cell * k;
    }
    return x;
  }

  update(t: number) {
    this.carriage.position.x = this.carriageX(t);
    for (const b of this.bars) b.rotation.x = REST;
    this.keys.forEach((k) => {
      k.position.y = k.userData.y as number;
    });
    this.spaceBar.position.y = this.spaceBar.userData.y as number;
    this.ribbonVibe.position.y = this.ribbonVibe.userData.y as number;

    for (const s of this.strokes) {
      const dt = t - s.t;
      if (dt < -0.07 || dt > 0.18) continue;
      const raw = s.ch === " " ? " " : s.ch.toUpperCase();
      const press = dt < 0 ? 1 + dt / 0.07 : 1 - THREE.MathUtils.clamp((dt - 0.02) / 0.12, 0, 1);
      if (raw === " ") {
        this.spaceBar.position.y = (this.spaceBar.userData.y as number) - 0.0035 * press;
        continue;
      }
      const keyName = raw === "'" ? "'" : raw;
      const key = this.keys.get(keyName);
      if (key) key.position.y = (key.userData.y as number) - 0.0038 * press;
      const bi = this.barIndex.get(keyName);
      if (bi === undefined) continue;
      const up = dt < 0 ? (1 + dt / 0.07) ** 2 : 1 - THREE.MathUtils.smoothstep(dt, 0.0, 0.15);
      this.bars[bi].rotation.x = REST + (-STRIKE - REST) * up;
      this.ribbonVibe.position.y = (this.ribbonVibe.userData.y as number) + 0.003 * up;
    }
  }
}
