import * as THREE from "three";

/**
 * Glyph atlas.
 * Every particle stores an integer cell index; the vertex shader turns that
 * into a UV rectangle. The atlas is the only place characters are drawn —
 * a particle can never show a glyph that wasn't rasterised here, and it can
 * never appear unless a source cell on a page selected that index.
 *
 *   alpha = typewriter ink coverage (double-struck, slightly uneven)
 */

export const ATLAS_COLS = 16;
export const ATLAS_ROWS = 8;
export const CELL_PX = 128;

export const TYPEWRITER_FONT = `"Special Elite", "Courier New", Courier, monospace`;

export interface GlyphAtlas {
  texture: THREE.CanvasTexture;
  index: Map<string, number>;
  cols: number;
  rows: number;
}

export function buildGlyphAtlas(): GlyphAtlas {
  const w = ATLAS_COLS * CELL_PX;
  const h = ATLAS_ROWS * CELL_PX;
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d")!;
  ctx.clearRect(0, 0, w, h);

  const chars: string[] = [];
  for (let c = 32; c < 127; c++) chars.push(String.fromCharCode(c));

  ctx.textAlign = "center";
  ctx.textBaseline = "alphabetic";
  ctx.font = `86px ${TYPEWRITER_FONT}`;
  ctx.fillStyle = "#ffffff";

  const index = new Map<string, number>();
  const baseline = 98;
  chars.forEach((ch, i) => {
    const cx = (i % ATLAS_COLS) * CELL_PX + CELL_PX / 2;
    const cy = Math.floor(i / ATLAS_COLS) * CELL_PX + baseline;
    // Ribbon never lays down perfectly even ink.
    ctx.globalAlpha = 0.92;
    ctx.fillText(ch, cx, cy);
    ctx.globalAlpha = 0.45;
    ctx.fillText(ch, cx + 0.8, cy + 0.45);
    ctx.globalAlpha = 1;
    index.set(ch, i);
  });

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.NoColorSpace;
  texture.flipY = true;
  texture.magFilter = THREE.LinearFilter;
  texture.minFilter = THREE.LinearFilter;
  texture.generateMipmaps = false;
  texture.anisotropy = 8;
  texture.needsUpdate = true;
  return { texture, index, cols: ATLAS_COLS, rows: ATLAS_ROWS };
}

export function glyphIndex(atlas: GlyphAtlas, ch: string): number {
  return atlas.index.get(ch) ?? atlas.index.get("?") ?? 0;
}
