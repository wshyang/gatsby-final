/**
 * ============================================================================
 *  GATSBY — "After Gatsby's death, New York was haunted for me…"
 *  Timeline, typography, quote formation, palette.
 * ============================================================================
 *
 *  Every moving thing is a pure function of time (seconds), so the sequence
 *  can be scrubbed, paused and looped deterministically. These numbers are
 *  the single source of truth for the pacing.
 *
 *  PACING — taken from the reference clip (66.0–88.0) and reviews.txt:
 *
 *    reviews said "fable max" zoomed, panned and lifted too fast, and that its
 *    sea of letters was too sparse. "fable low" had the right camera / lift-off
 *    pace and the right sea-letter size; the blur-into-focus city was liked.
 *    "kalmia" and "opus" had the lift-off, the sea, and the word-by-word
 *    condensation right. "mimo" was wrong in how letters came together (a
 *    direct lerp, not a sea that then condenses). "opus" was the favourite
 *    overall, except the typewriter looked flat and untextured.
 *
 *  So: the desk is given a long, slow pull-back; every visible letter peels,
 *  hovers, then rises; the sea is dense but the glyphs stay modest on screen;
 *  words hesitate, then snap. The city is real 3D geometry plus a painting
 *  that racks from blur to sharp.
 */

export const TIMELINE = {
  duration: 36,

  fadeIn: [0.15, 1.7] as const,
  fadeOut: [33.8, 35.6] as const,

  /** The typewriter finishes the last phrase of the quote, on the page. */
  typingStart: 0.85,
  typingInterval: 0.15,

  /** First letter peels off the sheet in the machine. */
  liftStart: 4.5,
  /** The wave takes this long to cross the whole desk. */
  liftSpread: 6.6,
  /** Extra per-letter delay so pages don't peel in rigid rings. */
  liftJitter: 1.5,
  /** Fibres letting go — the letter curls a few millimetres off the page. */
  peel: 1.7,
  /** Suspension: nearly zero velocity, just above the paper. */
  hover: [0.45, 1.45] as const,
  /** Long glide from the page up into the sea. Slow in, slow out. */
  ascent: [6.6, 9.0] as const,

  /** Overhead pull-back. Very slow ease — reviews.txt. */
  cameraRise: [1.5, 13.6] as const,
  /** Blend from the desk pose into the oblique aerial. */
  cameraTilt: [10.6, 16.6] as const,

  deskFade: [11.2, 15.4] as const,
  cityFade: [10.6, 14.6] as const,
  /** Painting + skyline rack from soft to sharp (fable low's best idea). */
  cityFocus: [12.6, 19.4] as const,

  finalDissolve: [32.4, 34.6] as const,
};

/**  Pica-ish typewriter metrics, metres. Slightly open so the close-up reads. */
export const TYPE = {
  cell: 0.00315,
  line: 0.00515,
  /** Glyph quad edge on the page, as a multiple of the cell. */
  quad: 1.42,
  pageW: 0.216,
  pageH: 0.279,
  marginX: 0.02,
  marginTop: 0.02,
  columns: 52,
  /** Lines actually filled on a scattered page (keeps the sea dense, not a wall). */
  pageLines: 15,
};

export const VFOV = 36;
export const REF_ASPECT = 16 / 9;
/** Aerial pose used to lay out the sea and the quote. Tilt has finished by then. */
export const REF_TIME = 21.5;
export const QUOTE_DEPTH = 6.55;

export interface QuoteWord {
  text: string;
  /** Multiplier on the line's glyph height. */
  scale?: number;
  /** Seconds — letters leave the sea and condense onto this word. */
  arrive: number;
  /** Seconds — the word dissolves back into the sea. */
  leave: number;
}

export interface QuoteLine {
  words: QuoteWord[];
  /** Centre of the line in frame units (y = ±1 is the frame edge). */
  at: [number, number];
  depth?: number;
  /**
   * If set, these glyphs are taken 1:1 from a line physically typed on the
   * sheet in the machine (the "no spawning" rule, made visible).
   *  2 = "After Gatsby's death,"   1 = "New York was haunted"   0 = "for me..."
   */
  sheetLine?: 0 | 1 | 2;
}

export const QUOTE: QuoteLine[] = [
  {
    at: [0.0, 0.16],
    sheetLine: 2,
    words: [
      { text: "After", arrive: 17.7, leave: 28.6 },
      { text: "Gatsby's", arrive: 18.15, leave: 28.8 },
      { text: "death,", arrive: 18.6, leave: 29.1, scale: 1.08 },
    ],
  },
  {
    at: [0.0, -0.08],
    sheetLine: 1,
    words: [
      { text: "New", arrive: 20.15, leave: 29.3 },
      { text: "York", arrive: 20.5, leave: 29.45 },
      { text: "was", arrive: 20.85, leave: 29.6 },
      { text: "haunted", arrive: 21.25, leave: 29.9, scale: 1.06 },
    ],
  },
  {
    at: [0.58, -0.32],
    sheetLine: 0,
    words: [
      { text: "for", arrive: 23.15, leave: 30.2 },
      { text: "me...", arrive: 23.5, leave: 30.45 },
    ],
  },
  {
    at: [-0.22, 0.4],
    depth: 0.45,
    words: [
      { text: "distorted", arrive: 27.7, leave: 33.4 },
      { text: "beyond", arrive: 28.1, leave: 33.5 },
      { text: "my", arrive: 28.45, leave: 33.6 },
      { text: "eyes'", arrive: 28.75, leave: 33.7 },
    ],
  },
  {
    at: [0.42, 0.16],
    depth: 0.7,
    words: [
      { text: "power", arrive: 29.25, leave: 33.8 },
      { text: "of", arrive: 29.55, leave: 33.9 },
      { text: "correction.", arrive: 29.9, leave: 34.05, scale: 1.08 },
    ],
  },
];

/** Advance width of a quote glyph, as a fraction of its height. Wide enough that ink doesn't collide. */
export const QUOTE_ADVANCE = 0.66;
/** Gap between words, as a fraction of height. */
export const QUOTE_GAP = 0.46;
/** Seconds a word takes to condense — a short magnetic lock, not a long messy drift. */
export const CONDENSE = 1.15;
export const LETTER_STAGGER = 0.028;

/** The line the machine types live. Its glyphs are the last line of the quote. */
export const TYPED_LINE = "for me...";
/** Already on the sheet, above the live line — also quote members, 1:1. */
export const SHEET_LINE_HAUNTED = "New York was haunted";
export const SHEET_LINE_DEATH = "After Gatsby's death,";

export const PHASES = [
  { at: 0, id: "source", label: "I  ·  The Source", text: "Every character is ink sitting on a real sheet of paper." },
  { at: 4.5, id: "lift", label: "II  ·  Lift-off", text: "Letters peel from every visible page, hover, then rise." },
  { at: 10.6, id: "sea", label: "III  ·  The Sea", text: "A dense drift of type hangs in the fog as the city resolves." },
  { at: 17.8, id: "assemble", label: "IV  ·  Assembly", text: "Words condense out of the sea — none of them were spawned." },
  { at: 32.4, id: "fade", label: "V  ·  Dissolve", text: "The sentence falls back into the haunted air." },
] as const;

export function phaseAt(t: number) {
  let p: (typeof PHASES)[number] = PHASES[0];
  for (const ph of PHASES) if (t >= ph.at) p = ph;
  return p;
}

export const PALETTE = {
  ink: "#161310",
  airborne: "#f3eee6",
  quote: "#f7f3ec",
  gold: "#c6a36a",
  deskFog: "#100d0a",
  cityFog: "#24383e",
  warmBg: "#0c0907",
};

export const WORLD = {
  cityGround: -205,
};
