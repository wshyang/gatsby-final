import { useEffect, useRef, useState } from "react";
import { GatsbyScene, PHASES, SEQUENCE_SECONDS, type SceneStats } from "./gatsby/scene";

/** Make sure the typewriter webfont is ready before we rasterise the atlas. */
async function waitForFont() {
  try {
    await Promise.race([
      document.fonts.load('46px "Special Elite"'),
      new Promise((r) => setTimeout(r, 2500)),
    ]);
  } catch {
    /* fall back to Courier */
  }
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sceneRef = useRef<GatsbyScene | null>(null);
  const [ready, setReady] = useState(false);
  const [progress, setProgress] = useState(0);
  const [playing, setPlaying] = useState(true);
  const [stats, setStats] = useState<SceneStats>({ total: 0, onPaper: 0, inFlight: 0, settled: 0 });
  const [hud, setHud] = useState(true);

  useEffect(() => {
    let scene: GatsbyScene | null = null;
    let raf = 0;
    let cancelled = false;

    waitForFont().then(() => {
      if (cancelled || !canvasRef.current) return;
      scene = new GatsbyScene(canvasRef.current);
      sceneRef.current = scene;
      setReady(true);
      let last = 0;
      const poll = (now: number) => {
        if (!scene) return;
        if (now - last > 100) {
          last = now;
          setProgress(scene.progress);
          setPlaying(scene.playing);
          setStats(scene.stats());
        }
        raf = requestAnimationFrame(poll);
      };
      raf = requestAnimationFrame(poll);
    });

    return () => {
      cancelled = true;
      cancelAnimationFrame(raf);
      scene?.dispose();
    };
  }, []);

  const phase = [...PHASES].reverse().find((p) => progress >= p.at) ?? PHASES[0];
  const seconds = progress * SEQUENCE_SECONDS;

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-[#05070d] text-[#e8dcc0] select-none">
      <canvas ref={canvasRef} className="block h-full w-full" />

      {/* loading */}
      {!ready && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#05070d]">
          <p className="tracking-[0.4em] text-xs uppercase text-[#c9b27a] animate-pulse">Threading the ribbon…</p>
        </div>
      )}

      {/* top title bar */}
      <header className={`pointer-events-none absolute left-0 right-0 top-0 flex items-start justify-between p-6 transition-opacity duration-700 ${hud ? "opacity-100" : "opacity-0"}`}>
        <div>
          <p className="text-[10px] uppercase tracking-[0.45em] text-[#c9b27a]">WebGL · Instanced Particle Typography</p>
          <h1 className="deco mt-1 text-2xl font-light tracking-[0.25em] uppercase">The Great Gatsby</h1>
          <p className="mt-1 text-[11px] text-[#9a8f78]">Opening sequence study · 00:66 – 00:88</p>
        </div>
        <div className="text-right text-[11px] leading-5 text-[#9a8f78]">
          <p><span className="text-[#e8dcc0]">{stats.total.toLocaleString()}</span> typed characters</p>
          <p><span className="text-[#e8dcc0]">{stats.onPaper.toLocaleString()}</span> on paper</p>
          <p><span className="text-[#f5e6b8]">{stats.inFlight.toLocaleString()}</span> airborne</p>
          <p><span className="text-[#ffffff]">{stats.settled.toLocaleString()}</span> settled</p>
        </div>
      </header>

      {/* bottom controls */}
      <footer className={`absolute bottom-0 left-0 right-0 p-6 transition-opacity duration-700 ${hud ? "opacity-100" : "opacity-0 pointer-events-none"}`}>
        <div className="mx-auto max-w-5xl">
          <div className="mb-3 flex items-end justify-between gap-6">
            <div>
              <p className="deco text-sm tracking-[0.3em] uppercase text-[#c9b27a]">{phase.label}</p>
              <p className="mt-1 max-w-xl text-xs text-[#9a8f78]">{phase.blurb}</p>
            </div>
            <p className="font-mono text-xs tabular-nums text-[#9a8f78]">
              {seconds.toFixed(1).padStart(4, "0")}s / {SEQUENCE_SECONDS}s
            </p>
          </div>

          {/* scrubber with phase ticks */}
          <div className="relative">
            <div className="absolute inset-x-0 top-1/2 h-px -translate-y-1/2 bg-[#3a3326]" />
            <div className="absolute left-0 top-1/2 h-px -translate-y-1/2 bg-[#c9b27a]" style={{ width: `${progress * 100}%` }} />
            {PHASES.map((p) => (
              <button
                key={p.at}
                title={p.label}
                onClick={() => sceneRef.current?.seek(p.at)}
                className="absolute top-1/2 h-2 w-2 -translate-x-1/2 -translate-y-1/2 rotate-45 border border-[#c9b27a] bg-[#05070d] hover:bg-[#c9b27a]"
                style={{ left: `${p.at * 100}%` }}
              />
            ))}
            <input
              type="range"
              min={0}
              max={1000}
              value={Math.round(progress * 1000)}
              onChange={(e) => sceneRef.current?.seek(Number(e.target.value) / 1000)}
              className="relative z-10 h-6 w-full cursor-pointer appearance-none bg-transparent"
              aria-label="Timeline"
            />
          </div>

          <div className="mt-3 flex items-center gap-3 text-[11px] uppercase tracking-[0.25em]">
            <button
              onClick={() => { const s = sceneRef.current; if (!s) return; if (s.progress >= 1) s.restart(); else s.playing = !s.playing; }}
              className="border border-[#c9b27a]/60 px-4 py-1.5 hover:bg-[#c9b27a]/15"
            >
              {progress >= 1 ? "Replay" : playing ? "Pause" : "Play"}
            </button>
            <button onClick={() => sceneRef.current?.restart()} className="border border-[#3a3326] px-4 py-1.5 hover:border-[#c9b27a]/60">
              Restart
            </button>
            <span className="ml-auto text-[#5f574a]">press H to hide interface</span>
          </div>
        </div>
      </footer>

      <KeyHandler onToggleHud={() => setHud((h) => !h)} onSpace={() => { const s = sceneRef.current; if (s) s.playing = !s.playing; }} />
    </div>
  );
}

function KeyHandler({ onToggleHud, onSpace }: { onToggleHud: () => void; onSpace: () => void }) {
  useEffect(() => {
    const fn = (e: KeyboardEvent) => {
      if (e.key === "h" || e.key === "H") onToggleHud();
      if (e.key === " ") { e.preventDefault(); onSpace(); }
    };
    window.addEventListener("keydown", fn);
    return () => window.removeEventListener("keydown", fn);
  }, [onToggleHud, onSpace]);
  return null;
}
