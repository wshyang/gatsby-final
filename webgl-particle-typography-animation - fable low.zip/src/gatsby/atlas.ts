import * as THREE from "three";

/**
 * Glyph atlas
 * -----------
 * All characters are rasterised once into a grid texture. Each instanced
 * particle only stores an integer glyph index; the vertex shader converts
 * that index into the atlas cell UV rectangle.
 *
 *   R channel = sharp typewriter glyph (ink)
 *   G channel = blurred copy of the glyph (used as a soft glow in flight)
 */

export const ATLAS_COLS = 16;
export const ATLAS_ROWS = 8;
export const CELL_PX = 64;
/** font size in px used inside a cell – the glyph "em" */
export const FONT_PX = 46;
/** baseline y inside the cell (px from top) */
export const BASELINE_PX = 45;

export const TYPEWRITER_FONT = `"Special Elite", "Courier Prime", "Courier New", Courier, monospace`;

export interface GlyphAtlas {
  texture: THREE.Texture;
  /** char -> cell index */
  index: Map<string, number>;
  /** advance width of one character, in em units (monospace) */
  advanceEm: number;
}

const EXTRA = "’‘“”…—–·";

export function buildGlyphAtlas(): GlyphAtlas {
  const w = ATLAS_COLS * CELL_PX;
  const h = ATLAS_ROWS * CELL_PX;

  const chars: string[] = [];
  for (let c = 32; c < 127; c++) chars.push(String.fromCharCode(c));
  for (const c of EXTRA) chars.push(c);

  const sharp = document.createElement("canvas");
  sharp.width = w;
  sharp.height = h;
  const sc = sharp.getContext("2d")!;
  sc.fillStyle = "#000";
  sc.fillRect(0, 0, w, h);
  sc.font = `${FONT_PX}px ${TYPEWRITER_FONT}`;
  sc.textAlign = "center";
  sc.textBaseline = "alphabetic";
  sc.fillStyle = "#fff";

  const index = new Map<string, number>();
  chars.forEach((ch, i) => {
    const cx = (i % ATLAS_COLS) * CELL_PX + CELL_PX / 2;
    const cy = Math.floor(i / ATLAS_COLS) * CELL_PX + BASELINE_PX;
    // typewriter ink is never perfectly uniform – strike twice, slightly offset
    sc.globalAlpha = 0.85;
    sc.fillText(ch, cx, cy);
    sc.globalAlpha = 0.6;
    sc.fillText(ch, cx + 0.6, cy + 0.4);
    sc.globalAlpha = 1;
    index.set(ch, i);
  });

  // blurred copy for the glow channel
  const glow = document.createElement("canvas");
  glow.width = w;
  glow.height = h;
  const gc = glow.getContext("2d")!;
  gc.filter = "blur(5px)";
  gc.drawImage(sharp, 0, 0);

  // pack R = sharp, G = glow
  const sData = sc.getImageData(0, 0, w, h);
  const gData = gc.getImageData(0, 0, w, h);
  const out = sc.createImageData(w, h);
  for (let i = 0; i < out.data.length; i += 4) {
    out.data[i] = sData.data[i];
    out.data[i + 1] = Math.min(255, gData.data[i] * 1.6);
    out.data[i + 2] = 0;
    out.data[i + 3] = 255;
  }
  sc.putImageData(out, 0, 0);

  const texture = new THREE.CanvasTexture(sharp);
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.magFilter = THREE.LinearFilter;
  texture.generateMipmaps = true;
  texture.colorSpace = THREE.NoColorSpace;

  const advanceEm = sc.measureText("M").width / FONT_PX;

  return { texture, index, advanceEm: advanceEm || 0.6 };
}

/* ------------------------------------------------------------------ */
/* Procedural surface textures                                         */
/* ------------------------------------------------------------------ */

function rand(seed: number) {
  let s = seed;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

/** Aged cream paper. The glyphs themselves are NOT baked in – they are live particles. */
export function buildPaperTexture(seed = 1): THREE.Texture {
  const w = 512, h = 660;
  const c = document.createElement("canvas");
  c.width = w; c.height = h;
  const ctx = c.getContext("2d")!;
  const r = rand(seed * 977 + 13);

  ctx.fillStyle = "#e9dfc6";
  ctx.fillRect(0, 0, w, h);

  // fibre noise
  const img = ctx.getImageData(0, 0, w, h);
  for (let i = 0; i < img.data.length; i += 4) {
    const n = (r() - 0.5) * 18;
    img.data[i] += n; img.data[i + 1] += n; img.data[i + 2] += n * 0.8;
  }
  ctx.putImageData(img, 0, 0);

  // foxing / stains
  for (let i = 0; i < 14; i++) {
    const x = r() * w, y = r() * h, rad = 20 + r() * 90;
    const g = ctx.createRadialGradient(x, y, 0, x, y, rad);
    g.addColorStop(0, `rgba(150,110,60,${0.05 + r() * 0.08})`);
    g.addColorStop(1, "rgba(150,110,60,0)");
    ctx.fillStyle = g;
    ctx.fillRect(x - rad, y - rad, rad * 2, rad * 2);
  }
  // darkened edges
  const edge = ctx.createRadialGradient(w / 2, h / 2, h * 0.35, w / 2, h / 2, h * 0.75);
  edge.addColorStop(0, "rgba(90,60,20,0)");
  edge.addColorStop(1, "rgba(90,60,20,0.35)");
  ctx.fillStyle = edge;
  ctx.fillRect(0, 0, w, h);

  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

/** Dark walnut desk surface */
export function buildWoodTexture(): THREE.Texture {
  const w = 1024, h = 1024;
  const c = document.createElement("canvas");
  c.width = w; c.height = h;
  const ctx = c.getContext("2d")!;
  const r = rand(4242);
  ctx.fillStyle = "#2a1a10";
  ctx.fillRect(0, 0, w, h);
  for (let i = 0; i < 900; i++) {
    const y = r() * h;
    ctx.strokeStyle = `rgba(${60 + r() * 40},${30 + r() * 25},${12 + r() * 12},${0.15 + r() * 0.3})`;
    ctx.lineWidth = 1 + r() * 3;
    ctx.beginPath();
    ctx.moveTo(0, y);
    for (let x = 0; x <= w; x += 64) ctx.lineTo(x, y + Math.sin(x * 0.01 + i) * 6 * r());
    ctx.stroke();
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(3, 3);
  t.anisotropy = 8;
  return t;
}
