/**
 * Text content for the scene.
 *
 * PAGE_TEXTS  – what is physically typed on each sheet of paper. Every glyph
 *               the particle system will ever show is drawn from one of these
 *               pages (the "No spawning out of nowhere" rule).
 * QUOTE_LINES – the floating cinematic quote the glyphs assemble into.
 *
 * Passages are from F. Scott Fitzgerald's "The Great Gatsby" (1925, public domain).
 */

export const QUOTE_LINES: string[] = [
  "After Gatsby's death,",
  "New York was haunted",
  "for me...",
];

const PAGE_ONE = `                                                     - 178 -

     After Gatsby's death the East was haunted for me
like that, distorted beyond my eyes' power of correction.
So when the blue smoke of brittle leaves was in the air
and the wind blew the wet laundry stiff on the line I
decided to come back home.

     There was one thing to be done before I left, an
awkward, unpleasant thing that perhaps had better have
been let alone. But I wanted to leave things in order
and not just trust that obliging and indifferent sea to
sweep my refuse away. I saw Jordan Baker and talked over
and around what had happened to us together, and what
had happened afterward to me, and she lay perfectly
still, listening, in a big chair.

     She was dressed to play golf, and I remember
thinking she looked like a good illustration, her chin
raised a little jauntily, her hair the color of an
autumn leaf, her face the same brown tint as the
fingerless glove on her knee. When I had finished she
told me without comment that she was engaged to another
man. I doubted that, though there were several she could
have married at a nod of her head, but I pretended to be
surprised. For just a minute I wondered if I wasn't
making a mistake, then I thought it all over again
quickly and got up to say good-by.

     "Nevertheless you did throw me over," said Jordan
suddenly. "You threw me over on the telephone. I don't
give a damn about you now, but it was a new experience
for me, and I felt a little dizzy for a while."`;

const PAGE_TWO = `                                                       - 1 -

                        CHAPTER ONE

     In my younger and more vulnerable years my father
gave me some advice that I've been turning over in my
mind ever since.

     "Whenever you feel like criticizing any one," he
told me, "just remember that all the people in this
world haven't had the advantages that you've had."

     He didn't say any more, but we've always been
unusually communicative in a reserved way, and I
understood that he meant a great deal more than that.
In consequence, I'm inclined to reserve all judgments,
a habit that has opened up many curious natures to me
and also made me the victim of not a few veteran bores.
The abnormal mind is quick to detect and attach itself
to this quality when it appears in a normal person, and
so it came about that in college I was unjustly accused
of being a politician, because I was privy to the secret
griefs of wild, unknown men.

     Most of the confidences were unsought - frequently
I have feigned sleep, preoccupation, or a hostile levity
when I realized by some unmistakable sign that an
intimate revelation was quivering on the horizon; for
the intimate revelations of young men, or at least the
terms in which they express them, are usually
plagiaristic and marred by obvious suppressions.`;

const PAGE_THREE = `                                                     - 180 -

     Gatsby believed in the green light, the orgastic
future that year by year recedes before us. It eluded
us then, but that's no matter - tomorrow we will run
faster, stretch out our arms farther. . . . And one
fine morning -

     So we beat on, boats against the current, borne
back ceaselessly into the past.

     Most of the big shore places were closed now and
there were hardly any lights except the shadowy, moving
glow of a ferryboat across the Sound. And as the moon
rose higher the inessential houses began to melt away
until gradually I became aware of the old island here
that flowered once for Dutch sailors' eyes - a fresh,
green breast of the new world. Its vanished trees, the
trees that had made way for Gatsby's house, had once
pandered in whispers to the last and greatest of all
human dreams; for a transitory enchanted moment man
must have held his breath in the presence of this
continent, compelled into an aesthetic contemplation he
neither understood nor desired, face to face for the
last time in history with something commensurate to his
capacity for wonder.

     And as I sat there brooding on the old, unknown
world, I thought of Gatsby's wonder when he first picked
out the green light at the end of Daisy's dock.`;

/** The sheet still rolled into the typewriter – only partly typed. */
const PAGE_IN_MACHINE = `                                                     - 181 -

     New York was haunted for me, Doctor. I see it
now, the whole city, from a great height - the towers,
the lights, the endless parties, all of it distorted
beyond my eyes' power of correction. After Gatsby's
death I could not bear to stay. New York was`;

export const PAGE_TEXTS = [PAGE_ONE, PAGE_TWO, PAGE_THREE, PAGE_IN_MACHINE];
