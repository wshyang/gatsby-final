import { useCallback, useEffect, useRef, useState } from "react";
import { PHASES, TIMELINE } from "./gatsby/config";
import { GatsbyEngine, type EngineInfo } from "./gatsby/Engine";
import { cn } from "./utils/cn";

const fmt = (t: number) => `${Math.floor(t / 60)}:${Math.floor(t % 60).toString().padStart(2, "0")}.${Math.floor((t % 1) * 10)}`;

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GatsbyEngine | null>(null);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [time, setTime] = useState(0);
  const [playing, setPlaying] = useState(true);
  const [speed, setSpeed] = useState(1);
  const [trace, setTrace] = useState(false);
  const [notes, setNotes] = useState(false);
  const [idle, setIdle] = useState(false);
  const [info, setInfo] = useState<EngineInfo | null>(null);
  const idleTimer = useRef<number>(0);

  useEffect(() => {
    let disposed = false;
    let lastUi = 0;
    GatsbyEngine.create(canvasRef.current!)
      .then((e) => {
        if (disposed) return e.dispose();
        engineRef.current = e;
        (window as unknown as { __gatsby?: GatsbyEngine }).__gatsby = e; // debug / capture hook
        e.onTick = (t) => {
          const now = performance.now();
          if (now - lastUi > 60) {
            lastUi = now;
            setTime(t);
          }
        };
        setInfo(e.info);
        setReady(true);
      })
      .catch((err) => {
        console.error(err);
        setError(String(err?.message ?? err));
      });
    return () => {
      disposed = true;
      engineRef.current?.dispose();
      engineRef.current = null;
    };
  }, []);

  const poke = useCallback(() => {
    setIdle(false);
    window.clearTimeout(idleTimer.current);
    idleTimer.current = window.setTimeout(() => setIdle(true), 2800);
  }, []);
  useEffect(() => {
    poke();
    window.addEventListener("pointermove", poke);
    window.addEventListener("keydown", poke);
    return () => {
      window.removeEventListener("pointermove", poke);
      window.removeEventListener("keydown", poke);
    };
  }, [poke]);

  const togglePlay = useCallback(() => {
    const e = engineRef.current;
    if (!e) return;
    e.playing = !e.playing;
    setPlaying(e.playing);
  }, []);

  const restart = () => {
    const e = engineRef.current;
    if (!e) return;
    e.seek(0);
    e.playing = true;
    setPlaying(true);
  };

  useEffect(() => {
    const onKey = (ev: KeyboardEvent) => {
      if (ev.code === "Space") {
        ev.preventDefault();
        togglePlay();
      }
      if (ev.key === "r") restart();
      if (ev.key === "t") setTrace((v) => !v);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [togglePlay]);

  useEffect(() => engineRef.current?.setTrace(trace), [trace]);
  useEffect(() => {
    if (engineRef.current) engineRef.current.speed = speed;
  }, [speed]);

  const phase = [...PHASES].reverse().find((p) => time >= p.at) ?? PHASES[0];
  const hide = idle && playing && !notes;

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-black text-[#efe6d2] select-none" style={{ fontFamily: '"Special Elite", "Courier New", monospace' }}>
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" onClick={togglePlay} />

      {/* Loading */}
      <div className={cn("pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-4 bg-black transition-opacity duration-1000", ready ? "opacity-0" : "opacity-100")}>
        <div className="text-sm tracking-[0.5em] text-[#d9c9a3]/80 uppercase">{error ? "WebGL error" : "Threading the ribbon"}</div>
        {!error && (
          <div className="h-px w-48 overflow-hidden bg-white/10">
            <div className="h-full w-1/3 animate-[load_1.4s_ease-in-out_infinite] bg-[#d9b45b]" />
          </div>
        )}
        {error && <div className="max-w-md px-6 text-center text-xs text-red-300/80">{error}</div>}
      </div>

      {/* Title + phase */}
      <div className={cn("pointer-events-none absolute top-0 left-0 p-5 transition-opacity duration-700 sm:p-8", hide ? "opacity-0" : "opacity-100")}>
        <div className="text-[10px] tracking-[0.45em] text-[#d9b45b]/90 uppercase">The Great Gatsby · 2013</div>
        <div className="mt-1 text-lg tracking-wide text-[#f3ead6] sm:text-xl">Particle Typography</div>
        <div className="mt-5 max-w-xs">
          <div key={phase.label} className="animate-[fade_0.8s_ease-out] text-xs tracking-[0.25em] text-[#e9dcc0] uppercase">
            {phase.label}
          </div>
          <div key={phase.label + "t"} className="mt-1 animate-[fade_1.2s_ease-out] text-[11px] leading-relaxed text-[#e9dcc0]/60">
            {phase.text}
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className={cn("absolute inset-x-0 bottom-0 p-4 transition-all duration-700 sm:p-8", hide ? "translate-y-4 opacity-0" : "opacity-100")}>
        <div className="mx-auto max-w-4xl rounded-sm border border-white/10 bg-black/45 px-4 py-3 backdrop-blur-md">
          <div className="relative h-5">
            <input
              type="range"
              min={0}
              max={TIMELINE.duration}
              step={0.01}
              value={time}
              onChange={(e) => {
                engineRef.current?.seek(parseFloat(e.target.value));
                setTime(parseFloat(e.target.value));
              }}
              className="gatsby-range absolute inset-0 w-full"
              aria-label="Timeline"
            />
            {PHASES.map((p) => (
              <div key={p.at} className="pointer-events-none absolute top-0 h-1.5 w-px bg-[#d9b45b]/70" style={{ left: `${(p.at / TIMELINE.duration) * 100}%` }} />
            ))}
          </div>
          <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-2 text-[11px] tracking-[0.18em] uppercase">
            <button onClick={togglePlay} className="min-w-16 text-left text-[#f3ead6] hover:text-[#d9b45b]">
              {playing ? "❚❚ Pause" : "▶ Play"}
            </button>
            <button onClick={restart} className="text-[#e9dcc0]/70 hover:text-[#d9b45b]">
              ↺ Replay
            </button>
            <span className="text-[#e9dcc0]/50 tabular-nums">
              {fmt(time)} / {fmt(TIMELINE.duration)}
            </span>
            <div className="ml-auto flex items-center gap-4">
              <div className="flex items-center gap-1">
                {[0.5, 1, 1.5].map((s) => (
                  <button key={s} onClick={() => setSpeed(s)} className={cn("px-1.5 py-0.5", speed === s ? "bg-[#d9b45b] text-black" : "text-[#e9dcc0]/60 hover:text-[#e9dcc0]")}>
                    {s}×
                  </button>
                ))}
              </div>
              <button onClick={() => setTrace((v) => !v)} className={cn("hover:text-[#d9b45b]", trace ? "text-[#d9b45b]" : "text-[#e9dcc0]/70")}>
                {trace ? "◉" : "○"} Trace origins
              </button>
              <button onClick={() => setNotes((v) => !v)} className="text-[#e9dcc0]/70 hover:text-[#d9b45b]">
                ✎ Notes
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Notes drawer */}
      <aside
        className={cn(
          "absolute top-0 right-0 h-full w-full max-w-md overflow-y-auto border-l border-white/10 bg-[#0b0908]/92 p-7 text-[12.5px] leading-relaxed text-[#e9dcc0]/80 backdrop-blur-md transition-transform duration-500",
          notes ? "translate-x-0" : "translate-x-full",
        )}
        style={{ fontFamily: "Georgia, 'Times New Roman', serif" }}
      >
        <button onClick={() => setNotes(false)} className="absolute top-5 right-6 text-xl text-[#e9dcc0]/60 hover:text-white">
          ×
        </button>
        <h2 className="mb-1 text-[10px] tracking-[0.4em] text-[#d9b45b] uppercase" style={{ fontFamily: '"Special Elite", monospace' }}>
          How it works
        </h2>
        <h3 className="mb-4 text-xl text-[#f3ead6]" style={{ fontFamily: '"Special Elite", monospace' }}>
          No letter from nowhere
        </h3>
        {info && (
          <p className="mb-4 text-[#e9dcc0]/60">
            {info.glyphs.toLocaleString()} printed characters → {info.glyphs.toLocaleString()} particles, one instanced draw call. {info.members} of them form the quote.
          </p>
        )}
        <Section title="Data mapping">
          Every particle is a row in a static table: its <em>paper cell</em> (computed with the exact transform that places the sheet mesh), a <em>sea point</em> inside the camera frustum, and, for quote letters, a <em>slot</em>. Quote letters are matched to printed characters of the same glyph:
          “After Gatsby's death,” and “New York was haunted for me.” come 1:1 from the two lines on the sheet in the typewriter, one of which you watch being typed. Characters covered by another sheet or by the machine are culled, so nothing rises through paper. Toggle <b>Trace origins</b> to see the threads.
        </Section>
        <Section title="Cinematic pacing">
          Peel (1.5 s, ease-out) → hover (the suspension beat) → a 6–9 s double-smoothstep ascent → a bounded drift in the sea → a 2 s easeInOutQuint condense that hesitates, accelerates and <em>snaps</em>, with a lock-in flash and a tiny overshoot. Words lock left to right, 0.35–0.45 s apart, “death,” heavier and “haunted” swelling, following the reference clip’s 7.5 s / 8.5 s / 10.5 s beats. Earlier words dissolve back into the fog as the next phrase forms.
        </Section>
        <Section title="Lessons from reviews.txt">
          <ul className="list-disc space-y-1 pl-4">
            <li>fable max: the type-bar basket was rebuilt as a true pivot hierarchy, so every bar's slug meets the same printing point. The zoom-out, pan and lift-off are slower, every letter on every visible page lifts, and the sea is dense.</li>
            <li>fable low: kept its calm camera and lift-off pacing, its sea-letter size and its blur-to-focus city reveal.</li>
            <li>mimo: physically based chrome, lacquer, shadows and environment reflections give a photographic feel, with a real 3D typewriter and city. Letters condense like the film instead of tweening flatly.</li>
          </ul>
        </Section>
        <Section title="Rendering">
          The desk (with depth) and the 3D city render to separate targets with shared camera poses. The city racks focus through a separable blur. Glyphs depth-test manually against the desk and fake depth of field per letter with mip-biased multi-tap sampling. A final grade applies ACES, a warm-lamp-to-cold-teal split tone, vignette, grain and letterbox.
        </Section>
        <p className="mt-6 text-[11px] text-[#e9dcc0]/40">Space: play/pause · R: replay · T: trace origins · Click the frame to pause</p>
      </aside>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-5">
      <h4 className="mb-1.5 text-[10px] tracking-[0.3em] text-[#d9b45b]/90 uppercase" style={{ fontFamily: '"Special Elite", monospace' }}>
        {title}
      </h4>
      <div>{children}</div>
    </section>
  );
}
