import "@fontsource/special-elite";
import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import cityUrl from "../assets/city.jpg";
import deskUrl from "../assets/desk.jpg";
import { GlyphAtlas } from "./atlas";
import { cameraPose, referencePose, vfovFor } from "./camera";
import { City } from "./city";
import { QUOTE_DEPTH, TIMELINE } from "./config";
import { buildDesk, makePagePoses } from "./desk";
import { GlyphParticles } from "./glyphs";
import { buildGlyphBuffers } from "./mapping";
import { Typewriter } from "./typewriter";

/**
 * GatsbyEngine – owns the renderer, scenes, cameras and the render pipeline.
 *
 *  Render graph (per frame)
 *  ────────────────────────
 *   deskScene ─► rtDesk (colour + DEPTH texture) ─────────────┐
 *   cityScene ─► rtCity ─► ½-res separable blur ×2 ─► rtBlur ──┤
 *                                                              ▼
 *                  composite (city focus pull + desk dissolve) ─► rtComp
 *                  glyphs (instanced, occluded via rtDesk depth) ─► rtComp
 *                                                              ▼
 *                  grade (ACES, warm desk → cold teal city, vignette,
 *                         grain, letterbox, fades) ─► screen
 *
 *  The desk lives at metre scale (near 0.01 m) and the city at 200 m+ scale
 *  (near 2 m). Using two cameras that share one pose keeps depth precision
 *  perfect for both, and lets the glyphs depth-test against the desk only.
 */
const sstep = (a: number, b: number, x: number) => {
  const t = THREE.MathUtils.clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};

const quadVert = /* glsl */ `varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }`;

export interface EngineInfo {
  glyphs: number;
  members: number;
}

export class GatsbyEngine {
  readonly renderer: THREE.WebGLRenderer;
  readonly info: EngineInfo;
  time = 0;
  playing = true;
  speed = 1;
  onTick?: (t: number) => void;

  private deskScene = new THREE.Scene();
  private glyphScene = new THREE.Scene();
  private camDesk = new THREE.PerspectiveCamera(40, 1, 0.01, 80);
  private camCity = new THREE.PerspectiveCamera(40, 1, 2, 12000);
  private city: City;
  private tw: Typewriter;
  private glyphs: GlyphParticles;
  private trace: THREE.LineSegments;
  private rtDesk!: THREE.WebGLRenderTarget;
  private rtCity!: THREE.WebGLRenderTarget;
  private rtA!: THREE.WebGLRenderTarget;
  private rtB!: THREE.WebGLRenderTarget;
  private rtComp!: THREE.WebGLRenderTarget;
  private quadScene = new THREE.Scene();
  private quadCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  private quad: THREE.Mesh;
  private blurMat: THREE.ShaderMaterial;
  private compMat: THREE.ShaderMaterial;
  private gradeMat: THREE.ShaderMaterial;
  private raf = 0;
  private last = 0;
  private ro: ResizeObserver;
  private ref = referencePose();

  static async create(canvas: HTMLCanvasElement) {
    await Promise.all([document.fonts.load('64px "Special Elite"'), document.fonts.ready]);
    const loader = new THREE.TextureLoader();
    const [desk, city] = await Promise.all([loader.loadAsync(deskUrl), loader.loadAsync(cityUrl)]);
    return new GatsbyEngine(canvas, desk, city);
  }

  private constructor(private canvas: HTMLCanvasElement, deskTex: THREE.Texture, cityTex: THREE.Texture) {
    const r = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: "high-performance" });
    r.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
    r.shadowMap.enabled = true;
    r.shadowMap.type = THREE.PCFShadowMap;
    r.outputColorSpace = THREE.LinearSRGBColorSpace;
    r.toneMapping = THREE.NoToneMapping;
    r.autoClear = false;
    this.renderer = r;

    // ---- desk scene --------------------------------------------------------
    this.deskScene.background = new THREE.Color(0x070504);
    const pmrem = new THREE.PMREMGenerator(r);
    this.deskScene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    this.deskScene.environmentIntensity = 0.4;
    const pages = makePagePoses();
    buildDesk(this.deskScene, deskTex, pages);
    this.tw = new Typewriter(new THREE.Vector3(-0.215, 0, -0.105), 0.1);
    this.deskScene.add(this.tw.group);

    // ---- city --------------------------------------------------------------
    this.city = new City(cityTex);

    // ---- glyphs: build the paper → sea → quote table and the instanced mesh -----
    const atlas = new GlyphAtlas("Special Elite");
    const inv = this.tw.group.matrixWorld.clone().invert();
    const v = new THREE.Vector3();
    const footprint = (p: THREE.Vector3) => {
      v.copy(p).applyMatrix4(inv);
      return Math.abs(v.x) < 0.168 && v.z > -0.14 && v.z < 0.195;
    };
    const B = buildGlyphBuffers(atlas, pages, this.tw, footprint);
    this.info = { glyphs: B.count, members: B.members };
    this.glyphs = new GlyphParticles(B, atlas);
    this.glyphScene.add(this.glyphs.mesh);
    const u = this.glyphs.material.uniforms;
    u.uCarriageAxis.value.copy(this.tw.carriageAxis());
    u.uRefQuat.value.set(this.ref.quaternion.x, this.ref.quaternion.y, this.ref.quaternion.z, this.ref.quaternion.w);
    u.uRefPos.value.copy(this.ref.position);

    // debug overlay: a thread from every quote letter's paper cell to its slot
    const endCarriage = this.tw.carriageX(1e3);
    const axis = this.tw.carriageAxis();
    const pts: number[] = [];
    for (const l of B.links) {
      const f = l.from.clone().addScaledVector(axis, l.carriage ? endCarriage : 0);
      pts.push(f.x, f.y, f.z, l.to.x, l.to.y, l.to.z);
    }
    const lg = new THREE.BufferGeometry();
    lg.setAttribute("position", new THREE.Float32BufferAttribute(pts, 3));
    this.trace = new THREE.LineSegments(lg, new THREE.LineBasicMaterial({ color: 0xe0b860, transparent: true, opacity: 0.45, depthTest: false }));
    this.trace.visible = false;
    this.trace.frustumCulled = false;
    this.glyphScene.add(this.trace);

    // ---- post materials -----------------------------------------------------
    this.blurMat = new THREE.ShaderMaterial({
      uniforms: { tInput: { value: null }, uDir: { value: new THREE.Vector2() } },
      vertexShader: quadVert,
      fragmentShader: /* glsl */ `
        uniform sampler2D tInput; uniform vec2 uDir; varying vec2 vUv;
        void main(){
          vec3 c = texture2D(tInput, vUv).rgb * 0.227;
          c += (texture2D(tInput, vUv + uDir * 1.385).rgb + texture2D(tInput, vUv - uDir * 1.385).rgb) * 0.316;
          c += (texture2D(tInput, vUv + uDir * 3.231).rgb + texture2D(tInput, vUv - uDir * 3.231).rgb) * 0.070;
          gl_FragColor = vec4(c, 1.0);
        }`,
      depthTest: false,
      depthWrite: false,
    });
    this.compMat = new THREE.ShaderMaterial({
      uniforms: {
        tDesk: { value: null },
        tCity: { value: null },
        tBlur: { value: null },
        uDesk: { value: 1 },
        uCity: { value: 0 },
        uBlur: { value: 1 },
      },
      vertexShader: quadVert,
      fragmentShader: /* glsl */ `
        uniform sampler2D tDesk, tCity, tBlur; uniform float uDesk, uCity, uBlur; varying vec2 vUv;
        void main(){
          vec3 city = mix(texture2D(tCity, vUv).rgb, texture2D(tBlur, vUv).rgb, uBlur) * uCity;
          vec3 desk = texture2D(tDesk, vUv).rgb;
          gl_FragColor = vec4(mix(city, desk, uDesk), 1.0);
        }`,
      depthTest: false,
      depthWrite: false,
    });
    this.gradeMat = new THREE.ShaderMaterial({
      uniforms: {
        tComp: { value: null },
        uTime: { value: 0 },
        uFade: { value: 0 },
        uCity: { value: 0 },
        uBars: { value: 0 },
        uRes: { value: new THREE.Vector2() },
      },
      vertexShader: quadVert,
      fragmentShader: /* glsl */ `
        uniform sampler2D tComp; uniform float uTime, uFade, uCity, uBars; uniform vec2 uRes; varying vec2 vUv;
        vec3 aces(vec3 x){ return clamp((x*(2.51*x+0.03))/(x*(2.43*x+0.59)+0.14), 0.0, 1.0); }
        float hash(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
        void main(){
          vec3 c = texture2D(tComp, vUv).rgb * mix(1.35, 1.25, uCity);
          c = aces(c);
          float l = dot(c, vec3(0.299, 0.587, 0.114));
          vec3 warm = c * vec3(1.06, 0.97, 0.84);                          // lamp-lit desk
          vec3 cool = mix(vec3(l), c, 0.72) * vec3(0.9, 1.0, 1.05);         // cold teal city
          c = mix(warm, cool, uCity);
          c += vec3(0.006, 0.012, 0.016) * uCity;                          // lifted, teal blacks
          vec2 q = (vUv - 0.5) * vec2(1.0, 1.2);
          c *= clamp(1.0 - dot(q, q) * 1.15, 0.0, 1.0);
          c = pow(max(c, 0.0), vec3(1.0 / 2.2));
          c += (hash(vUv * uRes + fract(uTime * 7.13) * 100.0) - 0.5) * 0.045;   // film grain
          c *= uFade;
          if (vUv.y < uBars || vUv.y > 1.0 - uBars) c = vec3(0.0);
          gl_FragColor = vec4(c, 1.0);
        }`,
      depthTest: false,
      depthWrite: false,
    });
    this.quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), this.blurMat);
    this.quad.frustumCulled = false;
    this.quadScene.add(this.quad);

    this.resize();
    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(canvas);
    this.last = performance.now();
    this.loop();
  }

  /* ------------------------------------------------------------------ */
  private makeTargets(w: number, h: number) {
    [this.rtDesk, this.rtCity, this.rtA, this.rtB, this.rtComp].forEach((t) => t?.dispose());
    const opts = { type: THREE.HalfFloatType, colorSpace: THREE.LinearSRGBColorSpace };
    const depthTexture = new THREE.DepthTexture(w, h, THREE.UnsignedIntType);
    this.rtDesk = new THREE.WebGLRenderTarget(w, h, { ...opts, depthTexture, depthBuffer: true });
    this.rtCity = new THREE.WebGLRenderTarget(w, h, { ...opts, samples: 4 });
    const hw = Math.max(1, Math.floor(w / 2));
    const hh = Math.max(1, Math.floor(h / 2));
    this.rtA = new THREE.WebGLRenderTarget(hw, hh, { ...opts, depthBuffer: false });
    this.rtB = new THREE.WebGLRenderTarget(hw, hh, { ...opts, depthBuffer: false });
    this.rtComp = new THREE.WebGLRenderTarget(w, h, { ...opts, depthBuffer: false });
  }

  resize() {
    const w = this.canvas.clientWidth || window.innerWidth;
    const h = this.canvas.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false);
    const size = this.renderer.getDrawingBufferSize(new THREE.Vector2());
    this.makeTargets(size.x, size.y);
    const aspect = w / h;
    for (const c of [this.camDesk, this.camCity]) {
      c.aspect = aspect;
      c.fov = vfovFor(aspect);
      c.updateProjectionMatrix();
    }
    this.glyphs.material.uniforms.uRes.value.set(size.x, size.y);
    this.glyphs.material.uniforms.uResY.value = size.y;
    this.gradeMat.uniforms.uRes.value.set(size.x, size.y);
    this.gradeMat.uniforms.uBars.value = Math.min(0.12, Math.max(0, (1 - aspect / 2.2) / 2));
    this.renderFrame();
  }

  /* ------------------------------------------------------------------ */
  private loop = () => {
    this.raf = requestAnimationFrame(this.loop);
    const now = performance.now();
    const dt = Math.min((now - this.last) / 1000, 0.1);
    this.last = now;
    if (this.playing) {
      this.time += dt * this.speed;
      if (this.time > TIMELINE.duration) this.time = 0;
    }
    this.renderFrame();
    this.onTick?.(this.time);
  };

  seek(t: number) {
    this.time = THREE.MathUtils.clamp(t, 0, TIMELINE.duration);
  }

  setTrace(on: boolean) {
    this.trace.visible = on;
  }

  private pass(mat: THREE.ShaderMaterial, target: THREE.WebGLRenderTarget | null) {
    this.quad.material = mat;
    this.renderer.setRenderTarget(target);
    this.renderer.render(this.quadScene, this.quadCam);
  }

  private renderFrame() {
    const t = this.time;
    const r = this.renderer;
    const T = TIMELINE;

    // ---- timeline-driven scalars ------------------------------------------
    const deskFade = 1 - sstep(T.deskFade[0], T.deskFade[1], t);
    const cityFade = sstep(T.cityFade[0], T.cityFade[1], t);
    const blur = 1 - sstep(T.cityFocus[0], T.cityFocus[1], t);
    const tilt = sstep(T.cameraTilt[0], T.cameraTilt[1], t);
    const fade = sstep(T.fadeIn[0], T.fadeIn[1], t) * (1 - sstep(T.fadeOut[0], T.fadeOut[1], t));

    // ---- cameras ---------------------------------------------------------------
    cameraPose(t, this.camDesk.position, this.camDesk.quaternion);
    this.camDesk.updateMatrixWorld();
    this.camCity.quaternion.copy(this.camDesk.quaternion);
    // The city camera drifts at helicopter scale so the skyline parallaxes.
    const drift = Math.max(0, t - 10);
    this.camCity.position.copy(this.camDesk.position).add(new THREE.Vector3(drift * 3.2, 90 + drift * 0.6, 140 - drift * 5.5));
    this.camCity.updateMatrixWorld();

    // ---- scene updates ---------------------------------------------------------
    this.tw.update(t);
    this.city.update(t, this.camCity);
    const u = this.glyphs.material.uniforms;
    u.uTime.value = t;
    u.uCarriageX.value = this.tw.carriageX(t);
    const deskFocus = this.camDesk.position.y;
    u.uFocus.value = THREE.MathUtils.lerp(deskFocus, QUOTE_DEPTH, tilt);
    u.uFocusRange.value = THREE.MathUtils.lerp(deskFocus * 0.45, 3.4, tilt);
    u.uDeskFade.value = deskFade;
    u.uEnd.value = sstep(T.finalDissolve[0], T.finalDissolve[1], t);
    u.uSeaDim.value = 1 - 0.2 * sstep(11, 14, t) - 0.32 * sstep(15.5, 17.5, t);
    u.uDeskDepth.value = this.rtDesk.depthTexture;
    u.uNear.value = this.camDesk.near;
    u.uFar.value = this.camDesk.far;

    // ---- 1. desk ---------------------------------------------------------------
    r.setRenderTarget(this.rtDesk);
    r.clear(true, true, true);
    if (deskFade > 0.001) r.render(this.deskScene, this.camDesk);

    // ---- 2. city + focus-pull blur ------------------------------------------------
    r.setRenderTarget(this.rtCity);
    r.clear(true, true, true);
    if (cityFade > 0.001) {
      r.render(this.city.scene, this.camCity);
      const bu = this.blurMat.uniforms;
      const px = 1 / this.rtA.width;
      const py = 1 / this.rtA.height;
      const rad = 0.6 + 2.6 * blur;
      bu.tInput.value = this.rtCity.texture;
      bu.uDir.value.set(px * rad, 0);
      this.pass(this.blurMat, this.rtA);
      bu.tInput.value = this.rtA.texture;
      bu.uDir.value.set(0, py * rad);
      this.pass(this.blurMat, this.rtB);
      bu.tInput.value = this.rtB.texture;
      bu.uDir.value.set(px * rad * 2.2, 0);
      this.pass(this.blurMat, this.rtA);
      bu.tInput.value = this.rtA.texture;
      bu.uDir.value.set(0, py * rad * 2.2);
      this.pass(this.blurMat, this.rtB);
    }

    // ---- 3. composite + glyphs ------------------------------------------------------
    const cu = this.compMat.uniforms;
    cu.tDesk.value = this.rtDesk.texture;
    cu.tCity.value = this.rtCity.texture;
    cu.tBlur.value = this.rtB.texture;
    cu.uDesk.value = deskFade;
    cu.uCity.value = cityFade;
    cu.uBlur.value = Math.min(1, blur * 1.15);
    this.pass(this.compMat, this.rtComp);
    r.setRenderTarget(this.rtComp);
    r.render(this.glyphScene, this.camDesk);

    // ---- 4. grade → screen --------------------------------------------------------
    const gu = this.gradeMat.uniforms;
    gu.tComp.value = this.rtComp.texture;
    gu.uTime.value = t;
    gu.uFade.value = fade;
    gu.uCity.value = sstep(9.8, 13.5, t);
    r.setRenderTarget(null);
    r.clear(true, true, true);
    this.pass(this.gradeMat, null);
  }

  dispose() {
    cancelAnimationFrame(this.raf);
    this.ro.disconnect();
    [this.rtDesk, this.rtCity, this.rtA, this.rtB, this.rtComp].forEach((t) => t.dispose());
    this.renderer.dispose();
  }
}
