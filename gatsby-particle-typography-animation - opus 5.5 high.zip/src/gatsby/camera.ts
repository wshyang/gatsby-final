import * as THREE from "three";
import { TIMELINE } from "./config";

/**
 * Camera rig – a pure function of time.
 *
 *  Overhead pose  : straight down on the desk, rising from 0.6 m to 2.9 m with
 *                   a *very* slow sine ease (reviews.txt: fable max zoomed out
 *                   and panned too fast) plus the slight clockwise roll the film
 *                   has during its pull-up.
 *  Aerial pose    : oblique view (≈13° down) over the city, drifting gently
 *                   right/forward so the floating quote slides left in frame
 *                   like in the reference clip.
 *  The two are blended over TIMELINE.cameraTilt (smootherstep on position,
 *  slerp on orientation) while the desk dissolves into the city.
 */
const ease = (x: number) => 0.5 - 0.5 * Math.cos(Math.PI * THREE.MathUtils.clamp(x, 0, 1));
const smoother = (x: number) => {
  const c = THREE.MathUtils.clamp(x, 0, 1);
  return c * c * c * (c * (c * 6 - 15) + 10);
};
const span = (t: number, r: readonly [number, number]) => (t - r[0]) / (r[1] - r[0]);

const X = new THREE.Vector3(1, 0, 0);
const Y = new THREE.Vector3(0, 1, 0);
const qa = new THREE.Quaternion();
const qb = new THREE.Quaternion();

export const BASE_VFOV = 40;
export const REF_ASPECT = 16 / 9;
/** Time whose aerial pose is used to lay out the sea of letters and the quote. */
export const REF_TIME = 19;

function overhead(t: number, pos: THREE.Vector3, quat: THREE.Quaternion) {
  const k = ease(span(t, TIMELINE.cameraRise));
  const breathe = Math.sin(t * 0.45) * 0.004;
  pos.set(THREE.MathUtils.lerp(-0.06, 0.0, k), THREE.MathUtils.lerp(0.64, 2.9, k) + breathe, THREE.MathUtils.lerp(-0.12, 0.08, k));
  const roll = THREE.MathUtils.lerp(0.06, -0.12, ease(span(t, [0, 14])));
  quat.setFromAxisAngle(Y, roll).multiply(qa.setFromAxisAngle(X, -Math.PI / 2));
}

export function aerial(t: number, pos: THREE.Vector3, quat: THREE.Quaternion) {
  const d = t - 16;
  pos.set(0.05 * d, 3.2 - 0.004 * d, 1.0 - 0.035 * d);
  const yaw = -0.07 + 0.0035 * d;
  const pitch = -0.13 + 0.001 * d;
  quat.setFromAxisAngle(Y, yaw).multiply(qa.setFromAxisAngle(X, pitch));
}

export function cameraPose(t: number, pos: THREE.Vector3, quat: THREE.Quaternion) {
  const w = smoother(span(t, TIMELINE.cameraTilt));
  const p1 = new THREE.Vector3();
  const p2 = new THREE.Vector3();
  overhead(t, p1, quat);
  aerial(t, p2, qb);
  pos.lerpVectors(p1, p2, w);
  quat.slerp(qb, w);
}

/** Vertical FOV that keeps the horizontal framing of a 16:9 frame on narrow screens. */
export function vfovFor(aspect: number) {
  if (aspect >= REF_ASPECT) return BASE_VFOV;
  const h = Math.tan(THREE.MathUtils.degToRad(BASE_VFOV / 2)) * REF_ASPECT;
  return THREE.MathUtils.radToDeg(2 * Math.atan(h / aspect));
}

/** Reference pose shared by the particle mapping and the shader. */
export function referencePose() {
  const position = new THREE.Vector3();
  const quaternion = new THREE.Quaternion();
  aerial(REF_TIME, position, quaternion);
  const tanHalf = Math.tan(THREE.MathUtils.degToRad(BASE_VFOV / 2));
  /** frame units (fx, fy) at depth d → world */
  const frameToWorld = (fx: number, fy: number, d: number) =>
    new THREE.Vector3(fx * tanHalf * d, fy * tanHalf * d, -d).applyQuaternion(quaternion).add(position);
  return { position, quaternion, tanHalf, frameToWorld };
}
