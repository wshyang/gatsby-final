import * as THREE from "three";
import { GlyphAtlas } from "./atlas";
import { REF_ASPECT, referencePose } from "./camera";
import { QUOTE, QUOTE_DEPTH, TIMELINE, TYPE, TYPED_LINE } from "./config";
import type { PagePose } from "./desk";
import { PASSAGES, SHEET_PASSAGE, rng, wrap } from "./texts";
import { Typewriter } from "./typewriter";

/**
 * ============================================================================
 *  DATA MAPPING  —  paper source position  →  sea of letters  →  quote slot
 * ============================================================================
 *
 *  The effect is a static table built once on the CPU. ONE ROW = ONE
 *  CHARACTER THAT IS PHYSICALLY PRINTED ON A SHEET OF PAPER. The GPU never
 *  invents a position: the vertex shader only evaluates curves between the
 *  points stored here, so every airborne letter can be traced back to the
 *  exact cell it was typed in ("no spawning out of nowhere").
 *
 *    1. SOURCE   aOrigin / aOriginQuat
 *         world position + orientation of the character cell on its sheet,
 *         computed with the very same transform that places the paper mesh
 *         (PagePose for desk pages, Typewriter.sheetGlyph for the sheet in the
 *         machine – those also slide with the carriage via aGrow.z).
 *         Characters hidden under another sheet or under the typewriter are
 *         culled, so nothing ever rises *through* paper.
 *
 *    2. SEA      aSea
 *         a resting point inside the reference camera frustum (depth 0.7–17 m),
 *         sized so all letters read as similar small "snowflakes" on screen
 *         (fable low's sea-letter size, but far denser – reviews.txt said the
 *         fable max sea was too sparse). The shader adds a slow drift.
 *
 *    3. QUOTE    aSlotA / aSlotB  (members only)
 *         each non-space quote character is matched to a printed character
 *         with the SAME glyph. "After Gatsby's death," and "New York was haunted
 *         for me." are mapped 1:1 from the two lines on the sheet in the
 *         typewriter (one of them typed live in the opening); the rest are
 *         harvested from the sheets nearest the machine. SlotB is the pose
 *         after a word "grows" (the film's "haunted" beat).
 *
 *    TIMING  aTime0 = (appear, lift, hover, ascent)
 *            aTime1 = (arrive, condenseDuration, leave, isMember)
 *         lift time = a radial wave starting at the typewriter + jitter, so
 *         ALL letters on ALL visible pages lift off (reviews.txt), slowly.
 * ============================================================================
 */

export interface GlyphBuffers {
  count: number;
  origin: Float32Array; // vec3
  originQuat: Float32Array; // vec4
  sea: Float32Array; // vec3
  slotA: Float32Array; // vec3
  slotB: Float32Array; // vec3
  glyph: Float32Array; // vec2 atlas uv origin
  time0: Float32Array; // vec4
  time1: Float32Array; // vec4
  grow: Float32Array; // vec3 (growStart, growDur, carriage)
  size: Float32Array; // vec4 (paper, sea, slotA, slotB)
  seed: Float32Array; // vec4
  /** For the debug "trace" overlay: origin → slot of every quote letter. */
  links: { from: THREE.Vector3; to: THREE.Vector3; carriage: boolean }[];
  members: number;
}

interface Source {
  ch: string;
  pos: THREE.Vector3;
  quat: THREE.Quaternion;
  carriage: boolean;
  appear: number;
  /** "prev" / "typed" line index for 1:1 mapping, or -1. */
  line: -1 | 0 | 1;
  col: number;
}

interface Slot {
  ch: string;
  bold: boolean;
  a: THREE.Vector3;
  b: THREE.Vector3;
  sizeA: number;
  sizeB: number;
  arrive: number;
  leave: number;
  growAt: number;
  growDur: number;
  lineSource: -1 | 0 | 1;
  col: number;
}

/* -------------------------------------------------------------------------- */
/* 1. Sources: every printed character on every sheet                          */
/* -------------------------------------------------------------------------- */
function collectSources(pages: PagePose[], tw: Typewriter, twFootprint: (p: THREE.Vector3) => boolean): Source[] {
  const out: Source[] = [];
  const cols = Math.floor((TYPE.pageW - 2 * TYPE.marginX) / TYPE.cell);
  const rows = Math.floor((TYPE.pageH - 2 * TYPE.marginTop) / TYPE.line);
  const tmp = new THREE.Vector3();

  // (a) the sheet in the typewriter
  const prev = wrap(SHEET_PASSAGE, cols).slice(0, 30).reverse(); // row 3 = last line of the paragraph
  for (const { row, text } of Typewriter.sheetLines(prev)) {
    [...text].forEach((ch, col) => {
      if (ch === " ") return;
      const g = tw.sheetGlyph(row, col);
      out.push({ ch, pos: g.world, quat: g.quat, carriage: true, appear: -1, line: row === 1 ? 0 : -1, col });
    });
  }
  [...TYPED_LINE].forEach((ch, col) => {
    if (ch === " ") return;
    const g = tw.sheetGlyph(0, col);
    out.push({ ch, pos: g.world, quat: g.quat, carriage: true, appear: tw.strokes[col].t, line: 1, col });
  });

  // (b) the scattered desk pages – the paragraph flow continues page to page
  pages.forEach((p, k) => {
    const lines: string[] = [];
    let pi = p.textOffset;
    while (lines.length < rows) {
      lines.push(...wrap(PASSAGES[pi % PASSAGES.length], cols), "");
      pi++;
    }
    const used = Math.floor(rows * p.fill);
    for (let r = 0; r < used; r++) {
      const text = lines[r];
      for (let c = 0; c < text.length; c++) {
        const ch = text[c];
        if (ch === " ") continue;
        // page-local → world, using the exact PagePose that places the mesh
        const lx = -p.width / 2 + TYPE.marginX + (c + 0.5) * TYPE.cell;
        const ly = p.height / 2 - TYPE.marginTop - r * TYPE.line;
        const world = new THREE.Vector3(lx, ly, 0.00045).applyQuaternion(p.quaternion).add(p.position);
        // cull characters hidden under a sheet placed above this one, or under the machine
        let covered = twFootprint(world);
        for (let j = k + 1; j < pages.length && !covered; j++) {
          tmp.copy(world).applyMatrix4(pages[j].inverse);
          covered = Math.abs(tmp.x) < pages[j].width / 2 + 0.002 && Math.abs(tmp.y) < pages[j].height / 2 + 0.002;
        }
        if (!covered) out.push({ ch, pos: world, quat: p.quaternion.clone(), carriage: false, appear: -1, line: -1, col: c });
      }
    }
  });
  return out;
}

/* -------------------------------------------------------------------------- */
/* 2. Quote slots in world space                                               */
/* -------------------------------------------------------------------------- */
function layoutQuote(atlas: GlyphAtlas): Slot[] {
  const ref = referencePose();
  const slots: Slot[] = [];
  let prevCol = 0;
  let typedCol = 0;
  for (const line of QUOTE) {
    const space = atlas.adv(" ") * line.words[0].size;
    const widths = line.words.map((w) => [...w.text].reduce((s, ch) => s + atlas.adv(ch) * w.size, 0));
    const total = widths.reduce((a, b) => a + b, 0) + space * (line.words.length - 1);
    let pen = line.at[0] - total / 2;
    const depth = QUOTE_DEPTH + (line.depth ?? 0);
    line.words.forEach((w, wi) => {
      // where this word sits after a "grow" (centre moves to w.grow.to, scaled)
      const centerA = pen + widths[wi] / 2;
      let x = pen;
      // The first quote line + "for me." are exactly the two lines on the typewriter sheet.
      const wordSource: -1 | 0 | 1 = line === QUOTE[0] && wi < 3 ? 0 : (line === QUOTE[0] && wi >= 3) || line === QUOTE[1] ? 1 : -1;
      for (const ch of w.text) {
        const adv = atlas.adv(ch) * w.size;
        const cx = x + adv / 2;
        const cy = line.at[1] + 0.14 * w.size; // atlas baseline sits 0.14 quad below the cell centre
        let bx = cx;
        let by = cy;
        let sizeB = w.size;
        if (w.grow) {
          bx = w.grow.to[0] + (cx - centerA) * w.grow.scale;
          by = w.grow.to[1] + 0.14 * w.size * w.grow.scale;
          sizeB = w.size * w.grow.scale;
        }
        // sources: the two lines on the typewriter sheet map 1:1 by column
        const lineSource = wordSource;
        const col = lineSource === 0 ? prevCol++ : lineSource === 1 ? typedCol++ : -1;
        if (ch !== " ") {
          slots.push({
            ch,
            bold: !!w.bold,
            a: ref.frameToWorld(cx, cy, depth),
            b: ref.frameToWorld(bx, by, depth - (w.grow ? 0.8 : 0)),
            sizeA: w.size * ref.tanHalf * depth,
            sizeB: sizeB * ref.tanHalf * (depth - (w.grow ? 0.8 : 0)),
            arrive: w.arrive,
            leave: w.leave,
            growAt: w.grow ? w.grow.at : 1e6,
            growDur: w.grow ? w.grow.dur : 1,
            lineSource,
            col,
          });
        }
        x += adv;
      }
      pen += widths[wi] + space;
      if (wordSource === 0) prevCol++; // the space after the word on the sheet
      if (wordSource === 1) typedCol++;
    });
  }
  return slots;
}

/* -------------------------------------------------------------------------- */
/* 3. Build the instance table                                                 */
/* -------------------------------------------------------------------------- */
export function buildGlyphBuffers(atlas: GlyphAtlas, pages: PagePose[], tw: Typewriter, twFootprint: (p: THREE.Vector3) => boolean): GlyphBuffers {
  const R = rng(20130510);
  const sources = collectSources(pages, tw, twFootprint);
  const slots = layoutQuote(atlas);
  const ref = referencePose();
  const N = sources.length;

  const B: GlyphBuffers = {
    count: N,
    origin: new Float32Array(N * 3),
    originQuat: new Float32Array(N * 4),
    sea: new Float32Array(N * 3),
    slotA: new Float32Array(N * 3),
    slotB: new Float32Array(N * 3),
    glyph: new Float32Array(N * 2),
    time0: new Float32Array(N * 4),
    time1: new Float32Array(N * 4),
    grow: new Float32Array(N * 3),
    size: new Float32Array(N * 4),
    seed: new Float32Array(N * 4),
    links: [],
    members: 0,
  };

  // Lift-off wave: starts at the printing point and spreads over the desk.
  const printPoint = tw.sheetGlyph(0, 0).world;
  let maxD = 0;
  for (const s of sources) maxD = Math.max(maxD, Math.hypot(s.pos.x - printPoint.x, s.pos.z - printPoint.z));

  /** Paper quad size such that one monospaced advance equals one typewriter cell. */
  const paperQuad = TYPE.cell / atlas.monoAdvance;

  const lift = new Float32Array(N);
  const hover = new Float32Array(N);
  const ascent = new Float32Array(N);
  sources.forEach((s, i) => {
    const d = Math.hypot(s.pos.x - printPoint.x, s.pos.z - printPoint.z) / maxD;
    lift[i] = TIMELINE.liftStart + Math.pow(d, 0.85) * TIMELINE.liftSpread + R() * TIMELINE.liftJitter * (s.carriage ? 0.5 : 1);
    hover[i] = THREE.MathUtils.lerp(TIMELINE.hover[0], TIMELINE.hover[1], R());
    ascent[i] = THREE.MathUtils.lerp(TIMELINE.ascent[0], TIMELINE.ascent[1], R());
  });

  // ---- Assign each quote slot to a printed source with the same character ----
  const member = new Int32Array(N).fill(-1);
  const taken = new Uint8Array(N);
  const reachSea = (i: number) => lift[i] + TIMELINE.peelDuration + hover[i] + ascent[i];
  slots.forEach((slot, si) => {
    let best = -1;
    // (i) 1:1 by column from the sheet lines
    if (slot.lineSource !== -1) {
      best = sources.findIndex((s, i) => !taken[i] && s.line === slot.lineSource && s.col === slot.col && s.ch === slot.ch);
    }
    // (ii) otherwise nearest matching printed glyph that will be airborne in time
    if (best < 0) {
      let bestD = Infinity;
      sources.forEach((s, i) => {
        if (taken[i] || s.ch !== slot.ch || reachSea(i) > slot.arrive - 0.3) return;
        const dd = s.pos.distanceToSquared(printPoint);
        if (dd < bestD) {
          bestD = dd;
          best = i;
        }
      });
    }
    if (best < 0) best = sources.findIndex((s, i) => !taken[i] && s.ch.toLowerCase() === slot.ch.toLowerCase());
    if (best >= 0) {
      taken[best] = 1;
      member[best] = si;
      // make sure it is drifting in the sea before its word condenses
      const late = reachSea(best) - (slot.arrive - 0.4);
      if (late > 0) ascent[best] = Math.max(3, ascent[best] - late);
    }
  });

  const tanH = ref.tanHalf;
  const v = new THREE.Vector3();
  sources.forEach((s, i) => {
    const m = member[i];
    const slot = m >= 0 ? slots[m] : null;

    B.origin.set([s.pos.x, s.pos.y, s.pos.z], i * 3);
    B.originQuat.set([s.quat.x, s.quat.y, s.quat.z, s.quat.w], i * 4);

    // Sea point: inside the reference frustum, denser in the mid-distance.
    const depth = THREE.MathUtils.lerp(1.3, 17, Math.pow(R(), 1.05));
    const fx = (R() * 2 - 1) * 1.2 * REF_ASPECT;
    const fy = (R() * 2 - 1) * 1.15 - 0.05;
    v.copy(ref.frameToWorld(fx, fy, depth));
    B.sea.set([v.x, v.y, v.z], i * 3);
    const seaSize = 0.0175 * tanH * depth * (0.6 + 0.6 * R()) * 1.45;

    const a = slot ? slot.a : v;
    const b = slot ? slot.b : v;
    B.slotA.set([a.x, a.y, a.z], i * 3);
    B.slotB.set([b.x, b.y, b.z], i * 3);

    const [u, w] = atlas.cell(slot ? slot.ch : s.ch, slot ? slot.bold : false);
    B.glyph.set([u, w], i * 2);

    B.time0.set([s.appear, lift[i], hover[i], ascent[i]], i * 4);
    B.time1.set(
      slot ? [slot.arrive + R() * 0.32, 1.85 + R() * 0.45, slot.leave + R() * 0.35, 1] : [1e6, 1, 1e6, 0],
      i * 4,
    );
    B.grow.set([slot ? slot.growAt : 1e6, slot ? slot.growDur : 1, s.carriage ? 1 : 0], i * 3);
    B.size.set([paperQuad, seaSize, slot ? slot.sizeA : seaSize, slot ? slot.sizeB : seaSize], i * 4);
    B.seed.set([R(), R(), R(), R()], i * 4);

    if (slot) {
      B.members++;
      B.links.push({ from: s.pos.clone(), to: slot.a.clone(), carriage: s.carriage });
    }
  });
  return B;
}
