import * as THREE from "three";
import { GlyphAtlas } from "./atlas";
import { TIMELINE } from "./config";
import type { GlyphBuffers } from "./mapping";

/**
 * GlyphParticles – ONE instanced draw call for every typewritten character:
 * printed on paper, peeling, hovering, rising, drifting in the sea, condensing
 * into the quote and dispersing again. Motion is a pure function of uTime.
 *
 *  CINEMATIC EASING (per letter)
 *  ─────────────────────────────
 *   peel     1.5 s  ease-out cubic        : fibres let go, letter curls up 3–12 mm
 *   hover    0.35–1.25 s  ~zero velocity  : the suspension beat
 *   ascent   6.2–8.6 s  double-smoothstep : very slow start, long glide, soft landing
 *   sea      ∞     bounded sine drift     : snowfall
 *   condense 1.85–2.3 s  easeInOutQuint   : hesitates, accelerates, then a
 *                                          deliberate SNAP + 1-frame flash + tiny
 *                                          overshoot in scale (the "lock-in")
 *   leave    2.6 s  ease-in quad          : drifts back into the fog, defocusing
 */
const vertexShader = /* glsl */ `
attribute vec3 aOrigin;
attribute vec4 aOriginQuat;
attribute vec3 aSea;
attribute vec3 aSlotA;
attribute vec3 aSlotB;
attribute vec2 aGlyph;
attribute vec4 aTime0;   // appear, lift, hover, ascent
attribute vec4 aTime1;   // arrive, condense, leave, member
attribute vec3 aGrow;    // growStart, growDur, carriage
attribute vec4 aSize;    // paper, sea, slotA, slotB
attribute vec4 aSeed;

uniform float uTime;
uniform float uCarriageX;
uniform vec3  uCarriageAxis;
uniform vec4  uRefQuat;
uniform vec3  uRefPos;
uniform float uFocus;
uniform float uFocusRange;
uniform float uDeskFade;
uniform float uEnd;
uniform vec2  uCellUV;
uniform float uSeaDim;
uniform float uResY;

varying vec2  vUv;
varying vec2  vCellMin;
varying vec2  vLocal;
varying float vAlpha;
varying float vBias;
varying float vLit;
varying float vShade;
varying float vFlash;
varying float vOcc;
varying float vGain;

const float PI = 3.14159265;
const float PEEL = ${TIMELINE.peelDuration.toFixed(3)};

vec3 qrot(vec4 q, vec3 v) { return v + 2.0 * cross(q.xyz, cross(q.xyz, v) + q.w * v); }
vec4 qmul(vec4 a, vec4 b) { return vec4(a.w*b.xyz + b.w*a.xyz + cross(a.xyz, b.xyz), a.w*b.w - dot(a.xyz, b.xyz)); }
vec4 qaxis(vec3 ax, float an) { float h = an * 0.5; return vec4(normalize(ax) * sin(h), cos(h)); }
vec4 qnlerp(vec4 a, vec4 b, float t) { if (dot(a, b) < 0.0) b = -b; return normalize(mix(a, b, t)); }
vec3 bez(vec3 a, vec3 b, vec3 c, vec3 d, float t) { float u = 1.0 - t; return u*u*u*a + 3.0*u*u*t*b + 3.0*u*t*t*c + t*t*t*d; }
float sstep(float x) { x = clamp(x, 0.0, 1.0); return x * x * (3.0 - 2.0 * x); }
float ascentEase(float x) { float s = sstep(x); return mix(s, sstep(s), 0.55); }
float quint(float x) { return x < 0.5 ? 16.0*x*x*x*x*x : 1.0 - pow(-2.0*x + 2.0, 5.0) * 0.5; }

/* Bounded, slow drift of the sea of letters (pure function of time). */
vec3 seaAt(vec3 base, float t, vec4 s) {
  float d = length(base - uRefPos);
  float tt = t - 12.0;
  vec3 right = qrot(uRefQuat, vec3(1.0, 0.0, 0.0));
  vec3 drift = vec3(
      sin(t * (0.11 + 0.08 * s.x) + s.y * 40.0),
      sin(t * (0.09 + 0.07 * s.z) + s.w * 40.0) * 0.8,
      sin(t * (0.10 + 0.06 * s.y) + s.x * 40.0)) * (0.035 * d);
  drift += vec3(0.0, -0.0045 * d * tt, 0.0) * (0.6 + 0.8 * s.z);  // gentle snowfall
  drift += right * (-0.0025 * d * tt);                             // and a faint wind
  return base + drift;
}

void main() {
  float t = uTime;
  float appear = aTime0.x, lift = aTime0.y, hover = aTime0.z, ascent = aTime0.w;
  float arrive = aTime1.x, cdur = aTime1.y, leave = aTime1.z;
  bool member = aTime1.w > 0.5;

  float visible = appear < 0.0 ? 1.0 : step(appear, t);
  vec3 origin = aOrigin + uCarriageAxis * (uCarriageX * aGrow.z);
  vec3 n = qrot(aOriginQuat, vec3(0.0, 0.0, 1.0));
  vec3 up = vec3(0.0, 1.0, 0.0);

  /* ---- 1. PEEL + HOVER (letter is still physically at its paper cell) ---- */
  float pk = clamp((t - lift) / PEEL, 0.0, 1.0);
  float peelE = 1.0 - pow(1.0 - pk, 3.0);
  float peelH = 0.003 + 0.009 * aSeed.x;
  float hv = sstep(pk);
  vec3 wob = vec3(sin(t * 1.7 + aSeed.y * 20.0), sin(t * 2.3 + aSeed.w * 30.0) * 0.6, cos(t * 1.3 + aSeed.z * 20.0)) * 0.0011 * hv;
  vec3 pos = origin + n * peelH * peelE + wob;
  vec4 qPaper = qmul(aOriginQuat, qaxis(vec3(1.0, 0.0, 0.0), (aSeed.z - 0.5) * 0.5 * peelE));

  /* ---- 2. ASCENT into the sea ---- */
  float a0 = lift + PEEL + hover;
  float ap = clamp((t - a0) / ascent, 0.0, 1.0);
  float ae = ascentEase(ap);
  vec3 sea = seaAt(aSea, t, aSeed);
  vec3 span = sea - pos;
  float dist = max(length(span), 1e-3);
  vec3 dir = span / dist;
  vec3 s1 = normalize(cross(dir, abs(dir.y) > 0.95 ? vec3(1.0, 0.0, 0.0) : up));
  vec3 s2 = cross(dir, s1);
  if (ap > 0.0) {
    vec3 c1 = pos + n * (0.06 + 0.16 * aSeed.y) + up * (0.18 + 0.55 * aSeed.z);
    vec3 c2 = mix(pos, sea, 0.6) + up * (0.5 + 1.1 * aSeed.w) + s1 * (aSeed.x - 0.5) * dist * 0.5;
    vec3 p = bez(pos, c1, c2, sea, ae);
    float air = sin(ap * PI);
    float ph = t * (0.7 + 0.8 * aSeed.x) + aSeed.w * 6.283;
    p += (s1 * sin(ph) + s2 * cos(ph)) * (0.03 + 0.08 * aSeed.z) * min(dist, 6.0) * air;
    pos = p;
  }

  /* ---- orientation: page → tumbling → facing the camera ---- */
  vec3 axis = normalize(aSeed.xyz - 0.5 + 0.001);
  float turns = floor(1.0 + aSeed.w * 2.5);
  float wobA = sin(t * (0.35 + 0.4 * aSeed.y) + aSeed.x * 30.0) * 0.55 * sstep(ap * 2.0 - 1.0);
  float spin = sstep(ap) * turns * 2.0 * PI + wobA;
  vec4 q = qnlerp(qPaper, uRefQuat, sstep(ap * 1.25));
  float sc = mix(aSize.x, aSize.y, sstep(ap * 1.1));

  /* ---- 3. CONDENSE into the quote (members only) ---- */
  float flash = 0.0;
  float condensed = 0.0;
  float leaveP = 0.0;
  if (member) {
    float g = sstep((t - aGrow.x) / aGrow.y);
    g = g * g * (3.0 - 2.0 * g);
    vec3 slot = mix(aSlotA, aSlotB, g);
    float slotSize = mix(aSize.z, aSize.w, g);
    // settled words breathe together (phase from slot position)
    slot += up * sin(t * 0.7 + aSlotA.x * 0.4) * 0.012 * slotSize;
    float cp = clamp((t - arrive) / cdur, 0.0, 1.0);
    float ce = quint(cp);
    if (cp > 0.0) {
      vec3 toCam = normalize(uRefPos - slot);
      vec3 c1 = sea + (s1 * (aSeed.y - 0.5) + up * (aSeed.z - 0.3)) * 0.35 * length(sea - slot);
      vec3 c2 = slot + toCam * (0.4 + 0.8 * aSeed.x) + s2 * (aSeed.w - 0.5) * 0.6;
      pos = bez(sea, c1, c2, slot, ce);
      sc = mix(sc, slotSize, sstep(cp * 1.2));
      spin *= 1.0 - ce;
      q = qnlerp(q, uRefQuat, ce);
      condensed = ce;
      float since = t - (arrive + cdur);
      flash = since > -0.12 ? exp(-max(since, 0.0) * 5.0) * sstep((since + 0.12) / 0.12) : 0.0;
      sc *= 1.0 + 0.07 * sin(clamp(since / 0.45, 0.0, 1.0) * PI) * step(0.0, since); // tiny overshoot
    }
    /* ---- 4. LEAVE: back into the fog ---- */
    leaveP = clamp((t - leave) / 2.6, 0.0, 1.0);
    if (leaveP > 0.0) {
      vec3 away = normalize(vec3(aSeed.x - 0.5, aSeed.y * 0.6 + 0.1, aSeed.z - 0.5));
      pos += (away * 1.4 + up * 0.35) * leaveP * leaveP * (0.5 + aSeed.w);
      spin += leaveP * leaveP * (aSeed.y - 0.5) * 4.0;
    }
  }

  // end of the sequence: everything drifts off
  pos += (up * 0.6 + s1 * (aSeed.x - 0.5) * 2.0) * uEnd * uEnd;

  q = qmul(q, qaxis(axis, spin));
  vec3 local = vec3(position.xy * sc, 0.0);

  /* ---- depth of field ---- */
  vec4 mv0 = modelViewMatrix * vec4(pos, 1.0);
  float depth = max(-mv0.z, 1e-3);
  float defocus = abs(depth - uFocus) / max(uFocusRange, 1e-3);
  defocus = min(defocus, 5.0) * (1.0 - 0.9 * condensed) + leaveP * 2.2;
  local *= 1.0 + 0.22 * min(defocus, 3.0);           // bokeh spreads the letter

  vec3 world = pos + qrot(q, local) + n * 0.00025 * (1.0 - sstep(ap * 4.0));
  vec4 mv = modelViewMatrix * vec4(world, 1.0);

  /* ---- shading: letters are thin flakes – edge-on ones catch less light ---- */
  vec3 nrm = qrot(q, vec3(0.0, 0.0, 1.0));
  vec3 view = normalize(cameraPosition - world);
  float facing = abs(dot(nrm, view));
  vShade = 0.55 + 0.45 * facing;

  /* ---- alpha ---- */
  float alpha = visible;
  float onPaper = 1.0 - step(0.0001, pk);
  alpha *= mix(1.0, uDeskFade, 1.0 - step(0.001, ap));   // still on the page → fades with the desk
  alpha *= member ? (1.0 - sstep(leaveP * 1.15)) : uSeaDim * (aSeed.w < 0.25 ? uDeskFade : 1.0);
  alpha *= 1.0 / (1.0 + defocus * 0.95);
  alpha *= 1.0 - uEnd;
  alpha *= mix(0.86 + 0.14 * aSeed.z, 1.0, sstep(ap * 3.0)); // uneven ribbon strike on paper

  vAlpha = alpha;
  vLit = sstep(ap * 3.0 - 0.15) * (member ? 1.0 : 0.9);
  vFlash = flash + condensed * 0.22 * (1.0 - leaveP);
  // Tiny on-screen letters (printed text seen from 0.6 m) lose their thin strokes in
  // the mip chain – sharpen the LOD and boost coverage so the page reads as type.
  float quadPx = sc * projectionMatrix[1][1] * uResY * 0.5 / max(-mv.z, 1e-3);
  vGain = clamp(40.0 / max(quadPx, 1.0), 1.0, 3.2);
  vBias = clamp(defocus * 1.25, 0.0, 3.0) - (vGain - 1.0) * 0.6;
  vOcc = uDeskFade * (1.0 - onPaper * 0.0);
  vLocal = uv;
  vCellMin = aGlyph;
  vUv = aGlyph + vec2(uv.x, 1.0 - uv.y) * uCellUV;
  gl_Position = projectionMatrix * mv;
}
`;

const fragmentShader = /* glsl */ `
uniform sampler2D uAtlas;
uniform sampler2D uDeskDepth;
uniform vec2  uRes;
uniform vec2  uCellUV;
uniform float uNear;
uniform float uFar;
uniform vec3  uInk;
uniform vec3  uAir;
uniform vec3  uWarm;

varying vec2  vUv;
varying vec2  vCellMin;
varying vec2  vLocal;
varying float vAlpha;
varying float vBias;
varying float vLit;
varying float vShade;
varying float vFlash;
varying float vOcc;
varying float vGain;

float linDepth(float z) { return (uNear * uFar) / (uFar - z * (uFar - uNear)); }

float tap(vec2 uv) {
  vec2 lo = vCellMin + uCellUV * 0.02;
  vec2 hi = vCellMin + uCellUV * 0.98;
  return texture2D(uAtlas, clamp(uv, lo, hi), vBias).a;
}

void main() {
  float a = tap(vUv);
  if (vBias > 0.4) {
    vec2 o = uCellUV * 0.018 * vBias;
    a = (a * 2.0 + tap(vUv + vec2(o.x, 0.0)) + tap(vUv - vec2(o.x, 0.0)) + tap(vUv + vec2(0.0, o.y)) + tap(vUv - vec2(0.0, o.y))) / 6.0;
  }
  // feather the quad edges so blurred letters never show a square
  vec2 e = abs(vLocal - 0.5);
  float sq = 1.0 - smoothstep(0.42, 0.5, max(e.x, e.y));
  float round_ = 1.0 - smoothstep(0.18, 0.46, length(vLocal - 0.5));   // bokeh is round, never square
  a *= mix(sq, round_, smoothstep(0.6, 2.2, vBias));
  a = min(1.0, a * vGain) * vAlpha;

  // manual occlusion against the desk depth (typewriter parts hide letters behind them)
  if (vOcc > 0.001) {
    float scene = texture2D(uDeskDepth, gl_FragCoord.xy / uRes).r;
    float hidden = step(linDepth(scene) + 0.0025, linDepth(gl_FragCoord.z));
    a *= 1.0 - hidden * vOcc;
  }
  if (a < 0.003) discard;

  // ribbon ink on the page → pale, paper-white flake once airborne
  vec3 air = mix(uAir, uWarm, 0.12) * vShade;
  vec3 col = mix(uInk, air, vLit) + vFlash * 0.55;
  gl_FragColor = vec4(col, a);
}
`;

export class GlyphParticles {
  readonly mesh: THREE.Mesh;
  readonly material: THREE.ShaderMaterial;

  constructor(B: GlyphBuffers, atlas: GlyphAtlas) {
    const base = new THREE.PlaneGeometry(1, 1);
    const geo = new THREE.InstancedBufferGeometry();
    geo.index = base.index;
    geo.setAttribute("position", base.getAttribute("position"));
    geo.setAttribute("uv", base.getAttribute("uv"));
    geo.instanceCount = B.count;
    const inst = (name: string, arr: Float32Array, size: number) => geo.setAttribute(name, new THREE.InstancedBufferAttribute(arr, size));
    inst("aOrigin", B.origin, 3);
    inst("aOriginQuat", B.originQuat, 4);
    inst("aSea", B.sea, 3);
    inst("aSlotA", B.slotA, 3);
    inst("aSlotB", B.slotB, 3);
    inst("aGlyph", B.glyph, 2);
    inst("aTime0", B.time0, 4);
    inst("aTime1", B.time1, 4);
    inst("aGrow", B.grow, 3);
    inst("aSize", B.size, 4);
    inst("aSeed", B.seed, 4);

    const lin = (r: number, g: number, b: number) => new THREE.Color(r, g, b).convertSRGBToLinear();
    this.material = new THREE.ShaderMaterial({
      vertexShader,
      fragmentShader,
      transparent: true,
      depthTest: false,
      depthWrite: false,
      uniforms: {
        uTime: { value: 0 },
        uCarriageX: { value: 0 },
        uCarriageAxis: { value: new THREE.Vector3(1, 0, 0) },
        uRefQuat: { value: new THREE.Vector4() },
        uRefPos: { value: new THREE.Vector3() },
        uFocus: { value: 0.6 },
        uFocusRange: { value: 0.3 },
        uDeskFade: { value: 1 },
        uEnd: { value: 0 },
        uSeaDim: { value: 1 },
        uResY: { value: 1 },
        uCellUV: { value: new THREE.Vector2(...atlas.cellUV) },
        uAtlas: { value: atlas.texture },
        uDeskDepth: { value: null },
        uRes: { value: new THREE.Vector2(1, 1) },
        uNear: { value: 0.01 },
        uFar: { value: 80 },
        uInk: { value: lin(0.08, 0.07, 0.07) },
        uAir: { value: lin(0.93, 0.93, 0.9) },
        uWarm: { value: lin(1.0, 0.9, 0.72) },
      },
    });
    this.mesh = new THREE.Mesh(geo, this.material);
    this.mesh.frustumCulled = false;
  }
}
