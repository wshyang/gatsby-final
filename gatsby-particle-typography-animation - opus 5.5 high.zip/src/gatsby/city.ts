import * as THREE from "three";
import { PALETTE, WORLD } from "./config";
import { rng } from "./texts";

/**
 * Procedural 1920s Manhattan seen from ~200 m up, in cold teal fog.
 *
 *  - ~6 000 instanced buildings on a Manhattan-like grid (tall clusters for
 *    downtown + midtown, low Brooklyn side), setback tiers and spires
 *  - a river running diagonally through the foreground with a suspension
 *    bridge (stone towers, catenary cables, suspenders) and a few tugs
 *  - shared fog function (exp² + low ground mist)
 *  - a matte painting (public/images/city.jpg) as the far atmospheric
 *    backdrop, locked to the true horizon so it reads as the distant skyline.
 *
 * reviews.txt: mimo had no 3D backdrop (bad); fable low's image backdrop with
 * a blur that racks into focus was liked. We do both: real 3D geometry, an
 * image only for the far haze, and a focus pull in the post pipeline.
 */
const G = WORLD.cityGround;
const riverX = (z: number) => -170 + 0.36 * z;
const RIVER_W = 400;

const fogChunk = /* glsl */ `
uniform vec3 uFog;
uniform float uDensity;
vec3 applyFog(vec3 col, vec3 wp, vec3 cam) {
  float d = length(wp - cam);
  float f = 1.0 - exp(-pow(d * uDensity, 2.0));
  float mist = exp(-max(wp.y - ${G.toFixed(1)}, 0.0) / 38.0) * 0.55 * smoothstep(150.0, 900.0, d);
  f = clamp(f + (1.0 - f) * mist, 0.0, 1.0);
  return mix(col, uFog, f);
}
`;

function fogUniforms(fog: THREE.Color) {
  return { uFog: { value: fog }, uDensity: { value: 0.00062 } };
}

export class City {
  readonly scene = new THREE.Scene();
  private backdrop: THREE.Mesh;
  private water: THREE.ShaderMaterial;
  private boats: THREE.Object3D[] = [];
  readonly fog = new THREE.Color(...PALETTE.cityFog).convertSRGBToLinear();

  constructor(painting: THREE.Texture) {
    this.scene.background = this.fog.clone();
    this.buildGround();
    this.buildBuildings();
    this.buildBridge(-760);
    this.buildBridge(-2350, 0.8);
    this.water = this.buildWater();
    this.buildBoats();
    this.backdrop = this.buildBackdrop(painting);
  }

  private buildGround() {
    const mat = new THREE.ShaderMaterial({
      uniforms: fogUniforms(this.fog),
      vertexShader: `varying vec3 vW; void main(){ vec4 w = modelMatrix*vec4(position,1.); vW=w.xyz; gl_Position=projectionMatrix*viewMatrix*w; }`,
      fragmentShader: `${fogChunk} varying vec3 vW;
        void main(){
          vec2 g = abs(fract(vW.xz / vec2(260.0, 80.0)) - 0.5);
          float street = step(0.47, max(g.x * 1.0, g.y));
          vec3 col = mix(vec3(0.075, 0.08, 0.08), vec3(0.16, 0.17, 0.17), street);
          gl_FragColor = vec4(applyFog(col, vW, cameraPosition), 1.0);
        }`,
    });
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(14000, 14000), mat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.set(0, G, -3000);
    this.scene.add(ground);
  }

  private buildBuildings() {
    const R = rng(1925);
    type B = { x: number; z: number; w: number; d: number; y0: number; h: number; tint: number };
    const list: B[] = [];
    const spires: { x: number; z: number; y: number; r: number; h: number }[] = [];
    const cluster = (x: number, z: number, cx: number, cz: number, r: number) => Math.exp(-((x - cx) ** 2 + (z - cz) ** 2) / (r * r));

    for (let ax = -2600; ax < 2600; ax += 260) {
      for (let sz = 500; sz > -5200; sz -= 80) {
        const rx = riverX(sz);
        const dRiver = ax + 130 - rx;
        if (Math.abs(dRiver) < RIVER_W / 2 + 140) continue;
        const manhattan = dRiver > 0;
        let x = ax + 14;
        while (x < ax + 246) {
          const w = 22 + R() * 42;
          if (x + w > ax + 246) break;
          const d = 30 + R() * 34;
          const zc = sz - 40;
          let h = manhattan ? 14 + R() * 34 : 8 + R() * 18;
          if (manhattan) {
            const boost = Math.max(cluster(x, zc, 380, -2150, 650), cluster(x, zc, 260, -950, 380) * 0.85);
            if (R() < 0.18 + boost * 0.7) h += boost * (90 + R() * 210) + R() * 25;
          }
          const tint = 0.25 + R() * 0.25;
          list.push({ x: x + w / 2, z: zc + (R() - 0.5) * 6, w, d, y0: G, h, tint });
          // setback tiers for tall towers (1920s zoning law silhouettes)
          if (h > 95) {
            let y = G + h;
            let tw = w * 0.72;
            let td = d * 0.72;
            const tiers = 1 + Math.floor(R() * 3);
            for (let k = 0; k < tiers; k++) {
              const th = h * (0.18 + R() * 0.2);
              list.push({ x: x + w / 2, z: zc, w: tw, d: td, y0: y, h: th, tint });
              y += th;
              tw *= 0.7;
              td *= 0.7;
            }
            if (R() < 0.55) spires.push({ x: x + w / 2, z: zc, y, r: Math.min(tw, td) * 0.6, h: 20 + R() * 55 });
          }
          x += w + 4 + R() * 10;
        }
      }
    }

    const geo = new THREE.BoxGeometry(1, 1, 1);
    geo.translate(0, 0.5, 0);
    const mat = new THREE.ShaderMaterial({
      uniforms: fogUniforms(this.fog),
      vertexShader: /* glsl */ `
        attribute float aTint;
        varying vec3 vW; varying vec3 vN; varying float vTint; varying float vH;
        void main(){
          vec4 w = modelMatrix * instanceMatrix * vec4(position, 1.0);
          vW = w.xyz; vN = normalize(mat3(instanceMatrix) * normal); vTint = aTint; vH = position.y;
          gl_Position = projectionMatrix * viewMatrix * w;
        }`,
      fragmentShader: /* glsl */ `${fogChunk}
        varying vec3 vW; varying vec3 vN; varying float vTint; varying float vH;
        float hash(vec2 p){ return fract(sin(dot(p, vec2(41.3, 289.1))) * 43758.5); }
        void main(){
          vec3 n = normalize(vN);
          vec3 base = vec3(0.24, 0.25, 0.25) * (0.6 + vTint);
          base *= mix(vec3(1.0), vec3(1.08, 0.98, 0.9), step(0.4, vTint));   // brownstone vs limestone
          float sky = 0.55 + 0.45 * n.y;
          float sun = max(dot(n, normalize(vec3(-0.5, 0.65, 0.45))), 0.0);
          vec3 col = base * (0.42 * sky + 0.55 * sun);
          if (n.y > 0.5) {
            float fr = hash(floor(vW.xz / 7.0));
            col = mix(col, vec3(0.44, 0.47, 0.48) * (0.75 + 0.35 * vTint), 0.4);   // frosty roofs, as in the film
            col *= 0.82 + 0.25 * fr;                                              // roof clutter / tar patches
            vec2 e = abs(fract(vW.xz / vec2(9.0, 11.0)) - 0.5);
            col *= 0.9 + 0.1 * step(0.45, max(e.x, e.y));
          } else {
            float u = abs(n.x) > 0.5 ? vW.z : vW.x;
            vec2 cell = vec2(u / 3.4, vW.y / 3.7);
            float win = step(0.35, fract(cell.x)) * step(0.4, fract(cell.y));
            col *= 1.0 - 0.3 * win;
            float lit = step(0.975, hash(floor(cell))) * win;
            col += vec3(0.9, 0.7, 0.45) * lit * 0.35;
            col *= 0.75 + 0.25 * smoothstep(0.0, 0.3, vH);   // darker at street level
          }
          gl_FragColor = vec4(applyFog(col, vW, cameraPosition), 1.0);
        }`,
    });
    const mesh = new THREE.InstancedMesh(geo, mat, list.length);
    const tint = new Float32Array(list.length);
    const m = new THREE.Matrix4();
    list.forEach((b, i) => {
      m.makeScale(b.w, b.h, b.d).setPosition(b.x, b.y0, b.z);
      mesh.setMatrixAt(i, m);
      tint[i] = b.tint;
    });
    geo.setAttribute("aTint", new THREE.InstancedBufferAttribute(tint, 1));
    mesh.frustumCulled = false;
    this.scene.add(mesh);

    const cone = new THREE.ConeGeometry(1, 1, 4);
    cone.translate(0, 0.5, 0);
    cone.setAttribute("aTint", new THREE.InstancedBufferAttribute(new Float32Array(spires.length).fill(0.45), 1));
    const sm = new THREE.InstancedMesh(cone, mat, spires.length);
    spires.forEach((s, i) => {
      m.makeRotationY(Math.PI / 4).scale(new THREE.Vector3(s.r, s.h, s.r)).setPosition(s.x, s.y, s.z);
      sm.setMatrixAt(i, m);
    });
    sm.frustumCulled = false;
    this.scene.add(sm);
  }

  private buildBridge(z0: number, scale = 1) {
    const stone = new THREE.ShaderMaterial({
      uniforms: fogUniforms(this.fog),
      vertexShader: `varying vec3 vW; varying vec3 vN; void main(){ vec4 w = modelMatrix*vec4(position,1.); vW=w.xyz; vN=normalize(mat3(modelMatrix)*normal); gl_Position=projectionMatrix*viewMatrix*w; }`,
      fragmentShader: `${fogChunk} varying vec3 vW; varying vec3 vN; void main(){ float l = 0.45 + 0.4*max(dot(normalize(vN), normalize(vec3(-0.5,0.65,0.45))),0.); gl_FragColor = vec4(applyFog(vec3(0.27,0.25,0.23)*l*1.4, vW, cameraPosition),1.); }`,
    });
    const group = new THREE.Group();
    const rx = riverX(z0);
    const half = RIVER_W / 2 + 110;
    const towerH = 95 * scale;
    const deckY = G + 40 * scale;
    // towers (two legs + cap) at ~1/4 and 3/4 of the span
    for (const s of [-0.55, 0.55]) {
      const tx = rx + s * RIVER_W * 0.5;
      for (const lz of [-9, 9]) {
        const leg = new THREE.Mesh(new THREE.BoxGeometry(9, towerH, 7), stone);
        leg.position.set(tx, G + towerH / 2, z0 + lz);
        group.add(leg);
      }
      const cap = new THREE.Mesh(new THREE.BoxGeometry(11, 12, 28), stone);
      cap.position.set(tx, G + towerH - 6, z0);
      group.add(cap);
      const mid = new THREE.Mesh(new THREE.BoxGeometry(10, 8, 26), stone);
      mid.position.set(tx, deckY + 26, z0);
      group.add(mid);
    }
    const deck = new THREE.Mesh(new THREE.BoxGeometry(half * 2, 3, 22), stone);
    deck.position.set(rx, deckY, z0);
    group.add(deck);
    // cables + suspenders
    const pts: number[] = [];
    const t1 = rx - 0.55 * RIVER_W * 0.5;
    const t2 = rx + 0.55 * RIVER_W * 0.5;
    const top = G + towerH - 4;
    const cable = (x: number) => {
      if (x < t1) return THREE.MathUtils.lerp(deckY, top, (x - (rx - half)) / (t1 - (rx - half)));
      if (x > t2) return THREE.MathUtils.lerp(top, deckY, (x - t2) / (rx + half - t2));
      const u = (x - t1) / (t2 - t1);
      return top - (top - deckY - 4) * 4 * u * (1 - u);
    };
    for (const lz of [-10, 10]) {
      for (let x = rx - half; x < rx + half; x += 6) {
        pts.push(x, cable(x), z0 + lz, x + 6, cable(x + 6), z0 + lz);
        pts.push(x, cable(x), z0 + lz, x, deckY, z0 + lz);
      }
    }
    const lg = new THREE.BufferGeometry();
    lg.setAttribute("position", new THREE.Float32BufferAttribute(pts, 3));
    const lines = new THREE.LineSegments(lg, new THREE.LineBasicMaterial({ color: 0x3d4448, transparent: true, opacity: 0.55, fog: false }));
    group.add(lines);
    this.scene.add(group);
  }

  private buildWater() {
    const mat = new THREE.ShaderMaterial({
      uniforms: { ...fogUniforms(this.fog), uTime: { value: 0 } },
      vertexShader: `varying vec3 vW; void main(){ vec4 w = modelMatrix*vec4(position,1.); vW=w.xyz; gl_Position=projectionMatrix*viewMatrix*w; }`,
      fragmentShader: /* glsl */ `${fogChunk}
        uniform float uTime; varying vec3 vW;
        float n2(vec2 p){ return sin(p.x)*sin(p.y); }
        void main(){
          vec3 v = normalize(cameraPosition - vW);
          float fres = pow(1.0 - max(v.y, 0.0), 4.0);
          float rip = n2(vW.xz * vec2(0.05, 0.11) + uTime * 0.3) * 0.5 + n2(vW.xz * vec2(0.13, 0.04) - uTime * 0.2) * 0.5;
          vec3 col = mix(vec3(0.07, 0.1, 0.11), vec3(0.38, 0.44, 0.47), clamp(fres + rip * 0.06, 0.0, 1.0));
          gl_FragColor = vec4(applyFog(col, vW, cameraPosition), 1.0);
        }`,
    });
    const shape = new THREE.Shape();
    const z1 = 900;
    const z2 = -6500;
    const hw = RIVER_W / 2 + 120;
    shape.moveTo(riverX(z1) - hw, -z1);
    shape.lineTo(riverX(z1) + hw, -z1);
    shape.lineTo(riverX(z2) + hw, -z2);
    shape.lineTo(riverX(z2) - hw, -z2);
    const water = new THREE.Mesh(new THREE.ShapeGeometry(shape), mat);
    water.rotation.x = -Math.PI / 2;
    water.position.y = G + 0.5;
    this.scene.add(water);
    return mat;
  }

  private buildBoats() {
    const mat = new THREE.MeshBasicMaterial({ color: 0x1a1d1f });
    const R = rng(77);
    for (let i = 0; i < 6; i++) {
      const b = new THREE.Group();
      const hull = new THREE.Mesh(new THREE.BoxGeometry(9, 3, 28), mat);
      const cab = new THREE.Mesh(new THREE.BoxGeometry(6, 5, 8), mat);
      cab.position.set(0, 3.5, 3);
      b.add(hull, cab);
      b.userData = { z: -300 - R() * 2200, off: (R() - 0.5) * RIVER_W * 0.6, speed: 2 + R() * 4 };
      this.scene.add(b);
      this.boats.push(b);
    }
  }

  private buildBackdrop(tex: THREE.Texture) {
    tex.colorSpace = THREE.SRGBColorSpace;
    const mat = new THREE.ShaderMaterial({
      uniforms: { uMap: { value: tex }, uFog: { value: this.fog } },
      depthTest: false,
      depthWrite: false,
      vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.); }`,
      fragmentShader: /* glsl */ `
        uniform sampler2D uMap; uniform vec3 uFog; varying vec2 vUv;
        void main(){
          vec3 c = texture2D(uMap, vUv).rgb;
          // desaturate toward the film's cold teal and sink the lower half into the fog
          float l = dot(c, vec3(0.3, 0.55, 0.15));
          c = mix(vec3(l), c, 0.55) * vec3(0.92, 1.0, 1.04);
          c = mix(c, uFog, 0.35 + 0.5 * (1.0 - smoothstep(0.3, 0.62, vUv.y)));
          gl_FragColor = vec4(c, 1.0);
        }`,
    });
    const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), mat);
    m.renderOrder = -10;
    m.frustumCulled = false;
    this.scene.add(m);
    return m;
  }

  update(t: number, cam: THREE.PerspectiveCamera) {
    this.water.uniforms.uTime.value = t;
    for (const b of this.boats) {
      const z = b.userData.z - t * b.userData.speed;
      b.position.set(riverX(z) + b.userData.off, G + 1.5, z);
      b.rotation.y = Math.atan(0.36);
    }
    // Backdrop: camera-attached plane whose image row 0.55 (the haze line under the
    // skyline) is pinned ~1.5° below the true horizon, whatever the camera pitch.
    const D = 8000;
    const e = new THREE.Euler().setFromQuaternion(cam.quaternion, "YXZ");
    const vt = Math.tan(THREE.MathUtils.degToRad(cam.fov / 2));
    const H = 2 * D * vt * 1.35;
    const W = Math.max(H * 1.78, 2 * D * vt * cam.aspect * 1.1);
    const horizonY = D * Math.tan(-e.x - THREE.MathUtils.degToRad(1.5));
    this.backdrop.scale.set(W, H, 1);
    this.backdrop.position.set(0, horizonY - (0.55 - 0.5) * H * -1, -D).applyQuaternion(cam.quaternion).add(cam.position);
    this.backdrop.quaternion.copy(cam.quaternion);
  }
}
