import * as THREE from "three";

/**
 * GlyphAtlas
 * ----------
 * Renders every printable ASCII character of a typewriter face ("Special
 * Elite", which has the worn ribbon / uneven-strike look of the film's title
 * typography) into a square-celled texture atlas – once regular and once
 * heavy (for the emphasised words "death," / "correction.").
 *
 * The texture is mip-mapped: the glyph shader fakes depth-of-field by
 * sampling higher mip levels for out-of-focus letters, so each cell gets
 * generous padding to keep blurred ink from bleeding into its neighbours.
 */
export const CELL = 128;
const COLS = 16;
const FONT_PX = 64;
const BASELINE = 0.64; // fraction of the cell height
const FIRST = 33;
const LAST = 126;
const COUNT = LAST - FIRST + 1;

export class GlyphAtlas {
  readonly texture: THREE.CanvasTexture;
  readonly cols = COLS;
  readonly rows: number;
  /** Atlas cell size in UV units. */
  readonly cellUV: [number, number];
  /** Horizontal advance of every character as a fraction of the quad size. */
  readonly advance = new Map<string, number>();
  /** Advance of a monospaced cell (fraction of the quad size). */
  readonly monoAdvance: number;

  constructor(fontFamily: string) {
    this.rows = Math.ceil((COUNT * 2) / COLS);
    const canvas = document.createElement("canvas");
    canvas.width = COLS * CELL;
    canvas.height = this.rows * CELL;
    const ctx = canvas.getContext("2d")!;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.textAlign = "center";
    ctx.textBaseline = "alphabetic";
    ctx.font = `${FONT_PX}px "${fontFamily}", "Courier New", monospace`;
    ctx.fillStyle = "#fff";
    ctx.strokeStyle = "#fff";

    for (let i = 0; i < COUNT; i++) {
      const ch = String.fromCharCode(FIRST + i);
      this.advance.set(ch, ctx.measureText(ch).width / CELL);
      for (let v = 0; v < 2; v++) {
        const idx = i + v * COUNT;
        const cx = (idx % COLS) * CELL + CELL / 2;
        const cy = Math.floor(idx / COLS) * CELL + CELL * BASELINE;
        if (v === 1) {
          ctx.lineWidth = 3.2;
          ctx.lineJoin = "round";
          ctx.strokeText(ch, cx, cy);
        }
        ctx.fillText(ch, cx, cy);
      }
    }
    this.advance.set(" ", ctx.measureText(" ").width / CELL);
    this.monoAdvance = ctx.measureText("M").width / CELL;

    // Ribbon grain: knock random speckles out of the ink so every letter
    // looks struck, not printed.
    const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const d = img.data;
    let s = 1234567;
    for (let p = 3; p < d.length; p += 4) {
      if (d[p] === 0) continue;
      s = (s * 16807) % 2147483647;
      const r = s / 2147483647;
      d[p] = Math.round(d[p] * (r < 0.06 ? 0.45 : 0.82 + 0.18 * r));
      d[p - 3] = d[p - 2] = d[p - 1] = 255;
    }
    ctx.putImageData(img, 0, 0);

    this.texture = new THREE.CanvasTexture(canvas);
    this.texture.generateMipmaps = true;
    this.texture.minFilter = THREE.LinearMipmapLinearFilter;
    this.texture.magFilter = THREE.LinearFilter;
    this.texture.anisotropy = 8;
    this.texture.flipY = false;
    this.texture.needsUpdate = true;
    this.cellUV = [1 / COLS, 1 / this.rows];
  }

  /** UV origin (top-left, flipY=false) of a character's atlas cell. */
  cell(ch: string, bold = false): [number, number] {
    let code = ch.charCodeAt(0);
    if (ch === "\u2019") code = 39;
    if (code < FIRST || code > LAST) code = 63; // '?'
    const idx = code - FIRST + (bold ? COUNT : 0);
    return [(idx % COLS) / COLS, Math.floor(idx / COLS) / this.rows];
  }

  adv(ch: string): number {
    return this.advance.get(ch) ?? this.monoAdvance;
  }
}
