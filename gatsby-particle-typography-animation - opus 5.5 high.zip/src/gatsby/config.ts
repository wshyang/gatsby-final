/**
 * ============================================================================
 *  GATSBY — "After Gatsby's death, New York was haunted for me…"
 *  Global configuration: cinematic timeline, quote formation, palette.
 * ============================================================================
 *
 *  Every moving thing in the scene is a *pure function of time* (seconds).
 *  Nothing is integrated frame-by-frame, so the sequence can be scrubbed,
 *  paused and looped deterministically – and the timings below are the single
 *  source of truth for the pacing.
 *
 *  PACING – derived from the reference clip (66.0-88.0.mp4, 24 s) and the
 *  critiques in reviews.txt:
 *
 *    film  0.0–3.0 s  overhead desk, letters start peeling off under the hand
 *    film  3.0–4.0 s  slow dissolve desk → foggy teal aerial of the city
 *    film  4.0–7.5 s  a dense, slow "snowfall" of letters, NO words yet
 *    film  7.5–8.5 s  "After Gatsby's death," condenses (death, heavier)
 *    film  8.5–9.5 s  "New York was haunted" condenses left → right
 *    film 10.0    s  first words dissolve back into the sea, camera drifts
 *    film 10.5–11.5 s "haunted" swells, "for me." settles under it
 *    film 12.0+   s  next phrase forms at the top of frame
 *
 *  reviews.txt said the fastest attempt ("fable max") zoomed out, panned and
 *  lifted letters off too quickly, while "fable low" had the right camera /
 *  lift-off pacing. So the desk part here is stretched ~2.5× and every ease is
 *  slow-in / slow-out. The city part keeps the film's own rhythm
 *  (≈1.1×): word stagger 0.35–0.45 s, words take ~2 s to condense, a beat of
 *  stillness, then a dissolve.
 */

export const TIMELINE = {
  /** Total loop length (s). */
  duration: 34,
  fadeIn: [0.0, 1.6] as const,

  /* --- I. The source: the typewriter finishes the line -------------------- */
  typingStart: 0.9,
  typingInterval: 0.072,

  /* --- II. Lift-off ------------------------------------------------------- */
  /** First letter peels off the sheet in the typewriter. */
  liftStart: 3.4,
  /** Lift-off wave spreads outward over the desk for this long. */
  liftSpread: 5.2,
  /** Random extra delay per letter (so pages don't peel in rigid rings). */
  liftJitter: 1.6,
  /** Slow peel: letter separates from the fibres (s). */
  peelDuration: 1.5,
  /** Suspension: the letter hovers a few mm above its page (s, min/max). */
  hover: [0.35, 1.25] as const,
  /** Ascent from the page into the sea of letters (s, min/max). */
  ascent: [6.2, 8.6] as const,

  /* --- Camera ------------------------------------------------------------- */
  /** Overhead pull-up (very slow ease in/out – see reviews.txt). */
  cameraRise: [1.8, 13.5] as const,
  /** Camera tilts from straight-down to the oblique aerial view. */
  cameraTilt: [10.2, 15.8] as const,

  /* --- III. Dissolve to the city ------------------------------------------ */
  deskFade: [9.6, 13.4] as const,
  cityFade: [9.4, 12.6] as const,
  /** City starts out of focus and racks into focus (fable low's best idea). */
  cityFocus: [11.0, 17.0] as const,

  /* --- V. End ------------------------------------------------------------- */
  finalDissolve: [30.6, 32.2] as const,
  fadeOut: [31.6, 33.4] as const,
};

/** Typewriter metrics (metres): 10 chars/inch pica, 6 lines/inch. */
export const TYPE = {
  cell: 0.0254 / 10,
  line: 0.0254 / 6,
  /** Glyph quad edge as a multiple of the cell width (atlas cell is square). */
  quad: 1.9,
  pageW: 0.216,
  pageH: 0.279,
  marginX: 0.024,
  marginTop: 0.026,
};

/* ========================================================================== */
/*  Quote formation                                                           */
/* ========================================================================== */
/**
 * Layout is expressed in "frame units" on a plane QUOTE_DEPTH metres in front
 * of the reference camera pose: y = ±1 is the top/bottom of the full frame,
 * x is scaled the same way (|x| ≤ 1.6 stays inside a 16:10 frame).
 *
 *  size     glyph quad size in frame units (1 = half the frame height)
 *  arrive   s – letters leave the sea and start condensing on their slot
 *  leave    s – the word dissolves back into the sea
 *  grow     optional – word swells / moves (the film's "haunted" beat)
 */
export interface QuoteWord {
  text: string;
  size: number;
  arrive: number;
  leave: number;
  bold?: boolean;
  grow?: { at: number; dur: number; scale: number; to: [number, number] };
}
export interface QuoteLine {
  words: QuoteWord[];
  /** Baseline centre in frame units (line is centred on x unless align set). */
  at: [number, number];
  /** Pushes the line towards (-) / away from (+) the camera, metres. */
  depth?: number;
}

export const QUOTE_DEPTH = 6.2;
const S = 0.125;

export const QUOTE: QuoteLine[] = [
  {
    at: [0.0, 0.08],
    words: [
      { text: "After", size: S, arrive: 16.4, leave: 21.0 },
      { text: "Gatsby's", size: S, arrive: 16.75, leave: 21.2 },
      { text: "death,", size: S * 1.75, arrive: 17.2, leave: 21.55, bold: true },
      { text: "New", size: S, arrive: 18.3, leave: 21.9 },
      { text: "York", size: S, arrive: 18.65, leave: 22.1 },
      { text: "was", size: S, arrive: 19.0, leave: 22.3 },
      {
        text: "haunted",
        size: S,
        arrive: 19.4,
        leave: 26.0,
        grow: { at: 21.7, dur: 1.9, scale: 2.1, to: [0.45, 0.0] },
      },
    ],
  },
  {
    at: [0.86, -0.24],
    words: [
      { text: "for", size: S * 1.05, arrive: 23.0, leave: 26.25 },
      { text: "me.", size: S * 1.05, arrive: 23.4, leave: 26.5 },
    ],
  },
  {
    at: [-0.45, 0.42],
    depth: 0.6,
    words: [
      { text: "distorted", size: S * 1.1, arrive: 25.9, leave: 30.6 },
      { text: "beyond", size: S * 1.1, arrive: 26.35, leave: 30.7 },
      { text: "my", size: S * 1.1, arrive: 26.75, leave: 30.8 },
      { text: "eyes'", size: S * 1.1, arrive: 27.1, leave: 30.9 },
    ],
  },
  {
    at: [0.3, 0.2],
    depth: 0.6,
    words: [
      { text: "power", size: S * 1.1, arrive: 27.7, leave: 31.0 },
      { text: "of", size: S * 1.1, arrive: 28.05, leave: 31.1 },
      { text: "correction.", size: S * 1.25, arrive: 28.4, leave: 31.2, bold: true },
    ],
  },
];

/** The line typed live on the sheet in the typewriter – its glyphs become the quote. */
export const TYPED_LINE = "New York was haunted for me.";
/** The line already on the sheet just above it. */
export const PREV_LINE = "After Gatsby's death,";

/** Phase labels for the HUD. */
export const PHASES = [
  { at: 0, label: "I · The Source", text: "Every character is a glyph printed on a real sheet of paper." },
  { at: 3.4, label: "II · Lift-off", text: "Letters peel off the fibres, hover, then rise – none appear from nowhere." },
  { at: 9.6, label: "III · Dissolve", text: "The desk gives way to the city; a sea of letters drifts in the fog." },
  { at: 16.4, label: "IV · Assembly", text: "Letters condense word by word into the quote, then scatter again." },
  { at: 30.6, label: "V · Fade", text: "The words fall back into the sea." },
];

export const PALETTE = {
  ink: [0.07, 0.06, 0.06] as const,
  airborne: [0.93, 0.93, 0.9] as const,
  cityFog: [0.33, 0.4, 0.43] as const,
};

/** World constants. Desk top is y = 0; the city ground is far below. */
export const WORLD = {
  cityGround: -205,
};
