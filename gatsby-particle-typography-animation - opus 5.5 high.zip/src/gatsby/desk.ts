import * as THREE from "three";
import { TYPE } from "./config";
import { rng } from "./texts";

/**
 * Desk + scattered manuscript pages.
 *
 * A page is a rigid flat sheet. `PagePose` is the single transform used both
 * to place the paper mesh AND to place every glyph particle printed on it, so
 * a particle's origin is by construction a real point on the paper surface.
 *
 * Page-local frame: origin at the page centre, +x along the typed line,
 * +y "up the page" (towards the top margin). World frame: desk top y = 0.
 */
export interface PagePose {
  position: THREE.Vector3;
  quaternion: THREE.Quaternion; // maps quad space (x right, y up, z normal) → world
  width: number;
  height: number;
  /** For coverage tests: world → page-local. */
  inverse: THREE.Matrix4;
  /** Fraction of the page that is typed (0..1). */
  fill: number;
  textOffset: number;
}

/** Hand-placed so the overhead opening frame reads like the film's. [x, z, rotY, fill] */
const LAYOUT: [number, number, number, number][] = [
  [0.53, -0.3, -0.42, 0.95],
  [-0.56, -0.3, -0.22, 0.9],
  [-0.52, 0.02, 0.45, 1.0],
  [0.58, 0.06, 0.1, 0.85],
  [0.1, -0.3, 0.58, 0.9],
  [-0.12, 0.4, 0.06, 1.0],
  [0.34, 0.21, -0.28, 0.95],
  [0.36, -0.12, 0.22, 1.0],
  [-0.27, 0.25, -0.16, 0.9],
  [0.07, 0.19, 0.31, 1.0],
  [0.14, -0.03, -0.12, 1.0],
];

const flatQuat = (rotY: number) =>
  new THREE.Quaternion()
    .setFromAxisAngle(new THREE.Vector3(0, 1, 0), rotY)
    .multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), -Math.PI / 2));

export function makePagePoses(): PagePose[] {
  return LAYOUT.map(([x, z, r, fill], k) => {
    const position = new THREE.Vector3(x, 0.0008 + k * 0.00045, z);
    const quaternion = flatQuat(r);
    const m = new THREE.Matrix4().compose(position, quaternion, new THREE.Vector3(1, 1, 1));
    return { position, quaternion, width: TYPE.pageW, height: TYPE.pageH, inverse: m.clone().invert(), fill, textOffset: k * 3 };
  });
}

/** Procedural aged paper: fibres, foxing, darker deckled edges. */
export function paperTexture(seed = 7): THREE.CanvasTexture {
  const w = 512;
  const h = 662;
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const g = c.getContext("2d")!;
  const r = rng(seed);
  g.fillStyle = "#efe6d2";
  g.fillRect(0, 0, w, h);
  // mottling
  for (let i = 0; i < 900; i++) {
    const x = r() * w;
    const y = r() * h;
    const rad = 4 + r() * 30;
    const grd = g.createRadialGradient(x, y, 0, x, y, rad);
    const a = 0.02 + r() * 0.035;
    grd.addColorStop(0, r() < 0.5 ? `rgba(160,130,90,${a})` : `rgba(255,255,245,${a})`);
    grd.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = grd;
    g.fillRect(x - rad, y - rad, rad * 2, rad * 2);
  }
  // fibres
  g.lineWidth = 0.6;
  for (let i = 0; i < 1400; i++) {
    const x = r() * w;
    const y = r() * h;
    const a = r() * Math.PI;
    const l = 2 + r() * 7;
    g.strokeStyle = `rgba(120,100,70,${0.04 + r() * 0.06})`;
    g.beginPath();
    g.moveTo(x, y);
    g.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l);
    g.stroke();
  }
  // foxing spots
  for (let i = 0; i < 14; i++) {
    g.fillStyle = `rgba(150,105,55,${0.05 + r() * 0.08})`;
    g.beginPath();
    g.arc(r() * w, r() * h, 0.8 + r() * 2.5, 0, Math.PI * 2);
    g.fill();
  }
  // edge burn
  const edge = g.createLinearGradient(0, 0, w, 0);
  edge.addColorStop(0, "rgba(120,90,50,0.22)");
  edge.addColorStop(0.05, "rgba(120,90,50,0)");
  edge.addColorStop(0.95, "rgba(120,90,50,0)");
  edge.addColorStop(1, "rgba(120,90,50,0.22)");
  g.fillStyle = edge;
  g.fillRect(0, 0, w, h);
  const edgeV = g.createLinearGradient(0, 0, 0, h);
  edgeV.addColorStop(0, "rgba(120,90,50,0.2)");
  edgeV.addColorStop(0.04, "rgba(120,90,50,0)");
  edgeV.addColorStop(0.96, "rgba(120,90,50,0)");
  edgeV.addColorStop(1, "rgba(120,90,50,0.25)");
  g.fillStyle = edgeV;
  g.fillRect(0, 0, w, h);
  // a faint fold crease
  g.strokeStyle = "rgba(90,70,40,0.08)";
  g.lineWidth = 2;
  g.beginPath();
  g.moveTo(0, h * 0.34);
  g.lineTo(w, h * 0.335);
  g.stroke();
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

function shadowTexture(): THREE.CanvasTexture {
  const c = document.createElement("canvas");
  c.width = c.height = 128;
  const g = c.getContext("2d")!;
  g.filter = "blur(10px)";
  g.fillStyle = "rgba(0,0,0,0.9)";
  g.fillRect(24, 24, 80, 80);
  return new THREE.CanvasTexture(c);
}

export function buildDesk(scene: THREE.Scene, deskTex: THREE.Texture, poses: PagePose[]) {
  // --- desk top ---------------------------------------------------------
  deskTex.wrapS = deskTex.wrapT = THREE.MirroredRepeatWrapping; // hides tile seams
  deskTex.repeat.set(3.2, 2.2);
  deskTex.colorSpace = THREE.SRGBColorSpace;
  deskTex.anisotropy = 8;
  const desk = new THREE.Mesh(
    new THREE.PlaneGeometry(9, 6),
    new THREE.MeshStandardMaterial({ map: deskTex, roughness: 0.48, metalness: 0.0, color: 0x9a8070 }),
  );
  desk.rotation.x = -Math.PI / 2;
  desk.receiveShadow = true;
  scene.add(desk);

  // --- pages --------------------------------------------------------------
  const sh = shadowTexture();
  const shadowMat = new THREE.MeshBasicMaterial({ map: sh, transparent: true, opacity: 0.55, depthWrite: false });
  poses.forEach((p, k) => {
    const mat = new THREE.MeshStandardMaterial({
      map: paperTexture(11 + k),
      roughness: 0.92,
      color: new THREE.Color().setHSL(0.11, 0.25, 0.86 + ((k * 37) % 10) / 100),
    });
    const page = new THREE.Mesh(new THREE.PlaneGeometry(p.width, p.height), mat);
    page.position.copy(p.position);
    page.quaternion.copy(p.quaternion);
    page.receiveShadow = true;
    scene.add(page);
    // soft contact shadow so the sheet sits on the wood
    const s = new THREE.Mesh(new THREE.PlaneGeometry(p.width * 1.32, p.height * 1.26), shadowMat);
    s.position.copy(p.position).add(new THREE.Vector3(0.004, -0.0003 - k * 0.0002, 0.006));
    s.position.y = 0.0002 + k * 0.00045;
    s.quaternion.copy(p.quaternion);
    scene.add(s);
  });

  // --- lighting: a warm desk lamp from the upper left, cool fill ---------------
  scene.add(new THREE.HemisphereLight(0xfff0dd, 0x2a1d14, 0.55));
  const key = new THREE.DirectionalLight(0xffe2b8, 2.6);
  key.position.set(-1.2, 2.4, -0.6);
  key.target.position.set(0, 0, 0);
  key.castShadow = true;
  key.shadow.mapSize.set(2048, 2048);
  const sc = key.shadow.camera as THREE.OrthographicCamera;
  sc.left = -0.8;
  sc.right = 0.8;
  sc.top = 0.8;
  sc.bottom = -0.8;
  sc.near = 0.5;
  sc.far = 5;
  key.shadow.bias = -0.0004;
  key.shadow.normalBias = 0.002;
  key.shadow.radius = 4;
  scene.add(key, key.target);
  const rim = new THREE.DirectionalLight(0x9fb8d8, 0.5);
  rim.position.set(1.5, 1.2, 1.4);
  scene.add(rim);
}
