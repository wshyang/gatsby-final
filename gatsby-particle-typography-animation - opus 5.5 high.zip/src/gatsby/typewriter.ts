import * as THREE from "three";
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js";
import { PREV_LINE, TIMELINE, TYPE, TYPED_LINE } from "./config";

/**
 * Procedural 1920s front-strike typewriter (Underwood-style), metres.
 *
 * Local frame: +x right, +y up, +z towards the typist.
 *
 * TYPE-BAR BASKET (the part reviews.txt said was rendered "corrupted" in the
 * fable max attempt): every bar pivots on the segment arc (radius R0 around
 * the printing point's projection C) and rests pointing outward. A strike is
 * a rotation about the bar's own tangent axis by STRIKE = acos(-R0 / L), which
 * geometrically places every bar's slug at the *same* printing point
 * C + (0, √(L²−R0²), 0) on the platen. Each bar is a proper Object3D
 * hierarchy (pivot → bar), Euler order 'YXZ' so yaw (fan angle) is applied
 * after the strike pitch.
 */
const KEY_ROWS = ["1234567890-", "QWERTYUIOP", "ASDFGHJKL;", "ZXCVBNM,./"];
const C = new THREE.Vector3(0, 0.068, -0.01); // basket centre (below printing point)
const R0 = 0.032;
const L = 0.07;
const STRIKE = Math.acos(-R0 / L);
const REST = 0.085;
const PRINT_Y = C.y + Math.sqrt(L * L - R0 * R0);
const PLATEN_R = 0.019;
const SHEET_TILT = THREE.MathUtils.degToRad(40);
const SHEET_LEN = 0.25;
/** Column 0 of the sheet sits under the printing point when the carriage is at this offset. */
const COL0_X = -TYPE.pageW / 2 + TYPE.marginX;

export interface Keystroke {
  ch: string;
  t: number;
}

export class Typewriter {
  readonly group = new THREE.Group();
  readonly carriage = new THREE.Group();
  private bars: THREE.Group[] = [];
  private keys = new Map<string, THREE.Object3D>();
  private spaceBar!: THREE.Mesh;
  private barIndex = new Map<string, number>();
  readonly strokes: Keystroke[] = [];

  constructor(position: THREE.Vector3, rotY: number) {
    this.group.position.copy(position);
    this.group.rotation.y = rotY;
    this.group.updateMatrixWorld(true);

    // Keystroke schedule for the live-typed line.
    for (let i = 0; i < TYPED_LINE.length; i++) {
      // slight human rhythm: pauses after spaces, quicker in the middle of words
      const prev = TYPED_LINE[i - 1];
      const jitter = Math.sin(i * 12.9898) * 0.012 + (prev === " " ? 0.05 : 0);
      const t = TIMELINE.typingStart + i * TIMELINE.typingInterval + jitter + (i > 0 ? this.strokes.length * 0 : 0);
      this.strokes.push({ ch: TYPED_LINE[i], t: Math.max(t, (this.strokes[i - 1]?.t ?? 0) + 0.045) });
    }
    this.build();
  }

  /* ------------------------------------------------------------------ */
  /* Geometry                                                            */
  /* ------------------------------------------------------------------ */
  private build() {
    const lacquer = new THREE.MeshPhysicalMaterial({ color: 0x0b0b0d, roughness: 0.28, metalness: 0.1, clearcoat: 1, clearcoatRoughness: 0.12 });
    const chrome = new THREE.MeshStandardMaterial({ color: 0xe8e8ea, metalness: 1, roughness: 0.16 });
    const steel = new THREE.MeshStandardMaterial({ color: 0x6d6d72, metalness: 0.85, roughness: 0.32 });
    const rubber = new THREE.MeshStandardMaterial({ color: 0x141414, roughness: 0.75 });
    const felt = new THREE.MeshStandardMaterial({ color: 0x1b1512, roughness: 1 });
    const gold = new THREE.MeshStandardMaterial({ color: 0xc8a24a, metalness: 1, roughness: 0.3 });
    const g = this.group;
    const add = (m: THREE.Mesh, parent: THREE.Object3D = g) => {
      m.castShadow = true;
      m.receiveShadow = true;
      parent.add(m);
      return m;
    };
    const rbox = (w: number, h: number, d: number, r: number, mat: THREE.Material) =>
      new THREE.Mesh(new RoundedBoxGeometry(w, h, d, 3, r), mat);

    // Frame
    add(rbox(0.31, 0.05, 0.32, 0.012, lacquer)).position.set(0, 0.025, 0.03);
    const sideL = add(rbox(0.026, 0.1, 0.2, 0.01, lacquer));
    sideL.position.set(-0.152, 0.05, -0.04);
    const sideR = sideL.clone();
    sideR.position.x = 0.152;
    add(sideR);
    add(rbox(0.33, 0.045, 0.06, 0.01, lacquer)).position.set(0, 0.075, -0.1);
    // gold pinstripe on the front apron
    add(new THREE.Mesh(new THREE.BoxGeometry(0.27, 0.0012, 0.0012), gold)).position.set(0, 0.03, 0.1905);
    add(new THREE.Mesh(new THREE.BoxGeometry(0.27, 0.0012, 0.0012), gold)).position.set(0, 0.012, 0.1905);

    // Keyboard deck (sloped)
    const deck = add(rbox(0.29, 0.012, 0.12, 0.004, lacquer));
    deck.position.set(0, 0.045, 0.135);
    deck.rotation.x = 0.33;

    // Basket floor (felt half disc) + segment arc
    const floor = add(new THREE.Mesh(new THREE.CircleGeometry(0.112, 48, -Math.PI / 2 - 1.42, 2.84), felt));
    floor.rotation.x = -Math.PI / 2;
    floor.position.set(C.x, 0.056, C.z);
    const seg = add(new THREE.Mesh(new THREE.TorusGeometry(R0, 0.0035, 8, 48, 2.9), chrome));
    // Torus arc a∈[0,2.9] lies in XY; Rz(0.12) centres it on a=π/2, Rx(π/2) lays it
    // in XZ so (cos a, sin a) → (cos a, 0, sin a) – exactly the bar pivot arc.
    seg.rotation.set(Math.PI / 2, 0, 0.12);
    seg.position.set(C.x, C.y - 0.002, C.z);

    // Type bars
    const all = KEY_ROWS.join("");
    const nBars = all.length;
    const barGeo = new THREE.BoxGeometry(0.0021, 0.0011, L);
    barGeo.translate(0, 0, L / 2);
    const slugGeo = new THREE.BoxGeometry(0.0034, 0.004, 0.0048);
    slugGeo.translate(0, 0.0012, L - 0.0024);
    for (let i = 0; i < nBars; i++) {
      const theta = -1.32 + (2.64 * i) / (nBars - 1);
      const dir = new THREE.Vector3(Math.sin(theta), 0, Math.cos(theta));
      const pivot = new THREE.Group();
      pivot.position.copy(C).addScaledVector(dir, R0);
      pivot.rotation.order = "YXZ";
      pivot.rotation.y = theta; // local +Z = outward radial direction
      pivot.rotation.x = REST;
      const bar = new THREE.Mesh(barGeo, steel);
      const slug = new THREE.Mesh(slugGeo, steel);
      bar.castShadow = true;
      pivot.add(bar, slug);
      g.add(pivot);
      this.bars.push(pivot);
      this.barIndex.set(all[i], i);
    }

    // Keys: black glass caps, chrome rings, white legends
    const legend = this.legendTexture(all);
    const capGeo = new THREE.CylinderGeometry(0.0072, 0.0072, 0.0032, 28);
    const ringGeo = new THREE.TorusGeometry(0.0074, 0.0009, 6, 28);
    const stemGeo = new THREE.CylinderGeometry(0.0009, 0.0009, 0.05, 6);
    let idx = 0;
    KEY_ROWS.forEach((row, r) => {
      const z = 0.098 + r * 0.0225;
      const y = 0.082 - r * 0.0072;
      const x0 = -((row.length - 1) * 0.0196) / 2 + r * 0.004 - 0.004;
      for (let k = 0; k < row.length; k++) {
        const key = new THREE.Group();
        const tex = legend.clone();
        tex.repeat.set(1 / 8, 1 / 6);
        tex.offset.set((idx % 8) / 8, 1 - (Math.floor(idx / 8) + 1) / 6);
        tex.needsUpdate = true;
        const top = new THREE.MeshPhysicalMaterial({ map: tex, roughness: 0.12, clearcoat: 1, color: 0xffffff });
        const cap = new THREE.Mesh(capGeo, [rubber, top, rubber]);
        cap.castShadow = true;
        const ring = new THREE.Mesh(ringGeo, chrome);
        ring.rotation.x = Math.PI / 2;
        ring.position.y = 0.0008;
        const stem = new THREE.Mesh(stemGeo, steel);
        stem.position.y = -0.025;
        key.add(cap, ring, stem);
        key.position.set(x0 + k * 0.0196, y, z);
        key.userData.y = y;
        g.add(key);
        this.keys.set(row[k], key);
        idx++;
      }
    });
    this.spaceBar = add(rbox(0.13, 0.005, 0.009, 0.0024, lacquer));
    this.spaceBar.position.set(0, 0.052, 0.188);
    this.spaceBar.userData.y = 0.052;

    // Ribbon spools + ribbon vibrator
    const ribbon = new THREE.MeshStandardMaterial({ color: 0x2a0d0d, roughness: 0.9 });
    for (const sx of [-0.105, 0.105]) {
      add(new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.026, 0.004, 32), chrome)).position.set(sx, 0.099, -0.085);
      add(new THREE.Mesh(new THREE.CylinderGeometry(0.019, 0.019, 0.011, 32), ribbon)).position.set(sx, 0.106, -0.085);
      add(new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.004, 0.014, 12), chrome)).position.set(sx, 0.11, -0.085);
    }
    const vib = add(new THREE.Mesh(new THREE.BoxGeometry(0.022, 0.012, 0.0012), ribbon));
    vib.position.set(0, PRINT_Y - 0.004, C.z + 0.002);

    /* ---- Carriage (slides along x while typing) ----------------------- */
    const car = this.carriage;
    g.add(car);
    const platenZ = C.z - PLATEN_R;
    const platen = add(new THREE.Mesh(new THREE.CylinderGeometry(PLATEN_R, PLATEN_R, 0.33, 40), rubber), car);
    platen.rotation.z = Math.PI / 2;
    platen.position.set(0, PRINT_Y, platenZ);
    for (const sx of [-1, 1]) {
      const knob = add(new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.016, 0.02, 32), chrome), car);
      knob.rotation.z = Math.PI / 2;
      knob.position.set(sx * 0.19, PRINT_Y, platenZ);
      const knurl = add(new THREE.Mesh(new THREE.CylinderGeometry(0.0172, 0.0172, 0.008, 24), rubber), car);
      knurl.rotation.z = Math.PI / 2;
      knurl.position.set(sx * 0.2, PRINT_Y, platenZ);
      const plate = add(rbox(0.008, 0.055, 0.075, 0.003, lacquer), car);
      plate.position.set(sx * 0.17, PRINT_Y - 0.012, platenZ - 0.012);
    }
    for (const rz of [-0.062, -0.075]) {
      const rail = add(new THREE.Mesh(new THREE.CylinderGeometry(0.0028, 0.0028, 0.36, 12), chrome), car);
      rail.rotation.z = Math.PI / 2;
      rail.position.set(0, PRINT_Y - 0.03, rz);
    }
    // paper bail with rubber rollers
    const bail = add(new THREE.Mesh(new THREE.CylinderGeometry(0.0017, 0.0017, 0.3, 10), chrome), car);
    bail.rotation.z = Math.PI / 2;
    bail.position.set(0, PRINT_Y + PLATEN_R + 0.002, platenZ + 0.006);
    for (const bx of [-0.05, 0.05]) {
      const rl = add(new THREE.Mesh(new THREE.CylinderGeometry(0.0034, 0.0034, 0.009, 14), rubber), car);
      rl.rotation.z = Math.PI / 2;
      rl.position.set(bx, bail.position.y, bail.position.z);
    }
    // carriage-return lever
    const lever = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.17, PRINT_Y + 0.006, platenZ - 0.005),
      new THREE.Vector3(-0.2, PRINT_Y + 0.022, platenZ + 0.01),
      new THREE.Vector3(-0.215, PRINT_Y + 0.03, platenZ + 0.05),
      new THREE.Vector3(-0.212, PRINT_Y + 0.028, platenZ + 0.075),
    ]);
    add(new THREE.Mesh(new THREE.TubeGeometry(lever, 24, 0.0024, 8), chrome), car);
    const leverTip = add(new THREE.Mesh(new THREE.SphereGeometry(0.0045, 16, 12), chrome), car);
    leverTip.position.set(-0.212, PRINT_Y + 0.028, platenZ + 0.077);

    // Paper: wraps over the platen and leans back. Its surface carries the sheet glyphs.
    const paperMat = new THREE.MeshStandardMaterial({ color: 0xf1e9d8, roughness: 0.9, side: THREE.DoubleSide });
    const wrap = add(new THREE.Mesh(new THREE.CylinderGeometry(PLATEN_R + 0.0006, PLATEN_R + 0.0006, TYPE.pageW, 32, 1, true, -0.2, 1.75), paperMat), car);
    wrap.rotation.z = Math.PI / 2;
    wrap.position.set(0, PRINT_Y, platenZ);
    const sheet = add(new THREE.Mesh(new THREE.PlaneGeometry(TYPE.pageW, SHEET_LEN), paperMat), car);
    const pose = this.sheetFrame();
    sheet.position.copy(pose.origin).addScaledVector(pose.up, SHEET_LEN / 2);
    sheet.quaternion.copy(pose.quat);
  }

  private legendTexture(chars: string): THREE.CanvasTexture {
    const c = document.createElement("canvas");
    c.width = 8 * 64;
    c.height = 6 * 64;
    const ctx = c.getContext("2d")!;
    ctx.fillStyle = "#0c0c0c";
    ctx.fillRect(0, 0, c.width, c.height);
    ctx.fillStyle = "#f4efe2";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.font = 'bold 30px "Special Elite", "Courier New", monospace';
    [...chars].forEach((ch, i) => {
      const cx = (i % 8) * 64 + 32;
      const cy = Math.floor(i / 8) * 64 + 32;
      ctx.save();
      ctx.translate(cx, cy);
      // CylinderGeometry top-cap UVs are rotated; counter-rotate the legend
      ctx.rotate(-Math.PI / 2);
      ctx.fillText(ch, 0, 2);
      ctx.restore();
    });
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }

  /* ------------------------------------------------------------------ */
  /* Sheet frame – the source surface for the glyphs in the typewriter     */
  /* ------------------------------------------------------------------ */
  /** Carriage-local frame of the sheet: bottom-centre origin, up-the-page, normal. */
  sheetFrame() {
    const up = new THREE.Vector3(0, Math.sin(SHEET_TILT), -Math.cos(SHEET_TILT));
    const normal = new THREE.Vector3(0, Math.cos(SHEET_TILT), Math.sin(SHEET_TILT));
    const quat = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), SHEET_TILT - Math.PI / 2);
    const origin = new THREE.Vector3(0, PRINT_Y + PLATEN_R * 0.8, C.z - PLATEN_R - PLATEN_R * 0.55);
    return { up, normal, quat, origin };
  }

  /** Carriage offset (local x, metres) that puts column `col` under the printing point. */
  static carriageFor(col: number) {
    return -(COL0_X + col * TYPE.cell);
  }

  /**
   * World position & orientation of a character cell on the sheet, with the
   * carriage at offset 0. row 0 = the live-typed line (just above the bail).
   */
  sheetGlyph(row: number, col: number) {
    const f = this.sheetFrame();
    const local = f.origin
      .clone()
      .addScaledVector(f.up, 0.011 + row * TYPE.line)
      .add(new THREE.Vector3(COL0_X + col * TYPE.cell, 0, 0))
      .addScaledVector(f.normal, 0.0004);
    const world = local.applyMatrix4(this.group.matrixWorld);
    const q = this.group.quaternion.clone().multiply(f.quat);
    return { world, quat: q };
  }

  /** World-space direction the carriage slides along. */
  carriageAxis() {
    return new THREE.Vector3(1, 0, 0).applyQuaternion(this.group.quaternion);
  }

  /** Lines already typed on the sheet (row → text). */
  static sheetLines(prevParagraph: string[]): { row: number; text: string }[] {
    const out = [{ row: 1, text: PREV_LINE }];
    prevParagraph.forEach((t, i) => out.push({ row: 3 + i, text: t }));
    return out;
  }

  /* ------------------------------------------------------------------ */
  /* Animation                                                            */
  /* ------------------------------------------------------------------ */
  /** Carriage x offset at time t (steps one cell per keystroke, with a quick ease). */
  carriageX(t: number) {
    let x = Typewriter.carriageFor(0);
    for (const s of this.strokes) {
      const k = THREE.MathUtils.clamp((t - s.t - 0.03) / 0.05, 0, 1);
      x -= TYPE.cell * k * k * (3 - 2 * k);
    }
    return x;
  }

  update(t: number) {
    this.carriage.position.x = this.carriageX(t);
    for (const b of this.bars) b.rotation.x = REST;
    this.keys.forEach((k) => (k.position.y = k.userData.y));
    this.spaceBar.position.y = this.spaceBar.userData.y;
    for (const s of this.strokes) {
      const dt = t - s.t;
      if (dt < -0.06 || dt > 0.16) continue;
      const ch = s.ch.toUpperCase();
      // key travel
      const press = dt < 0 ? 1 + dt / 0.06 : 1 - THREE.MathUtils.clamp((dt - 0.02) / 0.12, 0, 1);
      const key = ch === " " ? this.spaceBar : this.keys.get(ch === "'" ? ";" : ch === "." ? "." : ch);
      if (key) key.position.y = key.userData.y - 0.004 * press;
      if (ch === " ") continue;
      // type bar: whips up to the platen (arrives exactly at dt = 0) and falls back
      const bi = this.barIndex.get(ch) ?? this.barIndex.get(";")!;
      const up = dt < 0 ? Math.pow(1 + dt / 0.06, 2) : 1 - THREE.MathUtils.smoothstep(dt, 0.0, 0.14);
      this.bars[bi].rotation.x = REST + (-STRIKE - REST) * up;
    }
  }
}
