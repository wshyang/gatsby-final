import { useCallback, useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import Stage from "./scene/Stage";
import { PHASES, phaseFor, prefersReducedMotion, timeline } from "./scene/timeline";

/* -------------------------------------------------------------------------- */
/*  Small pieces                                                               */
/* -------------------------------------------------------------------------- */

function DecoMark({ className = "" }: { className?: string }) {
  // Hand-drawn deco mark: a lozenge frame holding three rising glyph-quads.
  return (
    <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
      <path
        d="M20 1.5 L38.5 20 L20 38.5 L1.5 20 Z"
        fill="none"
        stroke="currentColor"
        strokeWidth="1"
      />
      <path
        d="M20 6.5 L33.5 20 L20 33.5 L6.5 20 Z"
        fill="none"
        stroke="currentColor"
        strokeWidth="0.5"
        opacity="0.55"
      />
      <rect x="18.4" y="24.2" width="3.2" height="3.2" fill="currentColor" opacity="0.9" />
      <rect x="14.2" y="18.4" width="2.6" height="2.6" fill="currentColor" opacity="0.62" />
      <rect x="23.4" y="16.1" width="2.1" height="2.1" fill="currentColor" opacity="0.42" />
      <rect x="19.2" y="11.4" width="1.6" height="1.6" fill="currentColor" opacity="0.28" />
    </svg>
  );
}

function fmt(t: number) {
  const m = Math.floor(t / 60);
  const s = t - m * 60;
  return `${String(m).padStart(2, "0")}:${s.toFixed(1).padStart(4, "0")}`;
}

type Sample = {
  char: string;
  page: number;
  u: number;
  v: number;
  origin: number[];
  target: number[];
};

const n3 = (a: number[]) => a.map((v) => v.toFixed(3)).join("  ");

/* -------------------------------------------------------------------------- */
/*  Choreography copy                                                          */
/* -------------------------------------------------------------------------- */

const STEPS = [
  {
    n: "01",
    title: "Source",
    time: "t 0.00 → 0.18",
    body:
      "Three 768 × 1024 sheets are typeset in the browser. Every character is measured with measureText() as it is drawn, so its UV on the page is recorded at the moment the ink lands. Nothing is procedural — the particle's origin is literally its own printed glyph.",
  },
  {
    n: "02",
    title: "Lift-off",
    time: "t 0.18 → 0.42",
    body:
      "Each instance translates 0.012 units along the page normal before any other motion begins. The letter separates from the paper it was printed on. There is no spawn, no fade-in, no emitter: the anti-pattern this prototype exists to avoid.",
  },
  {
    n: "03",
    title: "Transit",
    time: "t 0.42 → 0.72",
    body:
      "A cheap curl field offsets airborne glyphs by up to 0.55 units and lifts them 0.6 – 2.0 units. Each tumbles about its own random axis by up to 5 radians, and grows from its typed size (0.061 u) toward its card size (0.185 u).",
  },
  {
    n: "04",
    title: "Settle",
    time: "t 0.72 → 1.00",
    body:
      "Position interpolates on mix(smoothstep, easeOutCubic, 0.7) — a magnetic, critically damped arrival. Orientation slerps from the page's own quaternion to identity, so the glyph rotates flat to camera as it lands in the letterform.",
  },
];

const CODE = `// source.ts — one row per typed character
type CharRecord = {
  char:  string;   // 'A' — keeps its identity for the whole flight
  page:  number;   // 0 | 1 | 2  -> which source mesh
  u, v:  number;   // measured UV of the printed ink
  size0: number;   // real size on the page, in world units
};

// vertex shader — the entire transition, per instance
float t = clamp((uProgress - aDelay) / (1.0 - aDelay), 0.0, 1.0);
float m = mix(t*t*(3.0-2.0*t), 1.0 - pow(1.0-t, 3.0), 0.7);

vec3 pos = mix(aOrigin, aTarget, m);   // paper  ->  quote
pos += curl(aSeed, uTime) * sin(t*PI) * 0.55;
pos.y += sin(t*PI) * (0.60 + aSeed*1.40);

float s = mix(aScale0, aScale1, m);    // typed size -> card size

// orientation: the page's own quaternion slerps to identity (camera-facing)
vec4  q = normalize(mix(aOriginQuat, vec4(0.0,0.0,0.0,1.0), m));`;

/* -------------------------------------------------------------------------- */
/*  App                                                                        */
/* -------------------------------------------------------------------------- */

export default function App() {
  const [progress, setProgress] = useState(0);
  const [showSource, setShowSource] = useState(false);
  const [count, setCount] = useState<number | null>(null);
  const [samples, setSamples] = useState<Sample[]>([]);
  const [stageReady, setStageReady] = useState(false);
  const scrubRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (prefersReducedMotion()) {
      timeline.playing = false;
      timeline.progress = 1;
      setProgress(1);
    }
  }, []);

  // Sample the mutable timeline at ~20 Hz for the DOM chrome.
  useEffect(() => {
    let raf = 0;
    let last = -1;
    const tick = () => {
      const p = timeline.progress;
      if (Math.abs(p - last) > 0.0012) {
        last = p;
        setProgress(p);
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  const onReady = useCallback((d: { count: number; samples: Sample[] }) => {
    setCount(d.count);
    setSamples(d.samples);
    setStageReady(true);
  }, []);

  const togglePlay = () => {
    if (timeline.progress >= 1) {
      timeline.progress = 0;
      timeline.playing = true;
      setProgress(0);
      return;
    }
    timeline.playing = !timeline.playing;
  };

  const onScrub = (v: number) => {
    timeline.playing = false;
    timeline.progress = v;
    setProgress(v);
  };

  const phase = phaseFor(progress);
  const headlineOpacity = Math.max(0, 1 - Math.max(0, (progress - 0.3) / 0.3));
  // The chapter readout steps aside once the quote starts claiming the frame.
  const phaseOpacity = Math.max(0, 1 - Math.max(0, (progress - 0.42) / 0.28));
  const seconds = progress * timeline.duration;

  return (
    <div className="relative min-h-screen bg-felt text-bone">
      {/* ============================ LEFT RAIL ============================ */}
      <aside className="fixed left-0 top-0 z-50 hidden h-screen w-[88px] flex-col items-center justify-between border-r border-gold/25 bg-felt/85 py-7 backdrop-blur-[2px] lg:flex">
        <a href="#top" className="text-gold transition-colors hover:text-gold-light">
          <DecoMark className="h-9 w-9" />
        </a>

        <div className="flex flex-1 items-center">
          <div className="vertical-rl caps text-[10px] text-ash">
            <span className="text-gold">Sequence 01</span>
            <span className="mx-3 opacity-40">/</span>
            <span>The Lifted Page</span>
            <span className="mx-3 opacity-40">/</span>
            <span>Particle Typography</span>
          </div>
        </div>

        <div className="flex flex-col items-center gap-3">
          <span
            className={`h-1.5 w-1.5 rounded-full ${
              timeline.playing ? "bg-gold" : "bg-ash"
            }`}
            style={{ boxShadow: timeline.playing ? "0 0 8px #c9a227" : "none" }}
          />
          <div className="vertical-rl caps text-[9px] text-ash">WebGL</div>
        </div>
      </aside>

      <main id="top" className="lg:pl-[88px]">
        {/* ============================ STAGE ============================ */}
        <section className="relative h-[100svh] min-h-[640px] w-full overflow-hidden">
          <div className="absolute inset-0">
            <Stage showSource={showSource} onReady={onReady} />
          </div>

          {/* vignette + grain, over the canvas, under the type */}
          <div className="vignette pointer-events-none absolute inset-0" />
          <div className="grain pointer-events-none absolute inset-0" />

          {/* --- title block, upper left; yields to the quote as it forms --- */}
          <div
            className="pointer-events-none absolute left-6 top-6 max-w-[min(92vw,34rem)] transition-opacity duration-500 sm:left-10 sm:top-10 md:max-w-[min(58vw,34rem)]"
            style={{ opacity: headlineOpacity }}
          >
            <div className="caps text-[10px] text-gold">
              Title Sequence Study <span className="mx-2 opacity-40">·</span> No. 07
            </div>
            <div className="rule-gold my-4 w-24" />
            <h1 className="font-display text-[clamp(2.5rem,6.2vw,5.6rem)] font-black leading-[0.86] tracking-[-0.02em] text-bone">
              The Lifted
              <br />
              <span className="italic font-normal text-gold-light">Page</span>
            </h1>
            <p className="mt-5 max-w-[34ch] font-type text-[13px] leading-[1.75] text-newsprint/85">
              Two thousand four hundred typed characters lift off three sheets of
              manuscript and settle, glyph by glyph, into the closing card.
            </p>
            {!stageReady && (
              <div className="mt-4 flex items-center gap-2">
                <span className="h-1 w-1 animate-pulse rounded-full bg-gold" />
                <span className="caps text-[9px] text-ash">Typesetting source pages…</span>
              </div>
            )}
          </div>

          {/* --- live phase readout, right edge --- */}
          <div
            className="pointer-events-none absolute right-6 top-1/2 hidden -translate-y-1/2 text-right transition-opacity duration-500 md:block"
            style={{ opacity: phaseOpacity }}
          >
            <div className="caps text-[9px] text-ash">Phase</div>
            <div className="font-display text-[2.1rem] italic leading-none text-gold-light">
              {phase.label}
            </div>
            <div className="mt-2 max-w-[15rem] font-type text-[11px] leading-relaxed text-newsprint/60">
              {phase.note}
            </div>
            <div className="mt-5 flex justify-end gap-[3px]">
              {PHASES.map((p) => (
                <span
                  key={p.key}
                  className={`h-[2px] transition-all duration-300 ${
                    progress >= p.at ? "w-7 bg-gold" : "w-4 bg-ash/50"
                  }`}
                />
              ))}
            </div>
          </div>

          {/* --- control deck --- */}
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-felt via-felt/85 to-transparent px-6 pb-6 pt-16 sm:px-10">
            <div className="rule-gold mb-4 opacity-60" />
            <div className="flex flex-wrap items-center gap-x-6 gap-y-4">
              <button
                onClick={togglePlay}
                className="caps flex items-center gap-2.5 border border-gold/40 px-4 py-2 text-[10px] text-gold transition-colors hover:border-gold hover:bg-gold hover:text-felt"
                aria-label={timeline.playing ? "Pause sequence" : "Play sequence"}
              >
                <span className="block h-0 w-0 border-y-[5px] border-l-[8px] border-y-transparent border-l-current" />
                {timeline.progress >= 1 ? "Replay" : timeline.playing ? "Pause" : "Play"}
              </button>

              <div className="flex min-w-[240px] flex-1 items-center gap-4">
                <span className="tnum caps text-[10px] text-ash">{fmt(seconds)}</span>
                <input
                  ref={scrubRef}
                  type="range"
                  className="scrub w-full"
                  min={0}
                  max={1000}
                  step={1}
                  value={Math.round(progress * 1000)}
                  onChange={(e) => onScrub(Number(e.target.value) / 1000)}
                  aria-label="Scrub the sequence timeline"
                />
                <span className="tnum caps text-[10px] text-ash">
                  {fmt(timeline.duration)}
                </span>
              </div>

              <button
                onClick={() => setShowSource((s) => !s)}
                className={`caps flex items-center gap-2.5 border px-4 py-2 text-[10px] transition-colors ${
                  showSource
                    ? "border-inkblue bg-inkblue text-bone"
                    : "border-ash/50 text-ash hover:border-inkblue hover:text-[#6fa8cf]"
                }`}
                aria-pressed={showSource}
              >
                <span
                  className={`block h-2 w-2 ${
                    showSource ? "bg-[#6fa8cf]" : "border border-current"
                  }`}
                />
                Source coords
              </button>

              <div className="caps flex items-center gap-2.5 border border-gold/25 px-4 py-2 text-[10px] text-gold-light">
                <span className="text-ash">Phase</span>
                <span className="h-2 w-px bg-gold/30" />
                {phase.label}
              </div>

              <div className="caps tnum text-[10px] text-ash">
                Glyphs <span className="ml-2 text-gold">{count ? count.toLocaleString() : "—"}</span>
              </div>
            </div>
          </div>
        </section>

        {/* ============================ QUOTE BAND ============================ */}
        <section className="relative overflow-hidden border-y border-gold/20 bg-felt-2">
          <div className="grain pointer-events-none absolute inset-0" />
          <div className="relative mx-auto grid max-w-[1240px] grid-cols-1 gap-10 px-6 py-24 sm:px-10 lg:grid-cols-12 lg:gap-6 lg:py-32">
            <div className="lg:col-span-3">
              <div className="caps text-[10px] text-gold">The Card</div>
              <div className="rule-gold my-4 w-16" />
              <p className="font-type text-[12px] leading-[1.9] text-newsprint/65">
                Card 01 of the sequence. Every letter below arrived from a typed
                page — the source line sits at page 3, line 8, of the manuscript
                drifting over the desk.
              </p>
            </div>

            <figure className="lg:col-span-9">
              <blockquote className="font-display text-[clamp(1.95rem,4.4vw,4.15rem)] font-bold leading-[1.06] tracking-[-0.015em] text-bone">
                <span className="text-gold">“</span>After Gatsby’s death, New York
                was haunted for me —{" "}
                <span className="italic font-normal text-gold-light">
                  until I stopped haunting it.
                </span>
                <span className="text-gold">”</span>
              </blockquote>
              <figcaption className="mt-10 flex flex-wrap items-baseline gap-x-5 gap-y-2">
                <span className="rule-gold hidden w-16 sm:block" />
                <span className="caps text-[10px] text-gold">
                  F. Scott Fitzgerald
                </span>
                <span className="font-type text-[11px] text-ash">
                  The Great Gatsby, 1925 — closing pages, set for the 2013 title sequence
                </span>
              </figcaption>
            </figure>
          </div>
        </section>

        {/* ============================ BREAKDOWN ============================ */}
        <section className="relative mx-auto max-w-[1240px] px-6 py-24 sm:px-10 lg:py-32">
          <header className="mb-16 flex flex-wrap items-end justify-between gap-6">
            <div>
              <div className="caps text-[10px] text-gold">Breakdown Sheet</div>
              <h2 className="mt-4 font-display text-[clamp(2rem,4.6vw,3.6rem)] font-black leading-[0.95] tracking-[-0.02em]">
                Paper coordinates,
                <br />
                <span className="italic font-normal text-gold-light">quoted back.</span>
              </h2>
            </div>
            <p className="max-w-[38ch] font-type text-[12px] leading-[1.95] text-newsprint/70">
              The mapping is the deliverable. Below is the full path a single
              character takes, from the UV where its ink was printed to the pixel
              inside a letterform it is destined to fill.
            </p>
          </header>

          {/* asymmetric 5/12 + 7/12 split with hanging numerals */}
          <div className="grid grid-cols-1 gap-x-12 gap-y-16 lg:grid-cols-12">
            <div className="lg:col-span-5">
              <ol className="space-y-11">
                {STEPS.map((s, i) => (
                  <motion.li
                    key={s.n}
                    initial={{ opacity: 0, y: 18 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: "-80px" }}
                    transition={{ duration: 0.55, delay: i * 0.07, ease: [0.16, 1, 0.3, 1] }}
                    className="relative pl-[4.25rem]"
                  >
                    <span className="absolute left-0 top-[-0.55rem] font-display text-[2.65rem] font-black leading-none text-gold/35 tnum">
                      {s.n}
                    </span>
                    <h3 className="caps-tight text-[11px] text-gold">{s.title}</h3>
                    <div className="caps tnum mt-1.5 text-[9px] text-ash">{s.time}</div>
                    <p className="mt-3 font-type text-[12.5px] leading-[1.95] text-newsprint/80">
                      {s.body}
                    </p>
                  </motion.li>
                ))}
              </ol>
            </div>

            <div className="lg:col-span-7">
              <div className="border border-gold/25 bg-felt-2">
                <div className="flex items-center justify-between border-b border-gold/20 px-5 py-3">
                  <span className="caps text-[9px] text-gold">
                    GlyphInstance — data mapping
                  </span>
                  <span className="caps text-[9px] text-ash">src/scene/source.ts</span>
                </div>
                <pre className="overflow-x-auto px-5 py-6 font-type text-[11px] leading-[1.85] text-newsprint/85">
                  <code>{CODE}</code>
                </pre>
              </div>

              <div className="mt-8 grid grid-cols-2 gap-px border border-gold/20 bg-gold/20 sm:grid-cols-4">
                {[
                  ["2,400", "glyph instances"],
                  ["3", "source plates"],
                  ["1", "glyph atlas, 16 × 8"],
                  ["0", "particles spawned"],
                ].map(([a, b]) => (
                  <div key={b} className="bg-felt px-5 py-6">
                    <div className="tnum font-display text-[1.85rem] font-black leading-none text-gold">
                      {a}
                    </div>
                    <div className="caps mt-2 text-[9px] leading-[1.5] text-ash">{b}</div>
                  </div>
                ))}
              </div>

              <p className="mt-8 border-l border-gold/30 pl-5 font-type text-[12px] leading-[1.95] text-newsprint/70">
                The last figure is the point of the whole exercise. A conventional
                particle text effect draws letters out of empty air; this one can
                only ever move ink that already exists. Toggle{" "}
                <span className="text-[#6fa8cf]">Source coords</span> in the deck
                above to see every thread the glyph travels along.
              </p>
            </div>
          </div>
        </section>

        {/* ============================ DATA TABLE ============================ */}
        <section className="border-t border-gold/20 bg-felt-2">
          <div className="mx-auto max-w-[1240px] px-6 py-20 sm:px-10">
            <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
              <div>
                <div className="caps text-[10px] text-gold">Source Register</div>
                <h2 className="mt-3 font-display text-[1.9rem] font-bold leading-none">
                  Six glyphs, traced
                </h2>
              </div>
              <div className="caps text-[9px] text-ash">
                Live values · world units · sampled from the running scene
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full min-w-[720px] border-collapse text-left">
                <thead>
                  <tr className="border-y border-gold/25">
                    {["#", "Glyph", "Plate", "UV", "Origin xyz", "Target xyz"].map((h) => (
                      <th
                        key={h}
                        className="caps px-3 py-4 text-[9px] font-semibold text-gold"
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {samples.length === 0 && (
                    <tr>
                      <td
                        colSpan={6}
                        className="px-3 py-10 text-center font-type text-[12px] text-ash"
                      >
                        Register populates once the source pages have been typeset…
                      </td>
                    </tr>
                  )}
                  {samples.map((s, i) => (
                    <tr
                      key={i}
                      className="border-b border-gold/10 transition-colors hover:bg-gold/[0.06]"
                    >
                      <td className="tnum px-3 py-4 text-[11px] text-ash">
                        {String(i + 1).padStart(2, "0")}
                      </td>
                      <td className="px-3 py-4">
                        <span className="inline-flex h-7 w-7 items-center justify-center border border-gold/35 font-type text-[13px] text-gold-light">
                          {s.char}
                        </span>
                      </td>
                      <td className="tnum px-3 py-4 text-[11px] text-newsprint/75">
                        PAGE {s.page + 1}
                      </td>
                      <td className="tnum px-3 py-4 text-[11px] text-newsprint/75">
                        {s.u.toFixed(4)}, {s.v.toFixed(4)}
                      </td>
                      <td className="tnum px-3 py-4 text-[11px] text-[#6fa8cf]">
                        {n3(s.origin)}
                      </td>
                      <td className="tnum px-3 py-4 text-[11px] text-gold">
                        {n3(s.target)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>

        {/* ============================ FOOTER ============================ */}
        <footer className="border-t border-gold/20">
          <div className="mx-auto max-w-[1240px] px-6 py-16 sm:px-10">
            <div className="rule-gold mb-10" />
            <div className="flex flex-wrap items-start justify-between gap-10">
              <div className="flex items-start gap-5">
                <DecoMark className="h-10 w-10 shrink-0 text-gold" />
                <div>
                  <div className="caps text-[10px] text-gold">The Lifted Page</div>
                  <p className="mt-3 max-w-[42ch] font-type text-[11.5px] leading-[1.95] text-ash">
                    A WebGL particle-typography prototype built as a companion to
                    the typewriter-and-pages sequence referenced from{" "}
                    <span className="text-newsprint/80">wshyang/gatsby-final</span>.
                    Three.js instanced geometry, custom GLSL, no post-processing.
                  </p>
                </div>
              </div>

              <dl className="grid grid-cols-2 gap-x-10 gap-y-5">
                {[
                  ["Type", "Playfair Display · Special Elite · Barlow Condensed"],
                  ["Runtime", "Three.js · React Three Fiber · GLSL"],
                  ["Instances", count ? `${count.toLocaleString()} glyph quads` : "—"],
                  ["Constraint", "Every glyph originates on a source mesh"],
                ].map(([k, v]) => (
                  <div key={k}>
                    <dt className="caps text-[9px] text-gold">{k}</dt>
                    <dd className="mt-2 max-w-[24ch] font-type text-[11px] leading-[1.8] text-newsprint/65">
                      {v}
                    </dd>
                  </div>
                ))}
              </dl>
            </div>

            <div className="caps mt-14 flex flex-wrap items-center justify-between gap-4 text-[9px] text-ash">
              <span>Sequence study · non-commercial · tribute</span>
              <span className="tnum">
                {count ? count.toLocaleString() : "—"} / 2,400 characters traced from paper
              </span>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
}
