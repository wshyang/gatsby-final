/**
 * ============================================================================
 *  Stage.tsx — the WebGL runtime
 * ============================================================================
 *  Three plates lie on a desk. 2,400 typed characters sit exactly on top of
 *  their own printed ink. The timeline lifts them off along the page normal,
 *  tumbles them through a curl field, and settles them into the quote hanging
 *  over the skyline.
 *
 *  Everything the GPU needs per glyph is an instanced attribute — see
 *  source.ts for how those arrays are filled.
 * ============================================================================
 */

import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";

import paperUrl from "../assets/paper.jpg";
import skylineUrl from "../assets/skyline.jpg";
import typewriterUrl from "../assets/typewriter.jpg";
import { timeline } from "./timeline";
import {
  ATLAS_ROWS,
  ATLAS_COLS,
  PAGE_H,
  PAGE_W,
  PARTICLE_COUNT,
  QUOTE_ORIGIN,
  assembleInstances,
  buildGlyphAtlas,
  buildPagePlates,
  type InstanceSet,
  type Plate,
  type Atlas,
} from "./source";

/* -------------------------------------------------------------------------- */
/*  Asset + font bootstrap                                                     */
/* -------------------------------------------------------------------------- */

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => resolve(img);
    // Resolve even on failure: the page texture degrades to flat bone stock.
    img.onerror = () => resolve(img);
    img.src = src;
  });
}

async function waitForFonts() {
  try {
    await Promise.all([
      (document as any).fonts?.load('21px "Special Elite"'),
      (document as any).fonts?.load('700 142px "Playfair Display"'),
      (document as any).fonts?.load('italic 700 186px "Playfair Display"'),
    ]);
    await (document as any).fonts?.ready;
  } catch {
    /* font loading is a nicety, never a blocker */
  }
}

export type SceneData = {
  atlas: Atlas;
  plates: Plate[];
  instances: InstanceSet;
};

/* -------------------------------------------------------------------------- */
/*  Camera choreography                                                        */
/* -------------------------------------------------------------------------- */

type Key = { t: number; pos: [number, number, number]; look: [number, number, number] };

const CAM_KEYS: Key[] = [
  // 0.00 — high three-quarter over the desk: pages fill the lower frame,
  //        the lit typewriter plate fills the band above the desk edge.
  { t: 0.0, pos: [0.65, 2.75, 4.85], look: [0.1, 1.05, -0.55] },
  // 0.24 — the first glyphs are airborne; camera starts to rise and tilt up.
  { t: 0.24, pos: [0.45, 3.55, 6.9], look: [0.12, 1.85, -1.5] },
  // 0.60 — the transfer shot: source pages at the bottom of frame, the quote
  //        assembling at the top of it, swarm between them.
  { t: 0.6, pos: [0.15, 4.25, 8.7], look: [0.05, 2.35, -2.7] },
  // 0.84 — settling; the card takes the frame.
  { t: 0.84, pos: [0.02, 5.35, 9.25], look: [0.0, 5.05, -4.3] },
  // 1.00 — hold on the finished card.
  { t: 1.0, pos: [0.0, 5.6, 9.2], look: [0.0, 5.6, -5.0] },
];

const lookAt = new THREE.Vector3();

function sampleCamera(p: number, outPos: THREE.Vector3, outLook: THREE.Vector3) {
  let i = 0;
  while (i < CAM_KEYS.length - 2 && p > CAM_KEYS[i + 1].t) i++;
  const a = CAM_KEYS[i];
  const b = CAM_KEYS[i + 1];
  const raw = THREE.MathUtils.clamp((p - a.t) / (b.t - a.t), 0, 1);
  const t = raw * raw * (3 - 2 * raw);
  outPos.set(
    THREE.MathUtils.lerp(a.pos[0], b.pos[0], t),
    THREE.MathUtils.lerp(a.pos[1], b.pos[1], t),
    THREE.MathUtils.lerp(a.pos[2], b.pos[2], t),
  );
  outLook.set(
    THREE.MathUtils.lerp(a.look[0], b.look[0], t),
    THREE.MathUtils.lerp(a.look[1], b.look[1], t),
    THREE.MathUtils.lerp(a.look[2], b.look[2], t),
  );
}

/* -------------------------------------------------------------------------- */
/*  Glyph cloud — the instanced shader                                         */
/* -------------------------------------------------------------------------- */

const GLYPH_VERT = /* glsl */ `
  attribute vec3 aOrigin;
  attribute vec3 aTarget;
  attribute vec4 aOriginQuat;
  attribute vec2 aUvOffset;
  attribute float aScale0;
  attribute float aScale1;
  attribute float aDelay;
  attribute vec3 aAxis;
  attribute float aSpin;
  attribute float aSeed;

  uniform float uProgress;
  uniform float uTime;
  uniform vec2 uAtlasCell;

  varying vec2 vUv;
  varying float vT;
  varying float vFlight;

  vec3 qrot(vec4 q, vec3 v) {
    return v + 2.0 * cross(q.xyz, cross(q.xyz, v) + q.w * v);
  }

  void main() {
    // Per-glyph progress: a delayed, eased lerp along the whole path.
    float t = clamp((uProgress - aDelay) / max(0.0001, 1.0 - aDelay), 0.0, 1.0);
    float smoothT = t * t * (3.0 - 2.0 * t);
    float settleT = 1.0 - pow(1.0 - t, 3.0);   // critically damped arrival
    float m = mix(smoothT, settleT, 0.7);

    float flight = sin(t * 3.14159265);         // 0 at both ends of the journey

    vec3 pos = mix(aOrigin, aTarget, m);

    // Cheap curl field — the "dust in a light shaft" drift while airborne.
    vec3 curl = vec3(
      sin(aSeed * 6.2831 + uTime * 0.50 + pos.y * 0.55 + pos.z * 0.30),
      cos(aSeed * 4.7123 + uTime * 0.38 + pos.x * 0.42),
      sin(aSeed * 9.4247 + uTime * 0.31 + pos.x * 0.25 + pos.y * 0.20)
    );
    pos += curl * flight * 0.55;
    pos.y += flight * (0.60 + aSeed * 1.40);    // letters always rise first

    float s = mix(aScale0, aScale1, m);

    // Orientation: the page's own quaternion -> camera-facing.
    vec4 q = normalize(mix(aOriginQuat, vec4(0.0, 0.0, 0.0, 1.0), m));
    float ang = aSpin * flight * 5.0;
    float ha = ang * 0.5;
    vec3 an = normalize(aAxis);
    vec4 tq = vec4(an * sin(ha), cos(ha));

    vec3 local = position * s;
    local = qrot(q, local);
    local = qrot(tq, local);

    vec4 world = modelMatrix * vec4(pos, 1.0);
    world.xyz += local;

    gl_Position = projectionMatrix * viewMatrix * world;

    vUv = aUvOffset + uv * uAtlasCell;
    vT = t;
    vFlight = flight;
  }
`;

const GLYPH_FRAG = /* glsl */ `
  uniform sampler2D uAtlas;
  uniform vec3 uInk;
  uniform vec3 uGold;

  varying vec2 vUv;
  varying float vT;
  varying float vFlight;

  void main() {
    vec4 tex = texture2D(uAtlas, vUv);
    float a = tex.a;
    if (a < 0.03) discard;
    // Ink on paper -> gold leaf in the air.
    vec3 col = mix(uInk, uGold, smoothstep(0.10, 0.55, vT));
    col *= 1.0 - vFlight * 0.12;
    gl_FragColor = vec4(col, a * (0.88 + 0.12 * vT));
  }
`;

function GlyphCloud({ data }: { data: SceneData }) {
  const { camera, size } = useThree();

  const mesh = useMemo(() => {
    const inst = data.instances;
    const n = inst.records.length;

    const base = new THREE.PlaneGeometry(1, 1);
    const geo = new THREE.InstancedBufferGeometry();
    geo.index = base.index;
    geo.setAttribute("position", base.getAttribute("position"));
    geo.setAttribute("uv", base.getAttribute("uv"));
    geo.instanceCount = n;

    geo.setAttribute("aOrigin", new THREE.InstancedBufferAttribute(inst.origin, 3));
    geo.setAttribute("aTarget", new THREE.InstancedBufferAttribute(inst.target, 3));
    geo.setAttribute("aOriginQuat", new THREE.InstancedBufferAttribute(inst.originQuat, 4));
    geo.setAttribute("aUvOffset", new THREE.InstancedBufferAttribute(inst.uvOffset, 2));
    geo.setAttribute("aScale0", new THREE.InstancedBufferAttribute(inst.scale0, 1));
    geo.setAttribute("aScale1", new THREE.InstancedBufferAttribute(inst.scale1, 1));
    geo.setAttribute("aDelay", new THREE.InstancedBufferAttribute(inst.delay, 1));
    geo.setAttribute("aAxis", new THREE.InstancedBufferAttribute(inst.axis, 3));
    geo.setAttribute("aSpin", new THREE.InstancedBufferAttribute(inst.spin, 1));
    geo.setAttribute("aSeed", new THREE.InstancedBufferAttribute(inst.seed, 1));

    const material = new THREE.ShaderMaterial({
      vertexShader: GLYPH_VERT,
      fragmentShader: GLYPH_FRAG,
      transparent: true,
      depthWrite: true,
      side: THREE.DoubleSide,
      uniforms: {
        uProgress: { value: 0 },
        uTime: { value: 0 },
        uAtlas: { value: data.atlas.texture },
        uAtlasCell: { value: new THREE.Vector2(1 / ATLAS_COLS, 1 / ATLAS_ROWS) },
        uInk: { value: new THREE.Color("#231d17") },
        uGold: { value: new THREE.Color("#e2bd52") },
      },
    });

    const m = new THREE.Mesh(geo, material);
    m.frustumCulled = false;
    return m;
  }, [data]);

  const tmpPos = useMemo(() => new THREE.Vector3(), []);
  const tmpLook = useMemo(() => new THREE.Vector3(), []);

  useFrame((state, delta) => {
    const mat = mesh.material as THREE.ShaderMaterial;

    if (timeline.playing && !timeline.scrubbing) {
      timeline.progress = Math.min(1, timeline.progress + delta / timeline.duration);
      if (timeline.progress >= 1) timeline.playing = false;
    }

    mat.uniforms.uProgress.value = timeline.progress;
    mat.uniforms.uTime.value = state.clock.elapsedTime;

    // Camera
    sampleCamera(timeline.progress, tmpPos, tmpLook);
    const aspect = size.width / Math.max(1, size.height);
    // Portrait viewports need the camera pulled back so the 12-unit quote
    // plate still fits inside the frustum.
    const zoom = THREE.MathUtils.clamp(1.6 / aspect, 1, 3.4);
    tmpPos.sub(tmpLook).multiplyScalar(zoom).add(tmpLook);
    camera.position.lerp(tmpPos, 1 - Math.pow(0.001, delta));
    lookAt.lerp(tmpLook, 1 - Math.pow(0.001, delta));
    camera.lookAt(lookAt);
    camera.updateMatrixWorld();
  });

  return <primitive object={mesh} />;
}

/* -------------------------------------------------------------------------- */
/*  Source-coordinate threads (the debug overlay)                              */
/* -------------------------------------------------------------------------- */

function SourceThreads({ data, visible }: { data: SceneData; visible: boolean }) {
  const line = useMemo(() => {
    const inst = data.instances;
    const n = inst.records.length;
    const pos = new Float32Array(n * 6);
    const col = new Float32Array(n * 6);
    const a = new THREE.Color("#3f6d94");
    const b = new THREE.Color("#9fd2f2");
    for (let i = 0; i < n; i++) {
      pos[i * 6 + 0] = inst.origin[i * 3 + 0];
      pos[i * 6 + 1] = inst.origin[i * 3 + 1];
      pos[i * 6 + 2] = inst.origin[i * 3 + 2];
      pos[i * 6 + 3] = inst.target[i * 3 + 0];
      pos[i * 6 + 4] = inst.target[i * 3 + 1];
      pos[i * 6 + 5] = inst.target[i * 3 + 2];
      col[i * 6 + 0] = a.r;
      col[i * 6 + 1] = a.g;
      col[i * 6 + 2] = a.b;
      col[i * 6 + 3] = b.r;
      col[i * 6 + 4] = b.g;
      col[i * 6 + 5] = b.b;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    g.setAttribute("color", new THREE.BufferAttribute(col, 3));
    const m = new THREE.LineBasicMaterial({
      vertexColors: true,
      transparent: true,
      opacity: 0.0,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    return new THREE.LineSegments(g, m);
  }, [data]);

  useFrame((_, delta) => {
    const mat = line.material as THREE.LineBasicMaterial;
    const target = visible ? 0.38 : 0;
    mat.opacity += (target - mat.opacity) * Math.min(1, delta * 5);
    line.visible = mat.opacity > 0.004;
  });

  return <primitive object={line} />;
}

/* -------------------------------------------------------------------------- */
/*  Dust motes                                                                 */
/* -------------------------------------------------------------------------- */

const DUST_VERT = /* glsl */ `
  attribute float aSeed;
  attribute float aSize;
  uniform float uTime;
  varying float vA;
  void main() {
    vec3 p = position;
    p.x += sin(uTime * 0.11 + aSeed * 6.2831) * 0.9;
    p.y += sin(uTime * 0.08 + aSeed * 11.0) * 1.1;
    p.z += cos(uTime * 0.09 + aSeed * 7.7) * 0.9;
    vec4 mv = modelViewMatrix * vec4(p, 1.0);
    gl_PointSize = aSize * (240.0 / max(0.001, -mv.z));
    gl_Position = projectionMatrix * mv;
    vA = 0.30 + 0.70 * abs(sin(uTime * 0.45 + aSeed * 20.0));
  }
`;

const DUST_FRAG = /* glsl */ `
  uniform vec3 uColor;
  varying float vA;
  void main() {
    float d = length(gl_PointCoord - 0.5);
    if (d > 0.5) discard;
    gl_FragColor = vec4(uColor, (1.0 - d * 2.0) * vA * 0.42);
  }
`;

function Dust() {
  const points = useMemo(() => {
    const count = 520;
    const pos = new Float32Array(count * 3);
    const seed = new Float32Array(count);
    const size = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      pos[i * 3 + 0] = (Math.random() - 0.5) * 18;
      pos[i * 3 + 1] = Math.random() * 13 - 0.5;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 14 - 1;
      seed[i] = Math.random();
      size[i] = 0.6 + Math.random() * 1.9;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    g.setAttribute("aSeed", new THREE.BufferAttribute(seed, 1));
    g.setAttribute("aSize", new THREE.BufferAttribute(size, 1));
    const m = new THREE.ShaderMaterial({
      vertexShader: DUST_VERT,
      fragmentShader: DUST_FRAG,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      uniforms: {
        uTime: { value: 0 },
        uColor: { value: new THREE.Color("#e8ce7a") },
      },
    });
    return new THREE.Points(g, m);
  }, []);

  useFrame((state) => {
    (points.material as THREE.ShaderMaterial).uniforms.uTime.value = state.clock.elapsedTime;
  });

  return <primitive object={points} />;
}

/* -------------------------------------------------------------------------- */
/*  Soft glow sprite (light shaft + quote halo)                                */
/* -------------------------------------------------------------------------- */

function glowTexture() {
  const c = document.createElement("canvas");
  c.width = c.height = 256;
  const ctx = c.getContext("2d")!;
  const g = ctx.createRadialGradient(128, 128, 0, 128, 128, 128);
  g.addColorStop(0, "rgba(255,232,180,1)");
  g.addColorStop(0.32, "rgba(226,189,82,0.42)");
  g.addColorStop(0.68, "rgba(201,162,39,0.12)");
  g.addColorStop(1, "rgba(201,162,39,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 256, 256);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/* -------------------------------------------------------------------------- */
/*  Scene assembly                                                             */
/* -------------------------------------------------------------------------- */

function Scene({
  data,
  textures,
  showSource,
}: {
  data: SceneData;
  textures: { typewriter: THREE.Texture | null; skyline: THREE.Texture | null };
  showSource: boolean;
}) {
  const glow = useMemo(glowTexture, []);
  const typewriterRef = useRef<THREE.MeshBasicMaterial>(null);
  const skylineRef = useRef<THREE.MeshBasicMaterial>(null);
  const haloRef = useRef<THREE.MeshBasicMaterial>(null);

  useFrame(() => {
    const p = timeline.progress;
    if (typewriterRef.current) {
      typewriterRef.current.opacity = THREE.MathUtils.clamp(1 - (p - 0.12) / 0.34, 0.05, 1);
    }
    if (skylineRef.current) {
      skylineRef.current.opacity = THREE.MathUtils.clamp((p - 0.3) / 0.36, 0, 1) * 0.92;
    }
    if (haloRef.current) {
      haloRef.current.opacity = THREE.MathUtils.clamp((p - 0.35) / 0.5, 0, 1) * 0.55;
    }
  });

  return (
    <>
      <color attach="background" args={["#141210"]} />
      <fogExp2 attach="fog" args={["#141210", 0.026]} />

      {/* --- lighting: one warm key, a cool rim, a low amber fill --- */}
      <ambientLight intensity={0.42} color="#6b6256" />
      <directionalLight position={[-5, 9, 4]} intensity={1.45} color="#e8ce7a" />
      <directionalLight position={[7, 5, -8]} intensity={0.5} color="#4a7699" />
      <pointLight position={[2.4, 3.2, 2.2]} intensity={16} distance={14} decay={2} color="#c9a227" />

      {/* --- the desk --- */}
      <mesh rotation-x={-Math.PI / 2} position-y={0} receiveShadow>
        <planeGeometry args={[70, 70]} />
        <meshStandardMaterial color="#1a1713" roughness={0.94} metalness={0.06} />
      </mesh>

      {/* --- typewriter plate (the lit backdrop) --- */}
      <mesh position={[0, 2.55, -8.5]}>
        <planeGeometry args={[23, 15.3]} />
        <meshBasicMaterial
          ref={typewriterRef}
          map={textures.typewriter ?? undefined}
          color="#9b9184"
          transparent
          opacity={1}
          depthWrite={false}
          toneMapped={false}
        />
      </mesh>

      {/* --- the skyline, held far back and hazed --- */}
      <mesh position={[0, 6.4, -17]}>
        <planeGeometry args={[50, 33.3]} />
        <meshBasicMaterial
          ref={skylineRef}
          map={textures.skyline ?? undefined}
          color="#a8977a"
          transparent
          opacity={0}
          depthWrite={false}
          toneMapped={false}
        />
      </mesh>

      {/* --- halo behind the quote --- */}
      <mesh position={[QUOTE_ORIGIN.x, QUOTE_ORIGIN.y, QUOTE_ORIGIN.z - 1.6]}>
        <planeGeometry args={[26, 20]} />
        <meshBasicMaterial
          ref={haloRef}
          map={glow}
          transparent
          opacity={0}
          depthWrite={false}
          blending={THREE.AdditiveBlending}
          toneMapped={false}
        />
      </mesh>

      {/* --- the three typed pages: the SOURCE MESHES --- */}
      {data.plates.map((plate, i) => (
        <mesh
          key={i}
          position={plate.transform.position}
          rotation={plate.transform.rotation}
        >
          <planeGeometry args={[PAGE_W, PAGE_H]} />
          <meshStandardMaterial map={plate.texture} roughness={0.92} metalness={0.02} />
        </mesh>
      ))}

      {/* --- warm pool of light on the desk, under the pages --- */}
      <mesh rotation-x={-Math.PI / 2} position={[0, 0.006, 0.2]}>
        <planeGeometry args={[13, 13]} />
        <meshBasicMaterial
          map={glow}
          transparent
          opacity={0.24}
          depthWrite={false}
          blending={THREE.AdditiveBlending}
          toneMapped={false}
        />
      </mesh>

      <Dust />
      <SourceThreads data={data} visible={showSource} />
      <GlyphCloud data={data} />
    </>
  );
}

/* -------------------------------------------------------------------------- */
/*  Public component                                                           */
/* -------------------------------------------------------------------------- */

export default function Stage({
  showSource,
  onReady,
}: {
  showSource: boolean;
  onReady?: (d: { count: number; samples: { char: string; page: number; u: number; v: number; origin: number[]; target: number[] }[] }) => void;
}) {
  const [data, setData] = useState<SceneData | null>(null);
  const [textures, setTextures] = useState<{
    typewriter: THREE.Texture | null;
    skyline: THREE.Texture | null;
  }>({ typewriter: null, skyline: null });

  useEffect(() => {
    let cancelled = false;

    (async () => {
      await waitForFonts();
      const [paperImg] = await Promise.all([
        loadImage(paperUrl),
        loadImage(typewriterUrl),
        loadImage(skylineUrl),
      ]);
      if (cancelled) return;

      const loader = new THREE.TextureLoader();
      const typeTex = loader.load(typewriterUrl);
      typeTex.colorSpace = THREE.SRGBColorSpace;
      const skyTex = loader.load(skylineUrl);
      skyTex.colorSpace = THREE.SRGBColorSpace;
      setTextures({ typewriter: typeTex, skyline: skyTex });

      const atlas = buildGlyphAtlas();
      const { plates, records } = buildPagePlates(paperImg.width ? paperImg : null);
      const instances = assembleInstances(records, plates, atlas, PARTICLE_COUNT);

      if (cancelled) return;
      setData({ atlas, plates, instances });

      onReady?.({
        count: instances.records.length,
        samples: instances.records.slice(0, 6).map((r, i) => ({
          char: r.char,
          page: r.page,
          u: r.u,
          v: r.v,
          origin: [
            instances.origin[i * 3],
            instances.origin[i * 3 + 1],
            instances.origin[i * 3 + 2],
          ],
          target: [
            instances.target[i * 3],
            instances.target[i * 3 + 1],
            instances.target[i * 3 + 2],
          ],
        })),
      });
    })();

    return () => {
      cancelled = true;
    };
  }, [onReady]);

  return (
    <Canvas
      dpr={[1, 1.8]}
      gl={{ antialias: true, powerPreference: "high-performance" }}
      camera={{ fov: 40, near: 0.1, far: 140, position: [0.65, 2.75, 4.85] }}
      style={{ width: "100%", height: "100%", display: "block" }}
    >
      {data ? (
        <Scene data={data} textures={textures} showSource={showSource} />
      ) : (
        <color attach="background" args={["#141210"]} />
      )}
    </Canvas>
  );
}
