/**
 * ============================================================================
 *  source.ts  —  THE DATA MAPPING
 *  From a coordinate on a physical sheet of paper  ->  to a coordinate in the
 *  floating quote.
 * ============================================================================
 *
 *  THE RULE THIS FILE EXISTS TO ENFORCE
 *  ------------------------------------
 *  No glyph is ever invented. Every particle in the scene is a single
 *  character that was typeset onto one of three typewritten pages. We know
 *  exactly where on that page it sits (page index + UV), so we know its exact
 *  world-space origin on the source mesh. Particles are then re-targeted to
 *  a sampled point inside the quote's letterforms.
 *
 *  PIPELINE
 *  --------
 *   1. buildGlyphAtlas()      -> texture atlas; char code -> (col,row) cell
 *   2. buildPagePlates()      -> typesets PAGE_TEXT onto the paper texture and
 *                               records a CharRecord for every typed character
 *   3. (inline)               -> converts each record's UV into world space via
 *                               the page plate's transform (the source mesh)
 *   4. sampleQuoteTargets()   -> rasterises QUOTE_LINES, reads filled pixels,
 *                               returns N target points inside the letterforms
 *   5. assembleInstances()    -> pairs source records with target points and
 *                               fills the InstancedBufferAttributes
 * ============================================================================
 */

import * as THREE from "three";

/* -------------------------------------------------------------------------- */
/*  Tunables                                                                   */
/* -------------------------------------------------------------------------- */

export const PARTICLE_COUNT = 2400;

/** Source plate: 768 x 1024 px typed page, mapped onto a 1.9 x 2.533 world unit plane. */
export const PAGE_PX_W = 768;
export const PAGE_PX_H = 1024;
export const PAGE_W = 1.9;
export const PAGE_H = (PAGE_W * PAGE_PX_H) / PAGE_PX_W;

/** Target plate: 1024 x 768 px raster of the quote, mapped onto a 12.0 x 9.0 plane. */
export const QUOTE_PX_W = 1024;
export const QUOTE_PX_H = 768;
export const QUOTE_W = 12.0;
export const QUOTE_H = (QUOTE_W * QUOTE_PX_H) / QUOTE_PX_W;

/**
 * Where the quote plate hangs in the scene. Low enough that the camera can hold
 * the typed pages at the bottom of frame and the forming words at the top of it
 * during the tilt — the whole point is that you see the transfer happen.
 */
export const QUOTE_ORIGIN = new THREE.Vector3(0, 5.6, -5.0);

export const ATLAS_COLS = 16;
export const ATLAS_ROWS = 8;
export const ATLAS_CELL = 64;

/**
 * Fraction of an atlas cell the glyph is drawn at. Every scale in the system is
 * expressed relative to this, so a particle glyph has exactly the same optical
 * height as the character printed on the page it came from.
 */
export const ATLAS_GLYPH = 0.85;

/* -------------------------------------------------------------------------- */
/*  1. Glyph atlas                                                             */
/* -------------------------------------------------------------------------- */

export type Atlas = {
  texture: THREE.CanvasTexture;
  /** char -> [offsetU, offsetV] */
  lookup: Map<string, [number, number]>;
  cellU: number;
  cellV: number;
};

const ATLAS_CHARS =
  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,;:'\"!?()--&*/#@$%+=";

/**
 * Draws every printable character we might need into a single 16x8 grid
 * texture. Each particle samples one cell — that is what makes an instanced
 * quad read as a *character* rather than as a spark.
 */
export function buildGlyphAtlas(): Atlas {
  const canvas = document.createElement("canvas");
  canvas.width = ATLAS_COLS * ATLAS_CELL;
  canvas.height = ATLAS_ROWS * ATLAS_CELL;
  const ctx = canvas.getContext("2d")!;

  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = "#ffffff";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  // Glyph is drawn at 0.70 of the cell so it matches the optical size the same
  // character has on the typed page (see buildPagePlates).
  ctx.font = `${Math.round(ATLAS_CELL * ATLAS_GLYPH)}px "Special Elite", "Courier New", monospace`;

  const lookup = new Map<string, [number, number]>();
  for (let i = 0; i < ATLAS_CHARS.length; i++) {
    const col = i % ATLAS_COLS;
    const row = Math.floor(i / ATLAS_COLS);
    const cx = col * ATLAS_CELL + ATLAS_CELL / 2;
    const cy = row * ATLAS_CELL + ATLAS_CELL / 2;
    ctx.fillText(ATLAS_CHARS[i], cx, cy);
    // CanvasTexture flips Y by default -> v grows upward from the canvas bottom.
    lookup.set(ATLAS_CHARS[i], [col / ATLAS_COLS, 1 - (row + 1) / ATLAS_ROWS]);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.magFilter = THREE.LinearFilter;
  texture.generateMipmaps = true;
  texture.needsUpdate = true;

  return { texture, lookup, cellU: 1 / ATLAS_COLS, cellV: 1 / ATLAS_ROWS };
}

/* -------------------------------------------------------------------------- */
/*  2. The source text — three typed pages                                     */
/* -------------------------------------------------------------------------- */

/**
 * Carraway's manuscript pages. Page 3 carries the line the closing card is
 * built from, so the quote literally lifts off the sheet it was typed on.
 */
export const PAGE_TEXT: string[][] = [
  [
    "In my younger and more vulnerable years my",
    "father gave me some advice that I've been",
    "turning over in my mind ever since.",
    "",
    '"Whenever you feel like criticizing any one,"',
    'he told me, "just remember that all the people',
    "in this world haven't had the advantages",
    'that you have had."',
    "",
    "He talked a lot about the past, and I gathered",
    "that he wanted to recover something, some idea",
    "of himself perhaps, that had gone into loving",
    "Daisy. His life had been confused and",
    "disordered since then, but if he could once",
    "return to a certain starting place and go over",
    "it all slowly, he could find out what that",
    "thing was.",
    "",
    "The city seen from the Queensboro Bridge is",
    "always the city seen for the first time, in its",
    "first wild promise of all the mystery and the",
    "beauty in the world.",
    "",
    "A breeze blew through the room, blew curtains",
    "in at one end and out the other like pale flags,",
    "twisting them up toward the frosted wedding-",
  ],
  [
    "cake of the ceiling, and then rippled over the",
    "wine-colored rug, making a shadow on it as",
    "wind does on the sea.",
    "",
    "Gatsby believed in the green light, the orgastic",
    "future that year by year recedes before us. It",
    "eluded us then, but that is no matter --",
    "tomorrow we will run faster, stretch out our",
    "arms farther. And one fine morning --",
    "",
    "So we beat on, boats against the current, borne",
    "back ceaselessly into the past.",
    "",
    "He stretched out his arms toward the dark",
    "water in a curious way, and, far as I was from",
    "him, I could have sworn he was trembling.",
    "Involuntarily I glanced seaward -- and",
    "distinguished nothing except a single green",
    "light, minute and far away, that might have",
    "been the end of a dock.",
    "",
    "There must have been moments even that",
    "afternoon when Daisy tumbled short of his",
    "dreams -- not through her own fault, but",
    "because of the colossal vitality of his illusion.",
  ],
  [
    "I became aware of the old island here that",
    "flowered once for Dutch sailors' eyes -- a fresh,",
    "green breast of the new world. Its vanished",
    "trees, the trees that had made way for Gatsby's",
    "house, had once pandered in whispers to the",
    "last and greatest of all human dreams.",
    "",
    "After Gatsby's death New York was haunted",
    "for me, and I fled back to the Midwest.",
    "",
    "The lights of the party grew dimmer and the",
    "streets of the city turned over and over in my",
    "sleep, until I stopped haunting it and let the",
    "current take me where it would.",
    "",
    "One autumn night, five years before, they had",
    "been walking down the street when the leaves",
    "were falling, and they came to a place where",
    "there were no trees and the sidewalk was white",
    "with moonlight.",
    "",
    "He had come a long way to this blue lawn, and",
    "his dream must have seemed so close that he",
    "could hardly fail to grasp it. He did not know",
    "that it was already behind him, somewhere",
    "back in that vast obscurity beyond the city,",
  ],
];

/* -------------------------------------------------------------------------- */
/*  3. CharRecord — one row per typed character                                */
/* -------------------------------------------------------------------------- */

export type CharRecord = {
  char: string;
  page: number;
  /** Normalised position of the character's centre on the typed page. */
  u: number;
  v: number;
  /** The character box, in world units — becomes the particle's start scale. */
  size0: number;
};

export type Plate = {
  canvas: HTMLCanvasElement;
  texture: THREE.CanvasTexture;
  transform: THREE.Object3D;
};

/** Where the three sheets lie on the desk (the source meshes). */
export const PLATE_LAYOUT = [
  { pos: new THREE.Vector3(-1.62, 0.012, 0.42), rotY: 0.24 },
  { pos: new THREE.Vector3(0.18, 0.014, -0.62), rotY: -0.31 },
  { pos: new THREE.Vector3(1.86, 0.012, 0.86), rotY: 0.58 },
];

/**
 * Typesets a page onto the paper texture and records where every character
 * landed. `measureText` per character gives true advance widths, so the UV we
 * store is the same UV the GPU rasterises — the particle will sit exactly on
 * top of its own printed ink.
 */
export function buildPagePlates(
  paperImage: HTMLImageElement | null,
): { plates: Plate[]; records: CharRecord[] } {
  const plates: Plate[] = [];
  const records: CharRecord[] = [];

  const margin = 62;
  const lineHeight = 34;
  const fontSize = 21;
  const pxToWorld = PAGE_W / PAGE_PX_W;

  for (let p = 0; p < PAGE_TEXT.length; p++) {
    const canvas = document.createElement("canvas");
    canvas.width = PAGE_PX_W;
    canvas.height = PAGE_PX_H;
    const ctx = canvas.getContext("2d")!;

    /* --- paper substrate: the generated sheet, cover-fitted and warmed --- */
    ctx.fillStyle = "#e8dfcb";
    ctx.fillRect(0, 0, PAGE_PX_W, PAGE_PX_H);
    if (paperImage && paperImage.width > 0) {
      const s = Math.max(PAGE_PX_W / paperImage.width, PAGE_PX_H / paperImage.height);
      const w = paperImage.width * s;
      const h = paperImage.height * s;
      ctx.globalAlpha = 0.92;
      ctx.drawImage(paperImage, (PAGE_PX_W - w) / 2, (PAGE_PX_H - h) / 2, w, h);
      ctx.globalAlpha = 1;
    }
    // faint typed-page tint so the ink sits in the paper, not on it
    const tint = ctx.createLinearGradient(0, 0, 0, PAGE_PX_H);
    tint.addColorStop(0, "rgba(232,223,203,0.30)");
    tint.addColorStop(1, "rgba(201,188,161,0.34)");
    ctx.fillStyle = tint;
    ctx.fillRect(0, 0, PAGE_PX_W, PAGE_PX_H);

    /* --- the typing --- */
    ctx.font = `${fontSize}px "Special Elite", "Courier New", monospace`;
    ctx.fillStyle = "#241f19";
    ctx.textBaseline = "alphabetic";
    ctx.textAlign = "left";

    const lines = PAGE_TEXT[p];
    for (let li = 0; li < lines.length; li++) {
      const line = lines[li];
      const baseline = margin + li * lineHeight + fontSize;
      let x = margin;
      for (let ci = 0; ci < line.length; ci++) {
        const ch = line[ci];
        const adv = ctx.measureText(ch).width;
        if (ch !== " ") {
          ctx.fillText(ch, x, baseline);
          records.push({
            char: ch,
            page: p,
            u: (x + adv / 2) / PAGE_PX_W,
            // canvas y grows down, plane UV v grows up
            v: 1 - (baseline - fontSize * 0.32) / PAGE_PX_H,
            // Divide back out the atlas glyph ratio so the particle glyph has
            // the same optical height as the ink sitting under it on the page.
            size0: (fontSize * pxToWorld) / ATLAS_GLYPH,
          });
        }
        x += adv + 0.55; // typewriter carriage advance
      }
    }

    // registration / margin hairline, like a proof sheet
    ctx.strokeStyle = "rgba(107,98,86,0.18)";
    ctx.lineWidth = 1;
    ctx.strokeRect(30.5, 30.5, PAGE_PX_W - 61, PAGE_PX_H - 61);

    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.anisotropy = 8;
    texture.needsUpdate = true;

    const transform = new THREE.Object3D();
    const layout = PLATE_LAYOUT[p];
    transform.position.copy(layout.pos);
    transform.rotation.set(-Math.PI / 2, 0, layout.rotY);
    transform.updateMatrixWorld(true);

    plates.push({ canvas, texture, transform });
  }

  return { plates, records };
}

/* -------------------------------------------------------------------------- */
/*  4. Target raster — sampling the quote's letterforms                        */
/* -------------------------------------------------------------------------- */

export const QUOTE_LINES: { text: string; size: number; italic?: boolean }[] = [
  { text: "After Gatsby's", size: 132 },
  { text: "death, New York", size: 128 },
  { text: "was haunted", size: 150 },
  { text: "for me.", size: 180, italic: true },
];

/**
 * Rasterises the quote and returns world-space points *inside* the
 * letterforms. This is the destination set — never the origin set.
 */
export function sampleQuoteTargets(count: number): Float32Array {
  const canvas = document.createElement("canvas");
  canvas.width = QUOTE_PX_W;
  canvas.height = QUOTE_PX_H;
  const ctx = canvas.getContext("2d", { willReadFrequently: true })!;

  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, QUOTE_PX_W, QUOTE_PX_H);
  ctx.fillStyle = "#fff";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  // Auto-fit: if a line would run past the safe measure, shrink it rather than
  // let the quote raster (and therefore every target point) fall off the plate.
  const maxWidth = QUOTE_PX_W * 0.88;
  const fitted = QUOTE_LINES.map((line) => {
    ctx.font = `${line.italic ? "italic " : ""}700 ${line.size}px "Playfair Display", Georgia, serif`;
    const w = ctx.measureText(line.text).width;
    return { ...line, size: w > maxWidth ? line.size * (maxWidth / w) : line.size };
  });

  const total = fitted.reduce((a, l) => a + l.size * 1.14, 0);
  let y = (QUOTE_PX_H - total) / 2;
  for (const line of fitted) {
    ctx.font = `${line.italic ? "italic " : ""}700 ${line.size}px "Playfair Display", Georgia, serif`;
    ctx.fillText(line.text, QUOTE_PX_W / 2, y + (line.size * 1.14) / 2);
    y += line.size * 1.14;
  }

  const { data } = ctx.getImageData(0, 0, QUOTE_PX_W, QUOTE_PX_H);
  const filled: number[] = [];
  for (let i = 0, n = data.length; i < n; i += 4) {
    if (data[i] > 128) filled.push(i / 4);
  }

  const out = new Float32Array(count * 3);
  const pxToWorld = QUOTE_W / QUOTE_PX_W;
  const n = Math.max(1, filled.length);
  for (let i = 0; i < count; i++) {
    const idx = filled[Math.floor(Math.random() * n)] ?? 0;
    const px = idx % QUOTE_PX_W;
    const py = Math.floor(idx / QUOTE_PX_W);
    // +/- 0.5px jitter so the swarm settles with an ink-grain texture
    out[i * 3 + 0] = (px + Math.random() - 0.5) * pxToWorld - QUOTE_W / 2;
    out[i * 3 + 1] = QUOTE_H / 2 - (py + Math.random() - 0.5) * pxToWorld;
    out[i * 3 + 2] = (Math.random() - 0.5) * 0.16;
  }
  return out;
}

/* -------------------------------------------------------------------------- */
/*  5. Assembling the instances                                                */
/* -------------------------------------------------------------------------- */

export type InstanceSet = {
  origin: Float32Array;
  target: Float32Array;
  originQuat: Float32Array;
  uvOffset: Float32Array;
  scale0: Float32Array;
  scale1: Float32Array;
  delay: Float32Array;
  axis: Float32Array;
  spin: Float32Array;
  seed: Float32Array;
  /** Parallel array kept for the on-page breakdown table. */
  records: CharRecord[];
};

function easeOutCubic(t: number) {
  return 1 - Math.pow(1 - t, 3);
}

/**
 * Pairs each source character with a target point and writes every per-instance
 * attribute the vertex shader needs.
 *
 *  origin    <- UV on the source plate, pushed 0.012 units along the page normal
 *  target    <- sampled point inside the quote raster
 *  delay     <- a wave sweeping bottom-left -> top-right of the quote, so the
 *              swarm lifts in a coherent gesture instead of all at once
 *  scale0    <- the character's real size on the typed page
 *  scale1    <- the size it needs to be to fill the quote letterform
 */
export function assembleInstances(
  records: CharRecord[],
  plates: Plate[],
  atlas: Atlas,
  count: number,
): InstanceSet {
  const n = Math.min(count, records.length);

  const origin = new Float32Array(n * 3);
  const target = new Float32Array(n * 3);
  const originQuat = new Float32Array(n * 4);
  const uvOffset = new Float32Array(n * 2);
  const scale0 = new Float32Array(n);
  const scale1 = new Float32Array(n);
  const delay = new Float32Array(n);
  const axis = new Float32Array(n * 3);
  const spin = new Float32Array(n);
  const seed = new Float32Array(n);

  const targets = sampleQuoteTargets(n);

  // Shuffle of the source pool so all three pages contribute evenly.
  const pool = records.slice();
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = pool[i];
    pool[i] = pool[j];
    pool[j] = tmp;
  }

  const v = new THREE.Vector3();
  const q = new THREE.Quaternion();

  for (let i = 0; i < n; i++) {
    const rec = pool[i % pool.length];
    const plate = plates[rec.page];

    // --- SOURCE: the character's true home on the paper mesh -----------------
    v.set((rec.u - 0.5) * PAGE_W, (rec.v - 0.5) * PAGE_H, 0.012);
    v.applyMatrix4(plate.transform.matrixWorld);
    origin[i * 3 + 0] = v.x;
    origin[i * 3 + 1] = v.y;
    origin[i * 3 + 2] = v.z;

    q.copy(plate.transform.quaternion);
    originQuat[i * 4 + 0] = q.x;
    originQuat[i * 4 + 1] = q.y;
    originQuat[i * 4 + 2] = q.z;
    originQuat[i * 4 + 3] = q.w;

    // --- TARGET -------------------------------------------------------------
    target[i * 3 + 0] = targets[i * 3 + 0] + QUOTE_ORIGIN.x;
    target[i * 3 + 1] = targets[i * 3 + 1] + QUOTE_ORIGIN.y;
    target[i * 3 + 2] = targets[i * 3 + 2] + QUOTE_ORIGIN.z;

    // --- ATLAS --------------------------------------------------------------
    const uv = atlas.lookup.get(rec.char) ?? atlas.lookup.get("e")!;
    uvOffset[i * 2 + 0] = uv[0];
    uvOffset[i * 2 + 1] = uv[1];

    // --- SCALING ------------------------------------------------------------
    scale0[i] = rec.size0;
    scale1[i] = 0.185 * (0.82 + Math.random() * 0.42);

    // --- CHOREOGRAPHY -------------------------------------------------------
    // Wave ordered by where the glyph lands in the quote.
    const nx = (target[i * 3 + 0] - QUOTE_ORIGIN.x + QUOTE_W / 2) / QUOTE_W;
    const ny = (target[i * 3 + 1] - QUOTE_ORIGIN.y + QUOTE_H / 2) / QUOTE_H;
    const d = Math.hypot(nx - 0.1, ny - 0.05) / 1.25;
    delay[i] = 0.1 + easeOutCubic(Math.min(1, d)) * 0.42;

    const a = Math.random() * Math.PI * 2;
    const b = Math.acos(2 * Math.random() - 1);
    axis[i * 3 + 0] = Math.sin(b) * Math.cos(a);
    axis[i * 3 + 1] = Math.sin(b) * Math.sin(a);
    axis[i * 3 + 2] = Math.cos(b);
    spin[i] = (Math.random() * 0.7 + 0.3) * (Math.random() > 0.5 ? 1 : -1);
    seed[i] = Math.random();
  }

  return {
    origin,
    target,
    originQuat,
    uvOffset,
    scale0,
    scale1,
    delay,
    axis,
    spin,
    seed,
    records: pool.slice(0, n),
  };
}
