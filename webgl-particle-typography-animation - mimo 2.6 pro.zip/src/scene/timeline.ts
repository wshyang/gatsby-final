/**
 * A tiny mutable timeline shared by the DOM chrome and the WebGL runtime.
 * It is a plain object on purpose: the render loop mutates it every frame and
 * the UI samples it at ~20 Hz, so no React state is touched 60 times a second.
 */
export const timeline = {
  progress: 0,
  playing: true,
  scrubbing: false,
  duration: 26,
};

export const PHASES = [
  { key: "source", label: "Source", at: 0.0, note: "Ink is still on the page" },
  { key: "lift", label: "Lift-off", at: 0.18, note: "Glyphs detach along the page normal" },
  { key: "transit", label: "Transit", at: 0.42, note: "Curl drift, tumble, scale-up" },
  { key: "settle", label: "Settle", at: 0.72, note: "Critically damped arrival" },
  { key: "hold", label: "Card", at: 0.92, note: "Quote holds against the skyline" },
] as const;

export type Phase = (typeof PHASES)[number];

export function phaseFor(p: number): Phase {
  let out: Phase = PHASES[0];
  for (const ph of PHASES) if (p >= ph.at) out = ph;
  return out;
}

export const prefersReducedMotion = () =>
  typeof window !== "undefined" &&
  window.matchMedia("(prefers-reduced-motion: reduce)").matches;
