import { useCallback, useEffect, useRef, useState } from "react";
import { TIMELINE } from "./gatsby/config";
import {
  GatsbyScene,
  LiveParticleCounts,
  PHASES,
  phaseAt,
  SceneStats,
} from "./gatsby/GatsbyScene";
import { cn } from "./utils/cn";

const fmt = (t: number) =>
  `${Math.floor(t / 60)}:${(t % 60).toFixed(1).padStart(4, "0")}`;
const num = (n: number) => n.toLocaleString("en-US");

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sceneRef = useRef<GatsbyScene | null>(null);
  const [time, setTime] = useState(0);
  const [counts, setCounts] = useState<LiveParticleCounts>({
    onPaper: 0,
    inFlight: 0,
    settled: 0,
  });
  const [playing, setPlaying] = useState(true);
  const [speed, setSpeed] = useState(1);
  const [showMapping, setShowMapping] = useState(false);
  const [showNotes, setShowNotes] = useState(false);
  const [stats, setStats] = useState<SceneStats | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [uiHidden, setUiHidden] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let scene: GatsbyScene | null = null;
    try {
      scene = new GatsbyScene(canvas, {
        onTime: (t, c) => {
          setTime(t);
          setCounts(c);
        },
        onReady: (s) => {
          setStats(s);
          if (scene) setCounts(scene.liveCountsAt(0));
        },
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
      return;
    }
    sceneRef.current = scene;
    (window as unknown as { __gatsby?: GatsbyScene }).__gatsby = scene;
    scene
      .init()
      .catch((e) => setError(e instanceof Error ? e.message : String(e)));

    const onResize = () => scene?.resize();
    window.addEventListener("resize", onResize);
    return () => {
      window.removeEventListener("resize", onResize);
      scene?.dispose();
      sceneRef.current = null;
    };
  }, []);

  const togglePlay = useCallback(() => {
    setPlaying((p) => {
      const next = !p;
      if (sceneRef.current) sceneRef.current.playing = next;
      return next;
    });
  }, []);

  const replay = useCallback(() => {
    if (!sceneRef.current) return;
    sceneRef.current.setTime(0);
    setTime(0);
    setCounts(sceneRef.current.liveCountsAt(0));
    sceneRef.current.playing = true;
    setPlaying(true);
  }, []);

  const scrub = useCallback((t: number) => {
    if (!sceneRef.current) return;
    sceneRef.current.setTime(t);
    setTime(t);
    setCounts(sceneRef.current.liveCountsAt(t));
  }, []);

  const cycleSpeed = useCallback(() => {
    setSpeed((s) => {
      const next = s === 1 ? 0.5 : s === 0.5 ? 1.5 : 1;
      if (sceneRef.current) sceneRef.current.speed = next;
      return next;
    });
  }, []);

  const toggleMapping = useCallback(() => {
    setShowMapping((m) => {
      sceneRef.current?.setShowMapping(!m);
      return !m;
    });
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement) return;
      if (e.code === "Space") {
        e.preventDefault();
        togglePlay();
      } else if (e.key === "r" || e.key === "R") replay();
      else if (e.key === "m" || e.key === "M") toggleMapping();
      else if (e.key === "i" || e.key === "I") setShowNotes((n) => !n);
      else if (e.key === "h" || e.key === "H") setUiHidden((h) => !h);
      else if (e.key === "ArrowRight")
        scrub(Math.min(TIMELINE.duration, (sceneRef.current?.time ?? 0) + 1));
      else if (e.key === "ArrowLeft")
        scrub(Math.max(0, (sceneRef.current?.time ?? 0) - 1));
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [togglePlay, replay, toggleMapping, scrub]);

  const phase = phaseAt(time);
  const progress = (time / TIMELINE.duration) * 100;

  return (
    <div className="fixed inset-0 overflow-hidden bg-[#050508] text-[#f4ead5] select-none">
      <canvas ref={canvasRef} className="block h-full w-full" />

      {/* Loading screen */}
      {!stats && !error && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-[#050508]">
          <Monogram />
          <p className="text-xs tracking-[0.45em] uppercase text-[#dcb862]/85">
            Setting the Typewriter &amp; Manuscript Pages…
          </p>
        </div>
      )}

      {/* Error fallback */}
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#050508] p-8 text-center">
          <div>
            <p className="text-sm tracking-[0.3em] uppercase text-[#dcb862]">
              WebGL Could Not Start
            </p>
            <p className="mt-3 max-w-md text-sm text-[#f4ead5]/70">{error}</p>
          </div>
        </div>
      )}

      {/* Cinema HUD Overlay */}
      <div
        className={cn(
          "pointer-events-none absolute inset-0 transition-opacity duration-500",
          uiHidden && "opacity-0",
        )}
      >
        {/* Top-left header */}
        <header className="absolute top-5 left-6 md:top-7 md:left-10">
          <div className="flex items-center gap-3">
            <span className="h-px w-8 bg-[#dcb862]/75" />
            <span className="text-[10px] tracking-[0.45em] uppercase text-[#dcb862]">
              The Great Gatsby · 2013 · 01:06–01:28
            </span>
          </div>
          <h1 className="mt-1.5 text-2xl leading-tight font-normal tracking-wide md:text-3xl">
            Typographic <span className="italic text-[#dcb862]">Lift-Off</span>
          </h1>
          <p className="mt-1 max-w-xs text-[11px] leading-relaxed text-[#f4ead5]/60 md:text-xs">
            Every character originates at a verified <code className="font-typewriter text-[#dcb862]/90">(u,v)</code> coordinate on the 8 physical manuscript sheets before lifting into 3D space.
          </p>
        </header>

        {/* Top-right active phase & live telemetry */}
        <aside className="absolute top-5 right-6 max-w-[280px] text-right md:top-7 md:right-10">
          <p className="text-[10px] tracking-[0.45em] uppercase text-[#dcb862]">
            Sequence Phase
          </p>
          <p className="mt-0.5 text-lg font-medium text-[#f4ead5] md:text-xl">
            {phase.name}
          </p>
          <p className="mt-1 text-[11px] leading-relaxed text-[#f4ead5]/60">
            {phase.blurb}
          </p>

          {stats && (
            <div className="mt-3 inline-grid grid-cols-3 gap-2 rounded border border-[#dcb862]/25 bg-black/45 px-3 py-1.5 text-center backdrop-blur-sm">
              <div>
                <div className="text-[9px] tracking-[0.2em] uppercase text-[#f4ead5]/50">
                  On Paper
                </div>
                <div className="font-typewriter text-xs text-[#f4ead5]">
                  {num(counts.onPaper)}
                </div>
              </div>
              <div className="border-x border-[#dcb862]/20 px-2">
                <div className="text-[9px] tracking-[0.2em] uppercase text-[#dcb862]/80">
                  Sea Flight
                </div>
                <div className="font-typewriter text-xs text-[#dcb862]">
                  {num(counts.inFlight)}
                </div>
              </div>
              <div>
                <div className="text-[9px] tracking-[0.2em] uppercase text-[#f4ead5]/50">
                  In Quote
                </div>
                <div className="font-typewriter text-xs text-[#f4ead5]">
                  {num(counts.settled)} / {stats.slots}
                </div>
              </div>
            </div>
          )}
        </aside>

        {/* Architecture & Review Notes Modal */}
        {showNotes && stats && (
          <div className="pointer-events-auto absolute inset-x-6 top-28 mx-auto max-w-2xl rounded border border-[#dcb862]/35 bg-[#08090f]/92 p-5 text-xs leading-relaxed text-[#f4ead5]/85 shadow-2xl backdrop-blur-md md:top-32 md:p-6">
            <div className="flex items-center justify-between border-b border-[#dcb862]/25 pb-2.5">
              <span className="text-[11px] tracking-[0.35em] uppercase text-[#dcb862]">
                Technical Architecture &amp; Synthesis of Reviews.txt
              </span>
              <button
                onClick={() => setShowNotes(false)}
                className="cursor-pointer text-[#f4ead5]/60 hover:text-[#dcb862]"
              >
                ✕ Close
              </button>
            </div>
            <div className="mt-3 space-y-2.5 text-[11.5px]">
              <p>
                <strong className="text-[#dcb862]">1. Strict Paper-Surface Origin (&ldquo;No Spawning Out of Nowhere&rdquo;):</strong>{" "}
                {num(stats.sources)} characters are laid out across {stats.pages} physical paper meshes (1 curved platen sheet + 7 desk manuscript pages) via{" "}
                <code className="font-typewriter text-[#dcb862]">PaperSurface.poseAt(u,v)</code>. The first two quote lines map 1:1 ({stats.identityMapped} glyphs) from the live-typed line on the platen; the remaining two lines harvest matching characters ({stats.searchMapped} glyphs) from the desk pages.
              </p>
              <p>
                <strong className="text-[#dcb862]">2. Fixed Uncorrupted Typewriter Key Strikers:</strong>{" "}
                Replaced the solid intersecting housing box from <code className="font-typewriter">fable_max</code> with an open type-basket cavity and 42 radial steel type bars + hammer slugs anchored on a curved slotted segment arc. At rest they fan outward onto a felt rest pad; when struck, the active bar pivots cleanly so its slug hits the exact platen printing point.
              </p>
              <p>
                <strong className="text-[#dcb862]">3. 100% Full-Page Lift-Off &amp; Dense Sea of Alphabets:</strong>{" "}
                Every single character on all 8 visible pages lifts off (<code className="font-typewriter">stays = 0</code>), using a two-stage slow-peel shader curve and well-proportioned airborne glyph sizing inspired by <code className="font-typewriter">fable_low</code> &amp; <code className="font-typewriter">mimo_pro</code>.
              </p>
              <p>
                <strong className="text-[#dcb862]">4. Hybrid 3D City + Bokeh Blur-to-Focus Skyline:</strong>{" "}
                Combines 1,650 3D instanced Manhattan skyscrapers, sweeping searchlights, and 3D snow with a panoramic skyline backdrop driven by a 13-tap Golden-Angle disk bokeh shader that smoothly racks into focus as the quote coalesces.
              </p>
            </div>
          </div>
        )}

        {/* Bottom Scrubber & Controls */}
        <footer className="pointer-events-auto absolute right-0 bottom-0 left-0 bg-gradient-to-t from-black/80 via-black/35 to-transparent px-6 pt-6 pb-5 md:px-10 md:pb-7">
          <div className="mx-auto max-w-5xl">
            {/* Quick Phase Jump Pills */}
            <div className="mb-2 flex flex-wrap items-center gap-1.5">
              {PHASES.map((ph) => {
                const active = phase.name === ph.name;
                return (
                  <button
                    key={ph.name}
                    onClick={() => scrub(ph.from + 0.05)}
                    className={cn(
                      "cursor-pointer rounded-sm border px-2 py-0.5 text-[10px] tracking-[0.18em] uppercase transition-colors",
                      active
                        ? "border-[#dcb862] bg-[#dcb862]/15 text-[#dcb862]"
                        : "border-[#f4ead5]/15 bg-black/30 text-[#f4ead5]/55 hover:border-[#dcb862]/50 hover:text-[#f4ead5]",
                    )}
                  >
                    {ph.name}
                  </button>
                );
              })}
            </div>

            {/* Scrubber Bar */}
            <div className="relative h-6">
              <div className="absolute top-1/2 right-0 left-0 h-px -translate-y-1/2 bg-[#f4ead5]/20" />
              <div
                className="absolute top-1/2 left-0 h-0.5 -translate-y-1/2 bg-[#dcb862]"
                style={{ width: `${progress}%` }}
              />
              {PHASES.slice(1).map((ph) => (
                <span
                  key={ph.from}
                  className="absolute top-1/2 h-2.5 w-px -translate-y-1/2 bg-[#dcb862]/65"
                  style={{ left: `${(ph.from / TIMELINE.duration) * 100}%` }}
                />
              ))}
              <input
                type="range"
                min={0}
                max={TIMELINE.duration}
                step={0.01}
                value={time}
                onChange={(e) => scrub(parseFloat(e.target.value))}
                aria-label="Timeline Scrubber"
                className="absolute inset-0 h-6 w-full cursor-pointer appearance-none bg-transparent opacity-0"
              />
              <div
                className="pointer-events-none absolute top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rotate-45 border border-[#dcb862] bg-[#050508]"
                style={{ left: `${progress}%` }}
              />
            </div>

            {/* Control Buttons */}
            <div className="mt-2 flex flex-wrap items-center gap-x-5 gap-y-2 text-[11px] tracking-[0.2em] uppercase">
              <button onClick={togglePlay} className="deco-btn">
                {playing ? "Pause" : "Play"}
              </button>
              <button onClick={replay} className="deco-btn">
                Replay
              </button>
              <button onClick={cycleSpeed} className="deco-btn">
                Speed {speed}×
              </button>
              <button
                onClick={toggleMapping}
                className={cn(
                  "deco-btn",
                  showMapping && "border-[#dcb862] text-[#dcb862]",
                )}
              >
                {showMapping ? "Hide" : "Show"} Origin → Quote Links
              </button>
              <button
                onClick={() => setShowNotes((n) => !n)}
                className={cn(
                  "deco-btn",
                  showNotes && "border-[#dcb862] text-[#dcb862]",
                )}
              >
                {showNotes ? "Hide" : "Architecture &"} Notes
              </button>
              <span className="font-typewriter text-xs tabular-nums text-[#f4ead5]/65">
                {fmt(time)} / {fmt(TIMELINE.duration)}
              </span>
              <span className="ml-auto hidden text-[#f4ead5]/40 normal-case tracking-normal lg:inline">
                Space · Play/Pause &nbsp;|&nbsp; R · Replay &nbsp;|&nbsp; M · Mapping Links &nbsp;|&nbsp; I · Notes &nbsp;|&nbsp; H · Hide HUD
              </span>
            </div>

            {stats && (
              <p className="mt-2 text-[11px] leading-relaxed text-[#f4ead5]/50">
                <span className="text-[#dcb862]/85">Provenance</span> ·{" "}
                {num(stats.sources)} paper-bound glyphs across {stats.pages} manuscript sheets →{" "}
                {num(stats.slots)} quote slots ({num(stats.identityMapped)} 1:1 from platen line,{" "}
                {num(stats.searchMapped)} harvested from desk pages) +{" "}
                {num(stats.chaff)} swirling sea glyphs · {num(stats.stays)} stay behind (100% lift-off) · font:{" "}
                {stats.fontUsed}
              </p>
            )}
          </div>
        </footer>
      </div>
    </div>
  );
}

function Monogram() {
  return (
    <svg
      width="72"
      height="72"
      viewBox="0 0 72 72"
      fill="none"
      className="text-[#dcb862]"
    >
      <circle
        cx="36"
        cy="36"
        r="33"
        stroke="currentColor"
        strokeWidth="1"
        opacity="0.6"
      />
      <circle
        cx="36"
        cy="36"
        r="28"
        stroke="currentColor"
        strokeWidth="0.5"
        opacity="0.4"
      />
      <path
        d="M26 24h20M26 48h20M36 24v24"
        stroke="currentColor"
        strokeWidth="1.2"
      />
      <path
        d="M30 30l6 6-6 6M42 30l-6 6 6 6"
        stroke="currentColor"
        strokeWidth="0.8"
        opacity="0.7"
      />
    </svg>
  );
}
