import * as THREE from "three";
import cityUrl from "../assets/city.jpg";
import { PALETTE, WORLD } from "./config";
import { mulberry32 } from "./GlyphAtlas";

/**
 * City
 * ----
 * Hybrid 3D + Optical Blur-to-Focus 1920s Manhattan at night:
 *  1. 3D Instanced Manhattan Cityscape: over 1,600 3D skyscraper blocks with
 *     procedural flickering warm windows, illuminated avenue grids, sweeping
 *     1920s searchlight beams, and 3D falling snow particles for true parallax.
 *  2. Blur-to-Focus Skyline Panorama (`reviews.txt` praise from `fable_low`):
 *     Behind the 3D buildings sits the warm 1920s Manhattan skyline (`city.jpg`)
 *     with a custom 13-tap disk-bokeh GLSL shader (`uBlur`) that starts softly
 *     out-of-focus as the camera rises from the desk and smoothly racks into
 *     sharp focus as the quote assembles.
 */

const buildingVert = /* glsl */ `
  attribute float aRand;
  varying vec3 vWorld;
  varying vec3 vNormal;
  varying float vRand;
  varying float vH;
  void main() {
    vec4 w = modelMatrix * instanceMatrix * vec4(position, 1.0);
    vWorld = w.xyz;
    vNormal = normalize(mat3(modelMatrix * instanceMatrix) * normal);
    vRand = aRand;
    vH = position.y;
    gl_Position = projectionMatrix * viewMatrix * w;
  }
`;

const buildingFrag = /* glsl */ `
  uniform vec3 uFogColor;
  uniform float uFogDensity;
  uniform vec3 uCameraPos;
  uniform float uTime;
  uniform vec3 uWindow;
  uniform float uBlur;
  varying vec3 vWorld;
  varying vec3 vNormal;
  varying float vRand;
  varying float vH;

  float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
  }

  void main() {
    vec3 n = abs(vNormal);
    vec3 facade = vec3(0.032, 0.042, 0.064) * (0.55 + 0.6 * vRand);
    vec3 col = facade;
    if (n.y < 0.5) {
      vec2 uvw = (n.x > n.z)
        ? vec2(vWorld.z / 0.58, vWorld.y / 0.72)
        : vec2(vWorld.x / 0.58, vWorld.y / 0.72);
      vec2 cell = floor(uvw);
      vec2 f = fract(uvw);

      // Soften window pane edges when uBlur > 0 (simulating optical defocus on 3D buildings too)
      float edge = mix(0.03, 0.22, uBlur);
      float paneX = smoothstep(0.24 - edge, 0.28 + edge, f.x) * (1.0 - smoothstep(0.72 - edge, 0.76 + edge, f.x));
      float paneY = smoothstep(0.20 - edge, 0.24 + edge, f.y) * (1.0 - smoothstep(0.74 - edge, 0.78 + edge, f.y));
      float pane = paneX * paneY;

      float h = hash(cell + vRand * 97.0);
      float occupancy = 0.50 + 0.28 * sin(vRand * 23.0);
      float lit = step(occupancy, h);
      float flick = 0.86 + 0.14 * sin(uTime * (0.4 + h * 1.2) + h * 60.0);
      float tone = mix(0.58, 1.55, hash(cell.yx + vRand * 13.0));
      col += pane * lit * uWindow * tone * flick * 1.75;
      col += lit * uWindow * (0.06 + 0.12 * uBlur) * tone;
    } else {
      col = facade * 1.2;
    }
    col *= 0.42 + 0.58 * smoothstep(0.0, 0.85, vH);
    float d = distance(vWorld, uCameraPos);
    float fog = 1.0 - exp(-pow(d * uFogDensity, 2.0));
    col = mix(col, uFogColor, fog);
    gl_FragColor = vec4(col, 1.0);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

const groundVert = /* glsl */ `
  varying vec3 vWorld;
  void main() {
    vec4 w = modelMatrix * vec4(position, 1.0);
    vWorld = w.xyz;
    gl_Position = projectionMatrix * viewMatrix * w;
  }
`;

const groundFrag = /* glsl */ `
  uniform vec3 uFogColor;
  uniform float uFogDensity;
  uniform vec3 uCameraPos;
  uniform vec3 uWindow;
  varying vec3 vWorld;
  float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
  }
  void main() {
    vec3 col = vec3(0.01, 0.014, 0.024);
    vec2 g = vec2(vWorld.x / 12.0, vWorld.z / 22.0);
    vec2 f = abs(fract(g) - 0.5);
    float street = smoothstep(0.43, 0.48, max(f.x, f.y));
    float dots = step(0.62, hash(floor(vec2(vWorld.x / 1.8, vWorld.z / 1.8))));
    col += street * dots * uWindow * 1.05;
    float d = distance(vWorld, uCameraPos);
    float fog = 1.0 - exp(-pow(d * uFogDensity, 2.0));
    col = mix(col, uFogColor, fog);
    gl_FragColor = vec4(col, 1.0);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

const skyVert = /* glsl */ `
  varying vec3 vDir;
  void main() {
    vDir = normalize(position);
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    gl_Position = projectionMatrix * mv;
    gl_Position.z = gl_Position.w;
  }
`;

const skyFrag = /* glsl */ `
  uniform vec3 uTop;
  uniform vec3 uHorizon;
  uniform vec3 uGlow;
  uniform vec3 uFogColor;
  uniform float uReveal;
  varying vec3 vDir;
  void main() {
    float h = clamp(vDir.y, 0.0, 1.0);
    vec3 sky = mix(uHorizon, uTop, pow(h, 0.55));
    float glow = exp(-abs(vDir.y + 0.03) * 8.0) * smoothstep(-0.2, 0.85, -vDir.z);
    sky += uGlow * glow * 0.72;
    vec3 col = mix(uFogColor, sky, uReveal);
    gl_FragColor = vec4(col, 1.0);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

/**
 * Custom 13-tap Golden-Angle Disk Bokeh Blur shader for the Manhattan skyline
 * backdrop (`city.jpg`). As `uBlur` transitions from `1.0` -> `0.0`, the out-of-focus
 * bokeh disks of city lights smoothly rack into crisp architectural focus.
 */
const backdropVert = /* glsl */ `
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

const backdropFrag = /* glsl */ `
  uniform sampler2D uMap;
  uniform float uBlur;
  uniform float uReveal;
  uniform vec3 uFogColor;
  varying vec2 vUv;

  void main() {
    // 13-tap golden-angle spiral bokeh kernel
    float radius = uBlur * 0.018;
    vec2 aspect = vec2(1.0, 1.777);
    vec3 acc = vec3(0.0);
    float wSum = 0.0;

    for (int i = 0; i < 13; i++) {
      float fi = float(i);
      float r = sqrt(fi / 12.0) * radius;
      float theta = fi * 2.3999632;
      vec2 offset = vec2(cos(theta), sin(theta)) * r * aspect;
      vec3 s = texture2D(uMap, clamp(vUv + offset, 0.002, 0.998)).rgb;
      // Highlight-boosted bokeh weighting so bright skyscraper windows bloom into soft circles when blurred
      float luma = dot(s, vec3(0.299, 0.587, 0.114));
      float w = 1.0 + uBlur * luma * luma * 3.8;
      acc += s * w;
      wSum += w;
    }
    vec3 col = acc / max(wSum, 1e-4);

    // Subtle vertical vignette at top and bottom of the skyline plane so it blends seamlessly into the 3D scene
    float vFade = smoothstep(0.0, 0.14, vUv.y) * (1.0 - smoothstep(0.82, 0.99, vUv.y));
    float hFade = smoothstep(0.0, 0.10, vUv.x) * (1.0 - smoothstep(0.90, 1.0, vUv.x));
    float mask = vFade * hFade * uReveal;

    col = mix(uFogColor, col * 1.12, mask);
    gl_FragColor = vec4(col, mask * 0.92);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

const snowVert = /* glsl */ `
  attribute vec3 aVel;
  uniform float uTime;
  uniform vec3 uCameraPos;
  uniform float uReveal;
  varying float vAlpha;
  void main() {
    vec3 span = vec3(14.0, 9.0, 14.0);
    vec3 rel = position + aVel * uTime - uCameraPos;
    rel = (fract(rel / span + 0.5) - 0.5) * span;
    vec3 world = uCameraPos + rel;
    vec4 mv = viewMatrix * vec4(world, 1.0);
    float d = max(-mv.z, 0.25);
    gl_PointSize = clamp(16.0 / d, 1.2, 6.0);
    vAlpha = uReveal * smoothstep(7.0, 2.0, d) * smoothstep(0.3, 1.1, d) * 0.42;
    gl_Position = projectionMatrix * mv;
  }
`;

const snowFrag = /* glsl */ `
  varying float vAlpha;
  void main() {
    float r = length(gl_PointCoord - 0.5);
    float a = smoothstep(0.5, 0.1, r) * vAlpha;
    if (a < 0.005) discard;
    gl_FragColor = vec4(vec3(0.9, 0.93, 1.0), a);
  }
`;

export interface CityUniformState {
  time: number;
  cameraPos: THREE.Vector3;
  fogColor: THREE.Color;
  fogDensity: number;
  reveal: number;
  cityBlur: number;
}

export class City {
  readonly group = new THREE.Group();
  private readonly buildingMat: THREE.ShaderMaterial;
  private readonly groundMat: THREE.ShaderMaterial;
  private readonly skyMat: THREE.ShaderMaterial;
  private readonly backdropMat: THREE.ShaderMaterial;
  private readonly snowMat: THREE.ShaderMaterial;
  private readonly beams: { mesh: THREE.Mesh; baseX: number; baseZ: number; speed: number; phase: number }[] = [];
  private readonly beamMat: THREE.MeshBasicMaterial;

  constructor() {
    const rnd = mulberry32(1925);

    /* ---- 1. Sky dome ------------------------------------------------- */
    this.skyMat = new THREE.ShaderMaterial({
      vertexShader: skyVert,
      fragmentShader: skyFrag,
      uniforms: {
        uTop: { value: new THREE.Color(PALETTE.skyTop) },
        uHorizon: { value: new THREE.Color(PALETTE.skyHorizon) },
        uGlow: { value: new THREE.Color(PALETTE.skyGlow) },
        uFogColor: { value: new THREE.Color(PALETTE.deskFog) },
        uReveal: { value: 0 },
      },
      side: THREE.BackSide,
      depthWrite: false,
    });
    const sky = new THREE.Mesh(new THREE.SphereGeometry(500, 24, 16), this.skyMat);
    sky.frustumCulled = false;
    sky.renderOrder = -10;
    this.group.add(sky);

    /* ---- 2. Blur-to-Focus Skyline Panorama (`city.jpg`) -------------- */
    const cityTex = new THREE.TextureLoader().load(cityUrl);
    cityTex.colorSpace = THREE.SRGBColorSpace;
    cityTex.minFilter = THREE.LinearFilter;
    cityTex.magFilter = THREE.LinearFilter;

    this.backdropMat = new THREE.ShaderMaterial({
      vertexShader: backdropVert,
      fragmentShader: backdropFrag,
      uniforms: {
        uMap: { value: cityTex },
        uBlur: { value: 1.0 },
        uReveal: { value: 0.0 },
        uFogColor: { value: new THREE.Color(PALETTE.deskFog) },
      },
      transparent: true,
      depthWrite: false,
    });

    const backdropGeo = new THREE.PlaneGeometry(165, 92, 24, 1);
    // Slight cylindrical curve around the horizon so the skyline wraps naturally
    const posAttr = backdropGeo.getAttribute("position");
    for (let i = 0; i < posAttr.count; i++) {
      const x = posAttr.getX(i);
      const zCurve = (x * x) / 420;
      posAttr.setZ(i, zCurve);
    }
    backdropGeo.computeVertexNormals();

    const backdrop = new THREE.Mesh(backdropGeo, this.backdropMat);
    backdrop.position.set(0, 6.2, -92);
    backdrop.renderOrder = -5;
    this.group.add(backdrop);

    /* ---- 3. 3D Ground Plane with Avenue Street Lights ---------------- */
    this.groundMat = new THREE.ShaderMaterial({
      vertexShader: groundVert,
      fragmentShader: groundFrag,
      uniforms: {
        uFogColor: { value: new THREE.Color(PALETTE.deskFog) },
        uFogDensity: { value: 0.5 },
        uCameraPos: { value: new THREE.Vector3() },
        uWindow: { value: new THREE.Color(PALETTE.window) },
      },
    });
    const groundGeo = new THREE.PlaneGeometry(360, 280);
    groundGeo.rotateX(-Math.PI / 2);
    const ground = new THREE.Mesh(groundGeo, this.groundMat);
    ground.position.set(0, WORLD.cityGround, -85);
    this.group.add(ground);

    /* ---- 4. 3D Instanced Manhattan Skyscrapers ----------------------- */
    const count = 1650;
    const box = new THREE.BoxGeometry(1, 1, 1);
    box.translate(0, 0.5, 0);
    this.buildingMat = new THREE.ShaderMaterial({
      vertexShader: buildingVert,
      fragmentShader: buildingFrag,
      uniforms: {
        uFogColor: { value: new THREE.Color(PALETTE.deskFog) },
        uFogDensity: { value: 0.5 },
        uCameraPos: { value: new THREE.Vector3() },
        uTime: { value: 0 },
        uWindow: { value: new THREE.Color(PALETTE.window) },
        uBlur: { value: 1.0 },
      },
    });
    const buildings = new THREE.InstancedMesh(box, this.buildingMat, count);
    buildings.frustumCulled = false;

    const rands = new Float32Array(count);
    const m = new THREE.Matrix4();
    const s = new THREE.Vector3();
    const p = new THREE.Vector3();
    const q = new THREE.Quaternion();

    for (let i = 0; i < count; i++) {
      // Leave central Fifth Avenue / Broadway visual canyon partially open for depth
      const rawX = (rnd() - 0.5) * 140;
      const x = Math.abs(rawX) < 2.2 ? rawX + Math.sign(rawX || 1) * 2.5 : rawX;
      const z = -10 - Math.pow(rnd(), 0.86) * 82;
      const w = 1.4 + rnd() * 2.8;
      const d = 1.4 + rnd() * 2.8;

      const centreBoost = Math.exp(-Math.pow(x / 32, 2));
      const spire = rnd() < 0.14 ? 12 + rnd() * 14 : 0;
      // Keep foreground buildings below the floating quote (`y <= 1.2`) while rising high on the flanks
      const maxH = z > -24 && Math.abs(x) < 12 ? 32 : 41;
      const h = Math.min(maxH, 8 + Math.pow(rnd(), 1.5) * (24 + 10 * centreBoost) + spire);

      p.set(x, WORLD.cityGround, z);
      s.set(w, h, d);
      m.compose(p, q, s);
      buildings.setMatrixAt(i, m);
      rands[i] = rnd();
    }
    buildings.instanceMatrix.needsUpdate = true;
    buildings.geometry.setAttribute(
      "aRand",
      new THREE.InstancedBufferAttribute(rands, 1),
    );
    this.group.add(buildings);

    /* ---- 5. Sweeping 1920s Art Deco Searchlights --------------------- */
    this.beamMat = new THREE.MeshBasicMaterial({
      color: 0xffe6b8,
      transparent: true,
      opacity: 0,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    const coneGeo = new THREE.ConeGeometry(4.2, 58, 16, 1, true);
    coneGeo.translate(0, -29, 0);
    coneGeo.rotateX(Math.PI);

    const beamSpecs = [
      { x: -24, z: -48, baseX: 0.14, baseZ: -0.18, speed: 0.28, phase: 0.4 },
      { x: 18, z: -56, baseX: 0.12, baseZ: 0.22, speed: 0.22, phase: 2.1 },
      { x: -8, z: -72, baseX: 0.18, baseZ: 0.08, speed: 0.19, phase: 4.0 },
    ];
    for (const bs of beamSpecs) {
      const mesh = new THREE.Mesh(coneGeo, this.beamMat);
      mesh.position.set(bs.x, WORLD.cityGround + 16, bs.z);
      this.group.add(mesh);
      this.beams.push({ mesh, ...bs });
    }

    /* ---- 6. 3D Falling Snow Wrapping Around the Camera --------------- */
    const snowCount = 900;
    const snowPos = new Float32Array(snowCount * 3);
    const snowVel = new Float32Array(snowCount * 3);
    for (let i = 0; i < snowCount; i++) {
      snowPos.set(
        [(rnd() - 0.5) * 14, (rnd() - 0.5) * 9, (rnd() - 0.5) * 14],
        i * 3,
      );
      snowVel.set(
        [(rnd() - 0.5) * 0.22, -(0.28 + rnd() * 0.38), (rnd() - 0.5) * 0.22],
        i * 3,
      );
    }
    const snowGeo = new THREE.BufferGeometry();
    snowGeo.setAttribute("position", new THREE.BufferAttribute(snowPos, 3));
    snowGeo.setAttribute("aVel", new THREE.BufferAttribute(snowVel, 3));
    this.snowMat = new THREE.ShaderMaterial({
      vertexShader: snowVert,
      fragmentShader: snowFrag,
      uniforms: {
        uTime: { value: 0 },
        uCameraPos: { value: new THREE.Vector3() },
        uReveal: { value: 0 },
      },
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    const snow = new THREE.Points(snowGeo, this.snowMat);
    snow.frustumCulled = false;
    snow.renderOrder = 25;
    this.group.add(snow);
  }

  update(s: CityUniformState) {
    const bu = this.buildingMat.uniforms;
    (bu.uFogColor.value as THREE.Color).copy(s.fogColor);
    bu.uFogDensity.value = s.fogDensity;
    (bu.uCameraPos.value as THREE.Vector3).copy(s.cameraPos);
    bu.uTime.value = s.time;
    bu.uBlur.value = s.cityBlur;

    const gu = this.groundMat.uniforms;
    (gu.uFogColor.value as THREE.Color).copy(s.fogColor);
    gu.uFogDensity.value = s.fogDensity;
    (gu.uCameraPos.value as THREE.Vector3).copy(s.cameraPos);

    const su = this.skyMat.uniforms;
    (su.uFogColor.value as THREE.Color).copy(s.fogColor);
    su.uReveal.value = s.reveal;

    const bdu = this.backdropMat.uniforms;
    bdu.uBlur.value = s.cityBlur;
    bdu.uReveal.value = s.reveal;
    (bdu.uFogColor.value as THREE.Color).copy(s.fogColor);

    const snu = this.snowMat.uniforms;
    snu.uTime.value = s.time;
    (snu.uCameraPos.value as THREE.Vector3).copy(s.cameraPos);
    snu.uReveal.value = s.reveal;

    this.beamMat.opacity = 0.032 * s.reveal;
    for (const b of this.beams) {
      b.mesh.rotation.x = b.baseX + Math.sin(s.time * b.speed + b.phase) * 0.14;
      b.mesh.rotation.z = b.baseZ + Math.cos(s.time * b.speed * 0.8 + b.phase) * 0.22;
    }
  }
}
