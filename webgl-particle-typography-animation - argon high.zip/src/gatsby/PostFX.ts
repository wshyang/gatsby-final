import * as THREE from "three";
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer.js";
import { OutputPass } from "three/examples/jsm/postprocessing/OutputPass.js";
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass.js";
import { ShaderPass } from "three/examples/jsm/postprocessing/ShaderPass.js";
import { UnrealBloomPass } from "three/examples/jsm/postprocessing/UnrealBloomPass.js";

/**
 * PostFX
 * ------
 * Filmic post-processing stack:
 *  - Soft bloom for luminous airborne typography and golden Manhattan windows
 *  - Warm-to-midnight filmic vignette and subtle 35mm grain
 */
const filmShader = {
  uniforms: {
    tDiffuse: { value: null },
    uTime: { value: 0 },
    uFade: { value: 1 },
  },
  vertexShader: /* glsl */ `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = vec4(position.xy, 0.0, 1.0);
    }
  `,
  fragmentShader: /* glsl */ `
    uniform sampler2D tDiffuse;
    uniform float uTime;
    uniform float uFade;
    varying vec2 vUv;

    float hash(vec2 p) {
      return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
    }

    void main() {
      vec3 col = texture2D(tDiffuse, vUv).rgb;
      vec2 d = (vUv - 0.5) * vec2(1.18, 1.0);
      float vig = clamp(1.0 - dot(d, d) * 0.62, 0.0, 1.0);
      col *= pow(vig, 0.85);

      float g = (hash(vUv * 520.0 + fract(uTime * 1.37)) - 0.5) * 0.022;
      col = max(vec3(0.0), (col + g) * uFade);
      gl_FragColor = vec4(col, 1.0);
    }
  `,
};

export class PostFX {
  readonly composer: EffectComposer;
  private readonly bloom: UnrealBloomPass;
  private readonly film: ShaderPass;

  constructor(
    renderer: THREE.WebGLRenderer,
    scene: THREE.Scene,
    camera: THREE.Camera,
    width: number,
    height: number,
  ) {
    this.composer = new EffectComposer(renderer);
    this.composer.addPass(new RenderPass(scene, camera));

    this.bloom = new UnrealBloomPass(
      new THREE.Vector2(width, height),
      0.34,
      0.58,
      0.78,
    );
    this.composer.addPass(this.bloom);

    this.film = new ShaderPass(filmShader);
    this.composer.addPass(this.film);
    this.composer.addPass(new OutputPass());
  }

  setSize(width: number, height: number, dpr: number) {
    this.composer.setPixelRatio(dpr);
    this.composer.setSize(width, height);
    this.bloom.resolution.set(width, height);
  }

  update(time: number, fade: number) {
    this.film.uniforms.uTime.value = time;
    this.film.uniforms.uFade.value = fade;
  }

  render() {
    this.composer.render();
  }

  dispose() {
    this.composer.dispose();
  }
}
