import * as THREE from "three";
import { TYPE, WORLD } from "./config";
import { makePaperTexture } from "./textures";

/**
 * PaperSurface
 * ------------
 * A physical sheet of manuscript paper in the 3D scene. It is the *only*
 * place glyph particles are allowed to originate from ("No Spawning Out of Nowhere").
 *
 * `poseAt(u, v)` maps normalized paper coordinates (u across the page 0..1,
 * v down the page 0..1) to an exact world-space pose:
 *   - position   : 3D point on the rendered paper mesh
 *   - quaternion : orthonormal frame where +X is the reading direction,
 *                  +Y points up the page, and +Z is the local paper normal.
 *
 * Because the paper mesh geometry itself is constructed by sampling `poseAt(u, v)`,
 * every character at `(u, v)` is mathematically guaranteed to rest on the surface.
 */
export interface SurfacePose {
  position: THREE.Vector3;
  quaternion: THREE.Quaternion;
}

export abstract class PaperSurface {
  readonly id: number;
  readonly width = TYPE.pageWidth;
  readonly height = TYPE.pageHeight;
  /** True when the surface rides on the typewriter carriage (slides while typing). */
  readonly onCarriage: boolean = false;
  abstract readonly mesh: THREE.Mesh;

  constructor(id: number) {
    this.id = id;
  }

  /** World-space pose for normalized paper coordinate (u, v) in [0, 1]^2. */
  abstract poseAt(u: number, v: number, out?: SurfacePose): SurfacePose;
}

const _m = new THREE.Matrix4();
const _x = new THREE.Vector3();
const _y = new THREE.Vector3();
const _z = new THREE.Vector3();

function poseFromBasis(
  out: SurfacePose,
  p: THREE.Vector3,
  x: THREE.Vector3,
  y: THREE.Vector3,
  z: THREE.Vector3,
): SurfacePose {
  out.position.copy(p);
  _m.makeBasis(x, y, z);
  out.quaternion.setFromRotationMatrix(_m);
  return out;
}

export function newPose(): SurfacePose {
  return { position: new THREE.Vector3(), quaternion: new THREE.Quaternion() };
}

/* ------------------------------------------------------------------ */
/*  Manuscript page lying on the writer's desk                         */
/* ------------------------------------------------------------------ */
export class FlatPage extends PaperSurface {
  readonly mesh: THREE.Mesh;
  private readonly matrix = new THREE.Matrix4();
  private readonly invRot = new THREE.Quaternion();
  private readonly curlAmp: number;

  /**
   * @param id       unique surface identifier
   * @param position world position of the page centre on the desk
   * @param yaw      rotation around the vertical Y axis (radians)
   * @param texture  aged bond paper texture
   * @param curlAmp  subtle upward paper arch/curl at edges (metres)
   */
  constructor(
    id: number,
    position: THREE.Vector3,
    yaw: number,
    texture: THREE.Texture,
    curlAmp = 0.0022,
  ) {
    super(id);
    this.curlAmp = curlAmp;

    // Rigid transform of the page frame on the desk
    const rot = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), yaw);
    this.invRot.copy(rot);
    this.matrix.compose(position, rot, new THREE.Vector3(1, 1, 1));

    // Construct a subdivided grid using `localPose` so the paper mesh matches
    // the exact subtle arch/curl that `poseAt(u, v)` returns for every glyph.
    const segU = 16;
    const segV = 20;
    const positions: number[] = [];
    const uvs: number[] = [];
    const indices: number[] = [];
    const pose = newPose();

    for (let j = 0; j <= segV; j++) {
      const v = j / segV;
      for (let i = 0; i <= segU; i++) {
        const u = i / segU;
        this.localPose(u, v, pose);
        positions.push(pose.position.x, pose.position.y, pose.position.z);
        uvs.push(u, 1 - v);
      }
    }
    for (let j = 0; j < segV; j++) {
      for (let i = 0; i < segU; i++) {
        const a = j * (segU + 1) + i;
        const b = a + 1;
        const c = a + segU + 1;
        const d = c + 1;
        indices.push(a, c, b, b, c, d);
      }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
    geo.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
    geo.setIndex(indices);
    geo.computeVertexNormals();

    const mat = new THREE.MeshStandardMaterial({
      map: texture,
      roughness: 0.9,
      metalness: 0.0,
      side: THREE.DoubleSide,
    });

    this.mesh = new THREE.Mesh(geo, mat);
    this.mesh.position.copy(position);
    this.mesh.rotation.y = yaw;
    this.mesh.castShadow = true;
    this.mesh.receiveShadow = true;
    this.mesh.updateMatrix();
  }

  private localPose(u: number, v: number, out: SurfacePose): SurfacePose {
    const lx = (u - 0.5) * this.width;
    const lz = (v - 0.5) * this.height;
    // Gentle organic paper wave & corner lift
    const du = u - 0.5;
    const dv = v - 0.5;
    const ly =
      this.curlAmp * (du * du * 1.4 + dv * dv * 0.9) +
      Math.sin(u * Math.PI) * 0.0008;

    const dydx = (this.curlAmp * 2.8 * du) / this.width;
    const dydz = (this.curlAmp * 1.8 * dv) / this.height;

    out.position.set(lx, ly, lz);
    _x.set(1, dydx, 0).normalize();
    _y.set(0, -dydz, -1).normalize();
    _z.crossVectors(_x, _y).normalize();
    _y.crossVectors(_z, _x).normalize();
    return poseFromBasis(out, out.position, _x, _y, _z);
  }

  poseAt(u: number, v: number, out: SurfacePose = newPose()): SurfacePose {
    this.localPose(u, v, out);
    out.position.applyMatrix4(this.matrix);
    out.quaternion.premultiply(this.invRot);
    return out;
  }
}

/* ------------------------------------------------------------------ */
/*  Manuscript sheet wrapped around the typewriter platen roller       */
/* ------------------------------------------------------------------ */
export class PlatenSheet extends PaperSurface {
  readonly mesh: THREE.Mesh;
  readonly onCarriage = true;
  /** Angle above the printing line where the sheet peels off the rubber platen. */
  readonly thetaEnd = THREE.MathUtils.degToRad(20);
  readonly radius = WORLD.platenRadius;
  /** Arc-length coordinate `s` of the top edge of the sheet (v = 0). */
  readonly sTop: number;
  private readonly base: THREE.Matrix4;

  constructor(
    id: number,
    typewriterMatrix: THREE.Matrix4,
    linesOnSheet: number,
    texture: THREE.Texture,
  ) {
    super(id);
    this.base = typewriterMatrix.clone();
    // Place the final (live-typed) line right on the printing line (s = 0)
    this.sTop = TYPE.marginTop + (linesOnSheet - 0.5) * TYPE.lineHeight;

    const segU = 4;
    const segV = 220;
    const positions: number[] = [];
    const uvs: number[] = [];
    const indices: number[] = [];
    const pose = newPose();
    const local = new THREE.Matrix4().copy(this.base).invert();

    for (let j = 0; j <= segV; j++) {
      const v = j / segV;
      for (let i = 0; i <= segU; i++) {
        const u = i / segU;
        this.poseAt(u, v, pose);
        pose.position.applyMatrix4(local);
        positions.push(pose.position.x, pose.position.y, pose.position.z);
        uvs.push(u, 1 - v);
      }
    }
    for (let j = 0; j < segV; j++) {
      for (let i = 0; i < segU; i++) {
        const a = j * (segU + 1) + i;
        const b = a + 1;
        const c = a + segU + 1;
        const d = c + 1;
        indices.push(a, c, b, b, c, d);
      }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
    geo.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
    geo.setIndex(indices);
    geo.computeVertexNormals();

    const mat = new THREE.MeshStandardMaterial({
      map: texture,
      roughness: 0.88,
      metalness: 0.0,
      side: THREE.DoubleSide,
    });
    this.mesh = new THREE.Mesh(geo, mat);
    this.mesh.castShadow = true;
    this.mesh.receiveShadow = true;
  }

  private localPose(u: number, v: number, out: SurfacePose) {
    const s = this.sTop - v * this.height;
    const r = this.radius;
    const [cx, cy, cz] = WORLD.platenCenter;
    const x = (u - 0.5) * this.width;
    const arc = r * this.thetaEnd;
    let theta: number;
    let py: number;
    let pz: number;
    if (s <= arc) {
      theta = Math.max(s / r, -1.45);
      py = cy + r * Math.sin(theta);
      pz = cz + r * Math.cos(theta);
    } else {
      theta = this.thetaEnd;
      const ext = s - arc;
      py = cy + r * Math.sin(theta) + ext * Math.cos(theta);
      pz = cz + r * Math.cos(theta) - ext * Math.sin(theta);
    }
    out.position.set(cx + x, py, pz);
    _x.set(1, 0, 0);
    _y.set(0, Math.cos(theta), -Math.sin(theta));
    _z.set(0, Math.sin(theta), Math.cos(theta));
    return poseFromBasis(out, out.position, _x, _y, _z);
  }

  poseAt(u: number, v: number, out: SurfacePose = newPose()): SurfacePose {
    this.localPose(u, v, out);
    out.position.applyMatrix4(this.base);
    const rot = new THREE.Quaternion().setFromRotationMatrix(this.base);
    out.quaternion.premultiply(rot);
    return out;
  }
}

/* ------------------------------------------------------------------ */
/*  Factory helpers: 7 scattered manuscript pages across the desk      */
/* ------------------------------------------------------------------ */
export interface PageSpec {
  x: number;
  y: number;
  z: number;
  yaw: number;
  age: number;
  coffeeRing?: boolean;
  crease?: boolean;
  curl?: number;
}

/**
 * 7 scattered manuscript pages arranged around the typewriter so that as the
 * camera slowly pulls back, the desk is covered in rich typewritten pages and
 * 100% of their characters lift off into a dense sea of floating alphabets.
 */
export const PAGE_SPECS: PageSpec[] = [
  // Front-centre-left & front-centre-right (closest to the typewriter front)
  { x: -0.13, y: 0.0022, z: 0.25, yaw: -0.14, age: 0.42, coffeeRing: true, curl: 0.0024 },
  { x: 0.16, y: 0.0032, z: 0.23, yaw: 0.19, age: 0.52, curl: 0.0022 },
  // Left wing pages
  { x: -0.34, y: 0.0014, z: 0.10, yaw: 0.34, age: 0.64, crease: true, curl: 0.0028 },
  { x: -0.30, y: 0.0038, z: 0.36, yaw: -0.28, age: 0.48, curl: 0.0026 },
  // Right wing pages
  { x: 0.37, y: 0.0016, z: 0.06, yaw: -0.38, age: 0.68, crease: true, curl: 0.0026 },
  { x: 0.32, y: 0.0036, z: 0.35, yaw: 0.26, age: 0.56, coffeeRing: true, curl: 0.0025 },
  // Foreground centre manuscript sheet
  { x: 0.01, y: 0.0048, z: 0.44, yaw: 0.06, age: 0.38, crease: true, curl: 0.0024 },
];

export function createFlatPages(startId = 0): FlatPage[] {
  return PAGE_SPECS.map((s, i) => {
    const tex = makePaperTexture({
      seed: 100 + i * 37,
      age: s.age,
      coffeeRing: s.coffeeRing,
      crease: s.crease,
    });
    return new FlatPage(
      startId + i,
      new THREE.Vector3(s.x, s.y, s.z),
      s.yaw,
      tex,
      s.curl ?? 0.0022,
    );
  });
}
