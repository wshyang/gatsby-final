import * as THREE from "three";
import { mulberry32 } from "./GlyphAtlas";

/**
 * Procedural canvas textures for paper sheets, walnut desk, enamel housing,
 * and vintage gold typewriter decal lettering.
 */

export interface PaperOptions {
  seed: number;
  width?: number;
  height?: number;
  /** Base tint; 0 = fresh cream, 1 = heavily aged parchment. */
  age?: number;
  coffeeRing?: boolean;
  crease?: boolean;
}

/** Aged 1920s cotton bond typewriter paper. Glyphs themselves are rendered as instanced 3D quads on top. */
export function makePaperTexture(opts: PaperOptions): THREE.CanvasTexture {
  const w = opts.width ?? 512;
  const h = opts.height ?? 660;
  const rnd = mulberry32(opts.seed);
  const age = opts.age ?? 0.5;

  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const ctx = c.getContext("2d")!;

  // Warm antique cream base
  const base = new THREE.Color().setHSL(0.104, 0.36 + age * 0.14, 0.85 - age * 0.13);
  ctx.fillStyle = `#${base.getHexString()}`;
  ctx.fillRect(0, 0, w, h);

  // Soft foxing blotches
  for (let i = 0; i < 16; i++) {
    const x = rnd() * w;
    const y = rnd() * h;
    const r = 36 + rnd() * 150;
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    const tint = rnd() < 0.5 ? "122,86,42" : "152,122,72";
    g.addColorStop(0, `rgba(${tint},${0.045 + rnd() * 0.08 * age})`);
    g.addColorStop(1, `rgba(${tint},0)`);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
  }

  // Edge darkening / handling vignette
  const vg = ctx.createRadialGradient(w / 2, h / 2, w * 0.26, w / 2, h / 2, w * 0.76);
  vg.addColorStop(0, "rgba(75,52,25,0)");
  vg.addColorStop(1, `rgba(72,48,20,${0.12 + age * 0.15})`);
  ctx.fillStyle = vg;
  ctx.fillRect(0, 0, w, h);

  // Optional fold crease across the page
  if (opts.crease) {
    const cy = h * (0.34 + rnd() * 0.32);
    const cg = ctx.createLinearGradient(0, cy - 8, 0, cy + 8);
    cg.addColorStop(0, "rgba(60,40,18,0)");
    cg.addColorStop(0.45, "rgba(60,40,18,0.11)");
    cg.addColorStop(0.55, "rgba(255,248,230,0.09)");
    cg.addColorStop(1, "rgba(60,40,18,0)");
    ctx.fillStyle = cg;
    ctx.fillRect(0, cy - 8, w, 16);
  }

  // Optional coffee cup stain ring
  if (opts.coffeeRing) {
    const cx = w * (0.25 + rnd() * 0.5);
    const cy = h * (0.28 + rnd() * 0.45);
    const r = 56 + rnd() * 28;
    ctx.save();
    ctx.strokeStyle = "rgba(110,68,26,0.13)";
    ctx.lineWidth = 4.5;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.stroke();
    ctx.strokeStyle = "rgba(110,68,26,0.06)";
    ctx.lineWidth = 10;
    ctx.beginPath();
    ctx.arc(cx + 2, cy - 1, r - 3, 0.4, Math.PI * 1.7);
    ctx.stroke();
    ctx.restore();
  }

  // Laid cotton paper horizontal watermark lines + fine fibre noise
  ctx.fillStyle = "rgba(90,66,36,0.025)";
  for (let y = 0; y < h; y += 4) {
    ctx.fillRect(0, y, w, 1);
  }

  const img = ctx.getImageData(0, 0, w, h);
  const d = img.data;
  for (let i = 0; i < d.length; i += 4) {
    const n = (rnd() - 0.5) * 14;
    d[i] = Math.min(255, Math.max(0, d[i] + n));
    d[i + 1] = Math.min(255, Math.max(0, d[i + 1] + n));
    d[i + 2] = Math.min(255, Math.max(0, d[i + 2] + n));
  }
  ctx.putImageData(img, 0, 0);

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

/** Dark 1920s walnut writer's desk surface texture. */
export function makeWoodTexture(seed = 21): { map: THREE.CanvasTexture; bump: THREE.CanvasTexture } {
  const w = 512;
  const h = 512;
  const rnd = mulberry32(seed);

  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const ctx = c.getContext("2d")!;

  ctx.fillStyle = "#1c110a";
  ctx.fillRect(0, 0, w, h);

  for (let y = 0; y < h; y++) {
    const band = Math.sin(y * 0.045) * 0.5 + Math.sin(y * 0.13 + 1.7) * 0.3 + (rnd() - 0.5) * 0.25;
    const l = Math.round(20 + band * 11);
    ctx.fillStyle = `rgb(${l + 14}, ${Math.max(6, l)}, ${Math.max(3, l - 5)})`;
    ctx.fillRect(0, y, w, 1);
  }

  // Subtle wood pores & plank seams
  ctx.fillStyle = "rgba(8,4,2,0.22)";
  for (let i = 0; i < 650; i++) {
    const x = rnd() * w;
    const y = rnd() * h;
    const len = 18 + rnd() * 68;
    ctx.fillRect(x, y, len, 1 + (rnd() < 0.3 ? 1 : 0));
  }

  const map = new THREE.CanvasTexture(c);
  map.colorSpace = THREE.SRGBColorSpace;
  map.wrapS = map.wrapT = THREE.RepeatWrapping;
  map.repeat.set(3, 3);

  const bump = new THREE.CanvasTexture(c);
  bump.wrapS = bump.wrapT = THREE.RepeatWrapping;
  bump.repeat.set(3, 3);

  return { map, bump };
}

/** Micro-pitted roughness map for cast-iron japanning / baked black enamel on the typewriter. */
export function makeEnamelRoughness(seed = 77): THREE.CanvasTexture {
  const s = 256;
  const rnd = mulberry32(seed);
  const c = document.createElement("canvas");
  c.width = s;
  c.height = s;
  const ctx = c.getContext("2d")!;
  const img = ctx.createImageData(s, s);
  const d = img.data;
  for (let i = 0; i < d.length; i += 4) {
    const v = Math.round(70 + rnd() * 55);
    d[i] = d[i + 1] = d[i + 2] = v;
    d[i + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(4, 4);
  return tex;
}

/** Gold-leaf "UNDERWOOD No. 5" decal texture for the front cross-bar and paper table. */
export function makeTypewriterDecal(): THREE.CanvasTexture {
  const w = 512;
  const h = 128;
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const ctx = c.getContext("2d")!;
  ctx.clearRect(0, 0, w, h);

  // Double gold pinstripe border
  ctx.strokeStyle = "rgba(216, 178, 92, 0.85)";
  ctx.lineWidth = 3;
  ctx.strokeRect(10, 14, w - 20, h - 28);
  ctx.strokeStyle = "rgba(216, 178, 92, 0.45)";
  ctx.lineWidth = 1.5;
  ctx.strokeRect(18, 22, w - 36, h - 44);

  // Gold serif lettering
  ctx.fillStyle = "rgba(232, 196, 110, 0.92)";
  ctx.font = 'bold 34px Georgia, "Times New Roman", serif';
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("U N D E R W O O D", w / 2, h / 2 - 8);

  ctx.fillStyle = "rgba(210, 172, 88, 0.75)";
  ctx.font = '16px Georgia, "Times New Roman", serif';
  ctx.fillText("STANDARD TYPEWRITER  •  NEW YORK", w / 2, h / 2 + 24);

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}
