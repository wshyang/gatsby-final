import * as THREE from "three";
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js";
import { WORLD } from "./config";
import { GlyphAtlas } from "./GlyphAtlas";
import { makeEnamelRoughness, makeTypewriterDecal } from "./textures";

/**
 * Typewriter
 * ----------
 * Photorealistic 1920s desktop typewriter (Underwood No. 5 / Royal standard aesthetic)
 * with an open type-basket cavity and uncorrupted radial type-bar strikers:
 *
 *  - At rest (`strike = 0`), all 42 steel type bars fan radially *outward* from the
 *    inner slotted brass segment ring onto a curved green-felt & brass rest pad inside
 *    the open basket well — never intersecting each other or clipping the housing.
 *  - When struck (`strike(char, phase)`), the active character's type bar pivots
 *    cleanly up through the chrome V-guide so its hammer slug lands *precisely* on
 *    `printingPoint` (`[0, 0.185, -0.118]`), synchronised with the rising ribbon
 *    vibrator, key depression, and rotating ribbon spools.
 */

const KEY_ROWS = ["ZXCVBNM,.?", "ASDFGHJKL;", "QWERTYUIOP", "1234567890"];
const KEY_PITCH = 0.019;
const KEY_ROW_Z = [0.118, 0.092, 0.066, 0.04];
const KEY_ROW_Y = [0.074, 0.082, 0.09, 0.098];
const KEY_ROW_SHIFT = [0.0, -0.007, 0.004, 0.012];
const PRESS_DEPTH = 0.0045;

const BAR_COUNT = 42;
const BAR_LENGTH = 0.054;

const legendVert = /* glsl */ `
  attribute vec3 aPos;
  attribute vec2 aGlyph;
  attribute float aIndex;
  uniform float uSize;
  uniform vec2 uCellSize;
  uniform float uPressed;
  uniform float uPressDepth;
  varying vec2 vUv;
  void main() {
    vUv = aGlyph + uv * uCellSize;
    float dip = (abs(aIndex - uPressed) < 0.5) ? uPressDepth : 0.0;
    vec3 p = aPos + vec3(position.x * uSize, -dip, -position.y * uSize);
    gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
  }
`;

const legendFrag = /* glsl */ `
  uniform sampler2D uAtlas;
  uniform float uOpacity;
  varying vec2 vUv;
  void main() {
    float a = texture2D(uAtlas, vUv).a;
    if (a < 0.02) discard;
    gl_FragColor = vec4(vec3(0.94, 0.89, 0.78), a * uOpacity);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

export class Typewriter {
  readonly group = new THREE.Group();
  readonly carriage = new THREE.Group();
  readonly materials: THREE.Material[] = [];
  /** Exact 3D point on the front of the platen where type bars strike the sheet. */
  readonly printingPoint: THREE.Vector3;

  private keyCaps!: THREE.InstancedMesh;
  private keyRings!: THREE.InstancedMesh;
  private keyBase: THREE.Matrix4[] = [];
  private keyRingBase: THREE.Matrix4[] = [];
  private keyOfChar = new Map<string, number>();
  private legendMat!: THREE.ShaderMaterial;
  private spaceBar!: THREE.Mesh;
  private spaceBarY = 0;

  private bars!: THREE.InstancedMesh;
  private slugs!: THREE.InstancedMesh;
  private barPivot: THREE.Vector3[] = [];
  private barStrikeDir: THREE.Vector3[] = [];
  private barRestDir: THREE.Vector3[] = [];
  private barSideAxis: THREE.Vector3[] = [];
  private barOfChar = new Map<string, number>();

  private vibrator!: THREE.Group;
  private vibratorBaseY = 0;
  private leftSpool!: THREE.Group;
  private rightSpool!: THREE.Group;

  private lastKey = -1;
  private lastBar = -1;

  constructor(legendAtlas: GlyphAtlas, envMap: THREE.Texture | null) {
    const [px, py, pz] = WORLD.platenCenter;
    this.printingPoint = new THREE.Vector3(px, py, pz + WORLD.platenRadius);

    const rough = makeEnamelRoughness();
    const decalTex = makeTypewriterDecal();

    const enamel = new THREE.MeshStandardMaterial({
      color: 0x0b0b0e,
      roughness: 0.34,
      metalness: 0.32,
      roughnessMap: rough,
      envMap,
      envMapIntensity: 1.1,
    });
    const matteWell = new THREE.MeshStandardMaterial({
      color: 0x070709,
      roughness: 0.88,
      metalness: 0.2,
    });
    const chrome = new THREE.MeshStandardMaterial({
      color: 0xdcdce2,
      roughness: 0.18,
      metalness: 0.98,
      envMap,
      envMapIntensity: 1.35,
    });
    const rubber = new THREE.MeshStandardMaterial({
      color: 0x151414,
      roughness: 0.78,
      metalness: 0.04,
    });
    const steel = new THREE.MeshStandardMaterial({
      color: 0x9fa3aa,
      roughness: 0.3,
      metalness: 0.94,
      envMap,
      envMapIntensity: 1.15,
    });
    const darkSteel = new THREE.MeshStandardMaterial({
      color: 0x383a42,
      roughness: 0.45,
      metalness: 0.88,
    });
    const keyGlass = new THREE.MeshStandardMaterial({
      color: 0x121317,
      roughness: 0.14,
      metalness: 0.15,
      envMap,
      envMapIntensity: 1.1,
    });
    const brass = new THREE.MeshStandardMaterial({
      color: 0xc8a055,
      roughness: 0.32,
      metalness: 0.94,
      envMap,
      envMapIntensity: 1.1,
    });
    const felt = new THREE.MeshStandardMaterial({
      color: 0x143322,
      roughness: 0.95,
      metalness: 0.0,
    });
    const ribbon = new THREE.MeshStandardMaterial({
      color: 0x1f0b0d,
      roughness: 0.88,
      metalness: 0.05,
    });
    const decalMat = new THREE.MeshStandardMaterial({
      map: decalTex,
      transparent: true,
      roughness: 0.3,
      metalness: 0.8,
      depthWrite: false,
    });

    this.materials.push(
      enamel,
      matteWell,
      chrome,
      rubber,
      steel,
      darkSteel,
      keyGlass,
      brass,
      felt,
      ribbon,
      decalMat,
    );

    const add = (
      geo: THREE.BufferGeometry,
      mat: THREE.Material,
      pos: [number, number, number],
      parent: THREE.Object3D = this.group,
      rot?: THREE.Euler,
    ) => {
      const m = new THREE.Mesh(geo, mat);
      m.position.set(...pos);
      if (rot) m.rotation.copy(rot);
      m.castShadow = true;
      m.receiveShadow = true;
      parent.add(m);
      return m;
    };

    /* ---- 1. Cast-iron frame with open type-basket well ---------------- */
    // Lower keyboard base frame
    add(new RoundedBoxGeometry(0.37, 0.058, 0.31, 3, 0.011), enamel, [0, 0.029, 0.0]);
    // Rubber feet at the 4 corners
    for (const fx of [-0.16, 0.16]) {
      for (const fz of [-0.12, 0.12]) {
        add(new THREE.CylinderGeometry(0.014, 0.016, 0.008, 16), rubber, [fx, 0.004, fz]);
      }
    }

    // Recessed dark floor of the type-basket cavity so bars never clip any box
    add(new THREE.BoxGeometry(0.22, 0.01, 0.14), matteWell, [0, 0.059, -0.075]);

    // Left and right upper cheek cowls (flanking the open central type-basket well)
    add(new RoundedBoxGeometry(0.082, 0.084, 0.168, 3, 0.012), enamel, [-0.126, 0.098, -0.078]);
    add(new RoundedBoxGeometry(0.082, 0.084, 0.168, 3, 0.012), enamel, [0.126, 0.098, -0.078]);

    // Rear wall behind the type basket supporting the carriage bed
    add(new RoundedBoxGeometry(0.26, 0.088, 0.032, 2, 0.006), enamel, [0, 0.10, -0.148]);

    // Front cross-beam bridging the left and right cowls above the keyboard
    add(new RoundedBoxGeometry(0.334, 0.026, 0.022, 2, 0.005), enamel, [0, 0.122, 0.002]);
    // Gold pinstriping and "UNDERWOOD" decal plate on the front cross-beam
    add(new THREE.BoxGeometry(0.28, 0.0022, 0.002), brass, [0, 0.134, 0.013]);
    add(new THREE.BoxGeometry(0.28, 0.0018, 0.002), brass, [0, 0.110, 0.013]);
    add(new THREE.PlaneGeometry(0.11, 0.022), decalMat, [0, 0.122, 0.0136]);

    // Side frames carrying the carriage rails
    add(new RoundedBoxGeometry(0.028, 0.072, 0.11, 2, 0.006), enamel, [-0.164, 0.128, -0.13]);
    add(new RoundedBoxGeometry(0.028, 0.072, 0.11, 2, 0.006), enamel, [0.164, 0.128, -0.13]);

    // Polished chrome carriage rail
    add(
      new THREE.CylinderGeometry(0.0038, 0.0038, 0.42, 16),
      chrome,
      [0, 0.158, -0.105],
      this.group,
      new THREE.Euler(0, 0, Math.PI / 2),
    );

    /* ---- 2. Ribbon spools & animated ribbon vibrator ------------------ */
    this.leftSpool = new THREE.Group();
    this.leftSpool.position.set(-0.118, 0.142, -0.058);
    this.rightSpool = new THREE.Group();
    this.rightSpool.position.set(0.118, 0.142, -0.058);
    this.group.add(this.leftSpool, this.rightSpool);

    for (const spool of [this.leftSpool, this.rightSpool]) {
      // Cup housing
      add(new THREE.CylinderGeometry(0.029, 0.029, 0.012, 32), chrome, [0, -0.002, 0], spool);
      // Wound ink ribbon roll
      add(new THREE.CylinderGeometry(0.025, 0.025, 0.011, 32), ribbon, [0, 0.001, 0], spool);
      // Top spoked brass reel flange & chrome spindle nut
      add(new THREE.CylinderGeometry(0.027, 0.027, 0.0015, 32), brass, [0, 0.007, 0], spool);
      add(new THREE.CylinderGeometry(0.005, 0.005, 0.016, 16), chrome, [0, 0.009, 0], spool);
    }

    // Ink ribbon feeding from the left/right spools into the center vibrator
    add(
      new THREE.BoxGeometry(0.11, 0.009, 0.0008),
      ribbon,
      [-0.06, 0.162, -0.086],
      this.group,
      new THREE.Euler(0.18, 0.48, 0.34),
    );
    add(
      new THREE.BoxGeometry(0.11, 0.009, 0.0008),
      ribbon,
      [0.06, 0.162, -0.086],
      this.group,
      new THREE.Euler(0.18, -0.48, -0.34),
    );

    // Chrome V-shaped type guide + rising ribbon vibrator right below printingPoint
    this.vibrator = new THREE.Group();
    this.vibratorBaseY = py - 0.008;
    this.vibrator.position.set(0, this.vibratorBaseY, pz + WORLD.platenRadius + 0.0028);
    this.group.add(this.vibrator);

    // Center ribbon strip stretched across the vibrator forks
    add(new THREE.BoxGeometry(0.036, 0.0085, 0.0007), ribbon, [0, 0, 0], this.vibrator);
    // Left and right chrome vibrator prongs
    add(new THREE.BoxGeometry(0.0022, 0.022, 0.0025), chrome, [-0.006, -0.004, 0.0005], this.vibrator);
    add(new THREE.BoxGeometry(0.0022, 0.022, 0.0025), chrome, [0.006, -0.004, 0.0005], this.vibrator);

    // Fixed V-shaped type guide mounted just below the printing point
    add(
      new THREE.BoxGeometry(0.003, 0.018, 0.003),
      steel,
      [-0.0045, py - 0.014, pz + WORLD.platenRadius + 0.004],
      this.group,
      new THREE.Euler(0, 0, -0.22),
    );
    add(
      new THREE.BoxGeometry(0.003, 0.018, 0.003),
      steel,
      [0.0045, py - 0.014, pz + WORLD.platenRadius + 0.004],
      this.group,
      new THREE.Euler(0, 0, 0.22),
    );

    /* ---- 3. Uncorrupted Type-Bar Basket (42 Radial Strikers) ---------- */
    // Each type bar pivots on the semicircular segment ring at distance BAR_LENGTH
    // from `this.printingPoint`.
    //  - At strike = 1: bar points along `strikeDir[i]`, so its hammer tip hits `printingPoint`.
    //  - At strike = 0: bar rotates outward & forward onto the felt rest pad (`restDir[i]`).
    const barGeo = new THREE.BoxGeometry(0.0014, BAR_LENGTH, 0.0028);
    barGeo.translate(0, BAR_LENGTH / 2, 0); // Pivot at local origin (0,0,0), extends along +Y

    // Hammer slug at the tip of each type bar
    const slugGeo = new THREE.BoxGeometry(0.0026, 0.0065, 0.0042);
    slugGeo.translate(0, BAR_LENGTH - 0.0025, 0.0012);

    this.bars = new THREE.InstancedMesh(barGeo, steel, BAR_COUNT);
    this.slugs = new THREE.InstancedMesh(slugGeo, chrome, BAR_COUNT);
    this.bars.castShadow = true;
    this.slugs.castShadow = true;

    const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890,.;?'-";
    const segmentPoints: THREE.Vector3[] = [];
    const restPadPoints: THREE.Vector3[] = [];

    for (let i = 0; i < BAR_COUNT; i++) {
      // Fan angle across the semicircular segment basket (-72 deg to +72 deg)
      const u = i / (BAR_COUNT - 1);
      const phi = THREE.MathUtils.degToRad(-72 + 144 * u);
      const sinP = Math.sin(phi);
      const cosP = Math.cos(phi);

      // Direction from the bar's segment pivot UP/BACK to the exact printingPoint:
      const strikeDir = new THREE.Vector3(
        -sinP * 0.64,
        0.66 + 0.06 * cosP,
        -0.64 * cosP - 0.14,
      ).normalize();

      // Because pivot = printingPoint - strikeDir * BAR_LENGTH, when the bar aligns
      // with `strikeDir` at strike = 1, its tip is guaranteed to be at `printingPoint`!
      const pivot = this.printingPoint.clone().addScaledVector(strikeDir, -BAR_LENGTH);

      // At rest (strike = 0), the bar folds forward/outward away from the platen
      // into the open basket well, forming a radial crown on the felt rest cushion:
      const outward = new THREE.Vector3(
        sinP * 0.72,
        -0.38 - 0.08 * (1 - cosP),
        cosP * 0.78 + 0.18,
      ).normalize();

      // Orthonormal hinge axis perpendicular to both strikeDir and outward
      const sideAxis = new THREE.Vector3().crossVectors(strikeDir, outward).normalize();
      // Rest direction rotated 66 degrees from strikeDir toward outward in the swing plane
      const restAngle = THREE.MathUtils.degToRad(66);
      const restDir = strikeDir.clone().applyAxisAngle(sideAxis, restAngle).normalize();

      this.barPivot.push(pivot);
      this.barStrikeDir.push(strikeDir);
      this.barRestDir.push(restDir);
      this.barSideAxis.push(sideAxis);

      segmentPoints.push(pivot.clone());
      restPadPoints.push(pivot.clone().addScaledVector(restDir, BAR_LENGTH * 0.82));

      const ch = letters[(i * 17) % letters.length];
      if (!this.barOfChar.has(ch.toLowerCase())) {
        this.barOfChar.set(ch.toLowerCase(), i);
      }
      this.setBarPose(i, 0);
    }

    this.bars.instanceMatrix.needsUpdate = true;
    this.slugs.instanceMatrix.needsUpdate = true;
    this.group.add(this.bars, this.slugs);

    // Curved slotted steel segment comb supporting all 42 bar pivots
    const segCurve = new THREE.CatmullRomCurve3(segmentPoints);
    const segGeo = new THREE.TubeGeometry(segCurve, 36, 0.0036, 8, false);
    add(segGeo, darkSteel, [0, -0.001, 0]);
    const segTrimGeo = new THREE.TubeGeometry(segCurve, 36, 0.0018, 8, false);
    add(segTrimGeo, chrome, [0, 0.0022, 0.001]);

    // Curved green-felt & brass type-bar rest cushion under the resting bars
    const restCurve = new THREE.CatmullRomCurve3(restPadPoints);
    const feltGeo = new THREE.TubeGeometry(restCurve, 36, 0.0032, 8, false);
    add(feltGeo, felt, [0, -0.0028, 0]);
    const brassCushionGeo = new THREE.TubeGeometry(restCurve, 36, 0.0038, 8, false);
    add(brassCushionGeo, brass, [0, -0.0052, 0]);

    /* ---- 4. Stepped Glass & Chrome Keyboard -------------------------- */
    const keyCount = KEY_ROWS.reduce((n, r) => n + r.length, 0);
    const capGeo = new THREE.CylinderGeometry(0.0084, 0.0082, 0.004, 24);
    const ringGeo = new THREE.TorusGeometry(0.0084, 0.0011, 8, 32);
    ringGeo.rotateX(Math.PI / 2);
    const stemGeo = new THREE.CylinderGeometry(0.0016, 0.0016, 1, 8);

    this.keyCaps = new THREE.InstancedMesh(capGeo, keyGlass, keyCount);
    this.keyRings = new THREE.InstancedMesh(ringGeo, chrome, keyCount);
    const stems = new THREE.InstancedMesh(stemGeo, chrome, keyCount);
    this.keyCaps.castShadow = true;

    const legendPos: number[] = [];
    const legendGlyph: number[] = [];
    const legendIdx: number[] = [];
    const m = new THREE.Matrix4();
    let k = 0;

    KEY_ROWS.forEach((row, r) => {
      const x0 = -((row.length - 1) * KEY_PITCH) / 2 + KEY_ROW_SHIFT[r];
      for (let i = 0; i < row.length; i++) {
        const x = x0 + i * KEY_PITCH;
        const y = KEY_ROW_Y[r];
        const z = KEY_ROW_Z[r];

        m.makeTranslation(x, y, z);
        this.keyCaps.setMatrixAt(k, m);
        this.keyBase.push(m.clone());

        m.makeTranslation(x, y + 0.002, z);
        this.keyRings.setMatrixAt(k, m);
        this.keyRingBase.push(m.clone());

        const stemH = y - 0.056;
        m.compose(
          new THREE.Vector3(x, 0.056 + stemH / 2, z),
          new THREE.Quaternion(),
          new THREE.Vector3(1, stemH, 1),
        );
        stems.setMatrixAt(k, m);

        legendPos.push(x, y + 0.0025, z);
        legendGlyph.push(...legendAtlas.cellOf(row[i]));
        legendIdx.push(k);
        this.keyOfChar.set(row[i].toLowerCase(), k);
        k++;
      }
    });
    this.group.add(this.keyCaps, this.keyRings, stems);

    const lg = new THREE.InstancedBufferGeometry();
    const plane = new THREE.PlaneGeometry(1, 1);
    lg.index = plane.index;
    lg.setAttribute("position", plane.getAttribute("position"));
    lg.setAttribute("uv", plane.getAttribute("uv"));
    lg.setAttribute("aPos", new THREE.InstancedBufferAttribute(new Float32Array(legendPos), 3));
    lg.setAttribute("aGlyph", new THREE.InstancedBufferAttribute(new Float32Array(legendGlyph), 2));
    lg.setAttribute("aIndex", new THREE.InstancedBufferAttribute(new Float32Array(legendIdx), 1));
    lg.instanceCount = keyCount;

    this.legendMat = new THREE.ShaderMaterial({
      vertexShader: legendVert,
      fragmentShader: legendFrag,
      uniforms: {
        uAtlas: { value: legendAtlas.texture },
        uCellSize: { value: legendAtlas.cellSize },
        uSize: { value: 0.0138 },
        uPressed: { value: -1 },
        uPressDepth: { value: PRESS_DEPTH },
        uOpacity: { value: 1 },
      },
      transparent: true,
      depthWrite: false,
    });
    const legends = new THREE.Mesh(lg, this.legendMat);
    legends.frustumCulled = false;
    legends.renderOrder = 5;
    this.group.add(legends);

    // Space bar + chrome mounting arms
    this.spaceBar = add(
      new RoundedBoxGeometry(0.155, 0.006, 0.016, 2, 0.0025),
      keyGlass,
      [0, 0.068, 0.145],
    );
    this.spaceBarY = 0.068;
    this.keyOfChar.set(" ", -2);
    this.keyOfChar.set("'", this.keyOfChar.get("8")!);
    this.keyOfChar.set('"', this.keyOfChar.get("2")!);
    this.keyOfChar.set("-", this.keyOfChar.get("0")!);
    this.keyOfChar.set(":", this.keyOfChar.get(";")!);
    this.keyOfChar.set("!", this.keyOfChar.get("1")!);

    /* ---- 5. Sliding Carriage & Platen Assembly ----------------------- */
    this.group.add(this.carriage);
    const pr = WORLD.platenRadius - 0.0006;
    const platen = add(
      new THREE.CylinderGeometry(pr, pr, 0.34, 64),
      rubber,
      [px, py, pz],
      this.carriage,
      new THREE.Euler(0, 0, Math.PI / 2),
    );
    platen.castShadow = true;

    // Chrome platen end-caps and knurled platen knobs
    for (const sx of [-1, 1]) {
      add(
        new THREE.CylinderGeometry(0.0175, 0.0175, 0.005, 32),
        chrome,
        [sx * 0.173, py, pz],
        this.carriage,
        new THREE.Euler(0, 0, Math.PI / 2),
      );
      add(
        new THREE.CylinderGeometry(0.004, 0.004, 0.036, 16),
        chrome,
        [sx * 0.188, py, pz],
        this.carriage,
        new THREE.Euler(0, 0, Math.PI / 2),
      );
      add(
        new THREE.CylinderGeometry(0.0165, 0.0165, 0.018, 32),
        enamel,
        [sx * 0.204, py, pz],
        this.carriage,
        new THREE.Euler(0, 0, Math.PI / 2),
      );
    }

    // Carriage bed & graduated chrome margin scale under the platen
    add(
      new RoundedBoxGeometry(0.38, 0.02, 0.068, 2, 0.005),
      enamel,
      [0, py - 0.028, pz + 0.008],
      this.carriage,
    );
    add(
      new THREE.BoxGeometry(0.31, 0.004, 0.002),
      chrome,
      [0, py - 0.016, pz + WORLD.platenRadius + 0.002],
      this.carriage,
    );

    // Chrome paper bail rod + rubber pinch rollers holding the sheet against the platen
    const bailA = THREE.MathUtils.degToRad(40);
    const bailPos: [number, number, number] = [
      0,
      py + Math.sin(bailA) * (WORLD.platenRadius + 0.0024),
      pz + Math.cos(bailA) * (WORLD.platenRadius + 0.0024),
    ];
    add(
      new THREE.CylinderGeometry(0.0015, 0.0015, 0.31, 12),
      chrome,
      bailPos,
      this.carriage,
      new THREE.Euler(0, 0, Math.PI / 2),
    );
    for (const sx of [-1, 1]) {
      add(
        new THREE.CylinderGeometry(0.0042, 0.0042, 0.014, 16),
        rubber,
        [sx * 0.072, bailPos[1], bailPos[2]],
        this.carriage,
        new THREE.Euler(0, 0, Math.PI / 2),
      );
    }

    // Slanted enamel paper table behind the sheet + chrome paper fingers
    add(
      new THREE.BoxGeometry(0.31, 0.076, 0.002),
      enamel,
      [0, py + 0.046, pz - 0.032],
      this.carriage,
      new THREE.Euler(THREE.MathUtils.degToRad(20), 0, 0),
    );
    add(
      new THREE.BoxGeometry(0.31, 0.003, 0.003),
      chrome,
      [0, py + 0.082, pz - 0.045],
      this.carriage,
    );

    // Left-hand chrome carriage-return lever
    add(
      new THREE.CylinderGeometry(0.0026, 0.0026, 0.08, 12),
      chrome,
      [-0.20, py + 0.012, pz + 0.022],
      this.carriage,
      new THREE.Euler(0.2, 0, THREE.MathUtils.degToRad(68)),
    );
    add(
      new THREE.SphereGeometry(0.0055, 14, 10),
      chrome,
      [-0.236, py + 0.026, pz + 0.03],
      this.carriage,
    );

    this.group.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) {
        o.castShadow = true;
        o.receiveShadow = true;
      }
    });
  }

  /** Attach the curved platen manuscript sheet to the sliding carriage. */
  attachSheet(mesh: THREE.Mesh) {
    this.carriage.add(mesh);
    const mat = mesh.material as THREE.Material;
    if (!this.materials.includes(mat)) this.materials.push(mat);
  }

  setCarriageX(x: number) {
    this.carriage.position.x = x;
    // Slowly turn the ribbon spools as the carriage advances
    const spin = x * 8.5;
    this.leftSpool.rotation.y = spin;
    this.rightSpool.rotation.y = spin;
  }

  /**
   * Animate a keystroke and its corresponding type-bar striker.
   * @param char  character being struck (null = all keys and bars at rest)
   * @param phase 0..1 progress through the keystroke
   */
  strike(char: string | null, phase: number) {
    const keyIdx = char === null ? -1 : (this.keyOfChar.get(char.toLowerCase()) ?? -1);
    // Sharp mechanical snap curve: fast up-swing, brief kiss at platen, brisk return
    const p = Math.min(1, Math.max(0, phase));
    const amount = Math.pow(Math.sin(p * Math.PI), 0.75);

    if (this.lastKey >= 0 && this.lastKey !== keyIdx) this.setKeyDip(this.lastKey, 0);
    if (this.lastKey === -2 && keyIdx !== -2) this.spaceBar.position.y = this.spaceBarY;
    if (keyIdx === -2) this.spaceBar.position.y = this.spaceBarY - amount * PRESS_DEPTH * 0.7;
    else if (keyIdx >= 0) this.setKeyDip(keyIdx, amount);

    this.legendMat.uniforms.uPressed.value = keyIdx >= 0 ? keyIdx : -1;
    this.legendMat.uniforms.uPressDepth.value = amount * PRESS_DEPTH;
    this.lastKey = keyIdx;

    const barIdx =
      char === null || char === " "
        ? -1
        : (this.barOfChar.get(char.toLowerCase()) ?? this.barOfChar.get("'")!);

    if (this.lastBar >= 0 && this.lastBar !== barIdx) this.setBarPose(this.lastBar, 0);
    if (barIdx >= 0) this.setBarPose(barIdx, amount);
    if (this.lastBar !== barIdx || barIdx >= 0) {
      this.bars.instanceMatrix.needsUpdate = true;
      this.slugs.instanceMatrix.needsUpdate = true;
    }
    this.lastBar = barIdx;

    // Lift the ribbon vibrator up to the printing line when a type bar strikes
    this.vibrator.position.y = this.vibratorBaseY + (barIdx >= 0 ? amount * 0.0082 : 0);
  }

  private setKeyDip(i: number, amount: number) {
    const m = new THREE.Matrix4().copy(this.keyBase[i]);
    m.elements[13] -= amount * PRESS_DEPTH;
    this.keyCaps.setMatrixAt(i, m);
    m.copy(this.keyRingBase[i]);
    m.elements[13] -= amount * PRESS_DEPTH;
    this.keyRings.setMatrixAt(i, m);
    this.keyCaps.instanceMatrix.needsUpdate = true;
    this.keyRings.instanceMatrix.needsUpdate = true;
  }

  /**
   * Position and orient type bar `i` for strike progress `strike` in [0, 1].
   *  - strike = 0: rests cleanly on the outer felt cushion (`barRestDir[i]`)
   *  - strike = 1: aligned with `barStrikeDir[i]` so tip lands at `printingPoint`
   */
  private setBarPose(i: number, strike: number) {
    const strikeDir = this.barStrikeDir[i];
    const sideAxis = this.barSideAxis[i];
    const restAngle = THREE.MathUtils.degToRad(66);

    // Rotate from strikeDir toward restDir by (1 - strike) * restAngle
    const angle = (1 - strike) * restAngle;
    const yAxis = strikeDir.clone().applyAxisAngle(sideAxis, angle).normalize();
    const xAxis = sideAxis.clone();
    const zAxis = new THREE.Vector3().crossVectors(xAxis, yAxis).normalize();

    const m = new THREE.Matrix4().makeBasis(xAxis, yAxis, zAxis);
    m.setPosition(this.barPivot[i]);
    this.bars.setMatrixAt(i, m);
    this.slugs.setMatrixAt(i, m);
  }

  /** Smoothly dissolve the typewriter as the camera ascends into the night sky. */
  setOpacity(o: number) {
    const transparent = o < 0.999;
    for (const m of this.materials) {
      if (m.transparent !== transparent) {
        m.transparent = transparent;
        m.needsUpdate = true;
      }
      m.opacity = o;
    }
    this.legendMat.uniforms.uOpacity.value = o;
    this.group.visible = o > 0.002;
  }
}
