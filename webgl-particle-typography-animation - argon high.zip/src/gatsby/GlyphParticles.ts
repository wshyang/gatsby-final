import * as THREE from "three";
import { PALETTE } from "./config";
import { GlyphAtlas } from "./GlyphAtlas";
import { ParticleBuffers } from "./Mapping";
import fragmentShader from "./shaders/glyph.frag.glsl?raw";
import vertexShader from "./shaders/glyph.vert.glsl?raw";

/**
 * GlyphParticles
 * --------------
 * A single instanced WebGL draw call rendering every typewritten character in
 * the scene — resting on the 8 manuscript pages, peeling off into the swirling
 * sea of alphabets, and locking into the 4-line floating quote over Manhattan.
 */
export interface GlyphUniformState {
  time: number;
  carriageX: number;
  focusDist: number;
  focusRange: number;
  deskFade: number;
  dissolve: number;
  fogDensity: number;
  fogColor: THREE.Color;
  opacity: number;
  pixelsPerUnit: number;
}

export class GlyphParticles {
  readonly mesh: THREE.Mesh;
  readonly material: THREE.ShaderMaterial;
  readonly geometry: THREE.InstancedBufferGeometry;
  /** Visualiser: gold lines connecting each quote character's paper origin to its 3D target slot. */
  readonly links: THREE.LineSegments;

  constructor(buffers: ParticleBuffers, atlas: GlyphAtlas) {
    const base = new THREE.PlaneGeometry(1, 1, 1, 1);
    const geo = new THREE.InstancedBufferGeometry();
    geo.index = base.index;
    geo.setAttribute("position", base.getAttribute("position"));
    geo.setAttribute("uv", base.getAttribute("uv"));
    geo.instanceCount = buffers.count;

    const inst = (arr: Float32Array, size: number) =>
      new THREE.InstancedBufferAttribute(arr, size);
    geo.setAttribute("aOrigin", inst(buffers.origin, 3));
    geo.setAttribute("aOriginQuat", inst(buffers.originQuat, 4));
    geo.setAttribute("aTarget", inst(buffers.target, 3));
    geo.setAttribute("aTargetQuat", inst(buffers.targetQuat, 4));
    geo.setAttribute("aGlyph", inst(buffers.glyph, 2));
    geo.setAttribute("aTiming", inst(buffers.timing, 4));
    geo.setAttribute("aSeed", inst(buffers.seed, 4));
    geo.setAttribute("aScale", inst(buffers.scale, 2));
    geo.setAttribute("aCarriage", inst(buffers.carriage, 1));
    geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e5);
    this.geometry = geo;

    this.material = new THREE.ShaderMaterial({
      vertexShader,
      fragmentShader,
      uniforms: {
        uAtlas: { value: atlas.texture },
        uCellSize: { value: atlas.cellSize },
        uCellPx: { value: atlas.cellPx },
        uPixelsPerUnit: { value: 900 },
        uTime: { value: 0 },
        uCarriageX: { value: 0 },
        uFocusDist: { value: 0.3 },
        uFocusRange: { value: 0.2 },
        uDeskFade: { value: 1 },
        uDissolve: { value: 0 },
        uFogDensity: { value: 0 },
        uFogColor: { value: new THREE.Color(PALETTE.deskFog) },
        uOpacity: { value: 1 },
        uInk: { value: new THREE.Color(PALETTE.ink) },
        uCream: { value: new THREE.Color(PALETTE.cream) },
      },
      transparent: true,
      depthWrite: false,
      depthTest: true,
      side: THREE.DoubleSide,
    });

    this.mesh = new THREE.Mesh(geo, this.material);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = 20;

    const linkGeo = new THREE.BufferGeometry();
    linkGeo.setAttribute(
      "position",
      new THREE.BufferAttribute(buffers.memberLinks, 3),
    );
    this.links = new THREE.LineSegments(
      linkGeo,
      new THREE.LineBasicMaterial({
        color: PALETTE.gold,
        transparent: true,
        opacity: 0.38,
        depthWrite: false,
        fog: false,
      }),
    );
    this.links.frustumCulled = false;
    this.links.visible = false;
    this.links.renderOrder = 21;
  }

  update(s: GlyphUniformState) {
    const u = this.material.uniforms;
    u.uTime.value = s.time;
    u.uCarriageX.value = s.carriageX;
    u.uFocusDist.value = s.focusDist;
    u.uFocusRange.value = s.focusRange;
    u.uDeskFade.value = s.deskFade;
    u.uDissolve.value = s.dissolve;
    u.uFogDensity.value = s.fogDensity;
    (u.uFogColor.value as THREE.Color).copy(s.fogColor);
    u.uOpacity.value = s.opacity;
    u.uPixelsPerUnit.value = s.pixelsPerUnit;
  }

  dispose() {
    this.geometry.dispose();
    this.material.dispose();
    this.links.geometry.dispose();
    (this.links.material as THREE.Material).dispose();
  }
}
