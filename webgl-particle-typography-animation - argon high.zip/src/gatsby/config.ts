/**
 * Global configuration for The Great Gatsby (2013) WebGL typographic lift-off sequence.
 *
 * Every visual element in the scene is a deterministic function of `time` (seconds),
 * allowing smooth scrubbing, looping, and frame-accurate inspection.
 *
 * Key adjustments informed by `reviews.txt`:
 *  - Slower, weighted camera zoom-out from the platen and unhurried crane/pan to the skyline.
 *  - Cohesive world scale (~4m crane ascent instead of a 30m jump) so characters peel off
 *    at a gentle, tactile velocity and form a dense, readable sea of floating alphabets.
 *  - 100% of characters across all 8 visible paper surfaces (1 platen sheet + 7 desk pages)
 *    lift off into the swirling stream (`stays = 0`).
 */

/* ------------------------------------------------------------------ */
/*  Timeline (seconds)                                                 */
/* ------------------------------------------------------------------ */
export const TIMELINE = {
  /** Total loop duration in seconds. */
  duration: 28.0,
  /** Initial fade in from black. */
  fadeIn: [0.0, 1.2] as const,
  /** The typewriter strikes the final line onto the platen manuscript sheet. */
  typingStart: 0.7,
  typingInterval: 0.082,
  /** First characters on the freshly typed line begin slowly peeling off. */
  memberLiftStart: 5.3,
  /** All characters across all scattered pages lift off in a slow outward wave. */
  chaffLiftStart: 5.7,
  chaffLiftSpread: 6.4,
  /** Desk and typewriter stay in frame during the slow crane-back, then dissolve. */
  deskFade: [12.0, 15.6] as const,
  /** Warm desk fog thins into cool night air, revealing the 3D city + skyline. */
  cityReveal: [9.2, 16.2] as const,
  /** The blurred city backdrop image smoothly racks into crisp focus (fable_low technique). */
  cityFocus: [10.5, 18.2] as const,
  /** Camera settles over Manhattan; quote words magnetically lock into 3D space. */
  firstArrival: 15.6,
  /** After holding legibly against the skyline, the quote gently drifts into the night. */
  dissolve: [24.6, 27.3] as const,
  /** Final fade to black before looping. */
  fadeOut: [26.3, 27.8] as const,
};

/* ------------------------------------------------------------------ */
/*  Typewriter typography (metres on physical paper)                   */
/* ------------------------------------------------------------------ */
/** 10 characters per inch / 6 lines per inch (12pt pica vintage typewriter). */
export const TYPE = {
  cellWidth: 0.0254 / 10,
  lineHeight: 0.0254 / 6,
  /** Square glyph quad side as multiple of lineHeight (room for descenders + ink halo). */
  quadScale: 1.28,
  columns: 65,
  pageWidth: 0.216,
  pageHeight: 0.279,
  marginLeft: 0.025,
  marginTop: 0.026,
};

/* ------------------------------------------------------------------ */
/*  The floating quote formation                                       */
/* ------------------------------------------------------------------ */
export interface FormationLine {
  text: string;
  /** Glyph quad size in world units (at formation distance = 5.2m from camera). */
  size: number;
  /** Offset from the formation centre in camera space: [right, up, towardsCamera]. */
  offset: [number, number, number];
  /** Second at which the first word of this line locks into place. */
  arrival: number;
  /** Seconds between consecutive words locking into place. */
  wordStagger: number;
  /**
   * Donor pool:
   *  - "typed" -> 1:1 identity mapping from the live-typed line on the platen sheet
   *  - "pages" -> character-matched harvesting from the scattered desk pages
   */
  source: "typed" | "pages";
}

/**
 * The line struck live on the sheet in the typewriter. It forms the first two
 * lines of the floating quote, so those characters map 1:1 from platen to sky.
 */
export const TYPED_LINE = "After Gatsby's death, New York was haunted for me...";

export const FORMATION: FormationLine[] = [
  {
    text: "After Gatsby's death,",
    size: 0.36,
    offset: [-0.58, 0.74, 0.18],
    arrival: 15.6,
    wordStagger: 0.44,
    source: "typed",
  },
  {
    text: "New York was haunted for me...",
    size: 0.36,
    offset: [0.1, 0.24, 0.0],
    arrival: 17.0,
    wordStagger: 0.35,
    source: "typed",
  },
  {
    text: "distorted beyond my eyes'",
    size: 0.265,
    offset: [0.42, -0.32, -0.36],
    arrival: 18.8,
    wordStagger: 0.32,
    source: "pages",
  },
  {
    text: "power of correction.",
    size: 0.265,
    offset: [0.92, -0.68, -0.58],
    arrival: 20.0,
    wordStagger: 0.32,
    source: "pages",
  },
];

/* ------------------------------------------------------------------ */
/*  Manuscript text (F. Scott Fitzgerald, The Great Gatsby)            */
/*  Used to densely populate all 7 scattered desk pages + platen sheet */
/*  so ~5,400 real paper-bound characters lift into the sea of letters */
/* ------------------------------------------------------------------ */
export const PAGE_TEXTS: string[][] = [
  [
    "In my younger and more vulnerable years my father gave me some advice that I've been turning over in my mind ever since.",
    "\"Whenever you feel like criticizing any one,\" he told me, \"just remember that all the people in this world haven't had the advantages that you've had.\"",
    "He didn't say any more, but we've always been unusually communicative in a reserved way, and I understood that he meant a great deal more than that. In consequence, I'm inclined to reserve all judgments, a habit that has opened up many curious natures to me and also made me the victim of not a few veteran bores.",
    "The abnormal mind is quick to detect and attach itself to this quality when it appears in a normal person, and so it came about that in college I was unjustly accused of being a politician, because I was privy to the secret griefs of wild, unknown men.",
    "Most of the confidences were unsought - frequently I have feigned sleep, preoccupation, or a hostile levity when I realized by some unmistakable sign that an intimate revelation was quivering on the horizon.",
  ],
  [
    "And, after boasting this way of my tolerance, I come to the admission that it has a limit. Conduct may be founded on the hard rock or the wet marshes, but after a certain point I don't care what it's founded on.",
    "When I came back from the East last autumn I felt that I wanted the world to be in uniform and at a sort of moral attention forever; I wanted no more riotous excursions with privileged glimpses into the human heart.",
    "Only Gatsby, the man who gives his name to this book, was exempt from my reaction - Gatsby, who represented everything for which I have an unaffected scorn.",
    "If personality is an unbroken series of successful gestures, then there was something gorgeous about him, some heightened sensitivity to the promises of life, as if he were related to one of those intricate machines that register earthquakes ten thousand miles away.",
    "This responsiveness had nothing to do with that flabby impressionability which is dignified under the name of the \"creative temperament\" - it was an extraordinary gift for hope, a romantic readiness such as I have never found in any other person and which it is not likely I shall ever find again.",
  ],
  [
    "Gatsby believed in the green light, the orgastic future that year by year recedes before us. It eluded us then, but that's no matter - tomorrow we will run faster, stretch out our arms farther... And one fine morning -",
    "So we beat on, boats against the current, borne back ceaselessly into the past.",
    "Most of the big shore places were closed now and there were hardly any lights except the shadowy, moving glow of a ferryboat across the Sound. And as the moon rose higher the inessential houses began to melt away until gradually I became aware of the old island here that flowered once for Dutch sailors' eyes - a fresh, green breast of the new world.",
    "Its vanished trees, the trees that had made way for Gatsby's house, had once pandered in whispers to the last and greatest of all human dreams; for a transitory enchanted moment man must have held his breath in the presence of this continent, compelled into an aesthetic contemplation he neither understood nor desired, face to face for the last time in history with something commensurate to his capacity for wonder.",
  ],
  [
    "One of my most vivid memories is of coming back West from prep school and later from college at Christmas time. Those who went farther than Chicago would gather in the old dim Union Station at six o'clock of a December evening, with a few Chicago friends, already caught up into their own holiday gaieties, to bid them a hasty good-by.",
    "When we pulled out into the winter night and the real snow, our snow, began to stretch out beside us and twinkle against the windows, and the dim lights of small Wisconsin stations moved by, a sharp wild brace came suddenly into the air.",
    "That's my Middle West - not the wheat or the prairies or the lost Swede towns, but the thrilling returning trains of my youth, and the street lamps and sleigh bells in the frosty dark and the shadows of holly wreaths thrown by lighted windows on the snow.",
    "I see now that this has been a story of the West, after all - Tom and Gatsby, Daisy and Jordan and I, were all Westerners, and perhaps we possessed some deficiency in common which made us subtly unadaptable to Eastern life.",
  ],
  [
    "There was music from my neighbor's house through the summer nights. In his blue gardens men and girls came and went like moths among the whisperings and the champagne and the stars. At high tide in the afternoon I watched his guests diving from the tower of his raft, or taking the sun on the hot sand of his beach while his two motor-boats slit the waters of the Sound.",
    "On week-ends his Rolls-Royce became an omnibus, bearing parties to and from the city between nine in the morning and long past midnight, while his station wagon scampered like a brisk yellow bug to meet all trains.",
    "And on Mondays eight servants, including an extra gardener, toiled all day with mops and scrubbing-brushes and hammers and garden-shears, repairing the ravages of the night before.",
    "Every Friday five crates of oranges and lemons arrived from a fruiterer in New York - every Monday these same oranges and lemons left his back door in a pyramid of pulpless halves.",
  ],
  [
    "At least once a fortnight a corps of caterers came down with several hundred feet of canvas and enough colored lights to make a Christmas tree of Gatsby's enormous garden.",
    "On buffet tables, garnished with glistening hors-d'oeuvre, spiced baked hams crowded against salads of harlequin designs and pastry pigs and turkeys bewitched to a dark gold. In the main hall a bar with a real brass rail was set up, and stocked with gins and liquors and with cordials so long forgotten that most of his female guests were too young to know one from another.",
    "By seven o'clock the orchestra has arrived, no thin five-piece affair, but a whole pitful of oboes and trombones and saxophones and viols and cornets and piccolos, and low and high drums.",
    "The bar is in full swing, and floating rounds of cocktails permeate the garden outside, until the air is alive with chatter and laughter, and casual innuendo and introductions forgotten on the spot.",
  ],
  [
    "The lights grow brighter as the earth lurches away from the sun, and now the orchestra is playing yellow cocktail music, and the opera of voices pitches a key higher. Laughter is easier minute by minute, spilled with prodigality, tipped out at a cheerful word.",
    "The groups change more swiftly, swell with new arrivals, dissolve and form in the same breath; already there are wanderers, confident girls who weave here and there among the stouter and more stable, become for a sharp, joyous moment the center of a group, and then, excited with triumph, glide on through the sea-change of faces and voices and color under the constantly changing light.",
    "Suddenly one of these gypsies, in trembling opal, seizes a cocktail out of the air, dumps it down for courage and, moving her hands like Frisco, dances out alone on the canvas platform.",
    "A momentary hush; the orchestra leader varies his rhythm obligingly for her, and there is a burst of chatter as the erroneous news goes around that she is Gilda Gray's understudy from the Follies.",
  ],
];

/** Text already printed on the sheet in the typewriter (above the live-typed line). */
export const SHEET_TEXT: string[] = [
  "Even when the East excited me most, even when I was most keenly aware of its superiority to the bored, sprawling, swollen towns beyond the Ohio, with their interminable inquisitions which spared only the children and the very old - even then it had always for me a quality of distortion.",
  "West Egg, especially, still figures in my more fantastic dreams. I see it as a night scene by El Greco: a hundred houses, at once conventional and grotesque, crouching under a sullen, overhanging sky and a lustreless moon.",
  "In the foreground four solemn men in dress suits are walking along the sidewalk with a stretcher on which lies a drunken woman in a white evening dress. Her hand, which dangles over the side, sparkles cold with jewels. Gravely the men turn in at a house - the wrong house. But no one knows the woman's name, and no one cares.",
];

/* ------------------------------------------------------------------ */
/*  Palette                                                            */
/* ------------------------------------------------------------------ */
export const PALETTE = {
  ink: 0x18161d,
  cream: 0xfff3db,
  gold: 0xdcb862,
  deskFog: 0x0b0806,
  cityFog: 0x091220,
  skyTop: 0x04070e,
  skyHorizon: 0x1a2840,
  skyGlow: 0x4d3722,
  window: 0xffba6b,
};

/** World-space constants shared across modules. */
export const WORLD = {
  /** y of the 3D city ground plane below the aerial camera. */
  cityGround: -42,
  /** Distance from settled camera to the floating quote formation. */
  formationDistance: 5.2,
  /** Platen roller centre in typewriter-local coordinates. */
  platenCenter: [0, 0.185, -0.14] as const,
  platenRadius: 0.022,
};
