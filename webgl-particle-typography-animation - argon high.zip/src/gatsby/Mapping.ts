import * as THREE from "three";
import { TIMELINE } from "./config";
import { GlyphAtlas, mulberry32 } from "./GlyphAtlas";
import { CameraFrame, SourceGlyph, TargetSlot } from "./TextLayout";

/**
 * Mapping
 * -------
 * Connects characters that physically exist on the 8 manuscript paper surfaces
 * (`SourceGlyph`) with cells of the floating quote (`TargetSlot`) and packs the
 * result into per-instance GPU attributes.
 *
 *   PaperSurface ──poseAt(u,v)──▶ SourceGlyph ──assignment──▶ TargetSlot / Sea of Alphabets
 *                                      │                           │
 *                                 aOrigin/aOriginQuat        aTarget/aTargetQuat
 *
 * Strict Constraint ("No Spawning Out of Nowhere"):
 *   Every particle starts at its exact `SourceGlyph` coordinate on a physical paper mesh.
 *
 * Feedback from `reviews.txt` applied here:
 *   1. "For better effect, all the letters on all visible pages should lift off."
 *      -> 100% of characters on all 8 surfaces lift off (`stays = 0`).
 *   2. "The character lift off is too fast." & "The floating sea of alphabets is too sparse."
 *      -> Extended lift-off wave (`chaffLiftSpread = 6.4s`), longer flight durations
 *         (`9.5s..16.5s`), and multi-depth camera-corridor placement so thousands of
 *         well-sized typewriter letters fill the 3D volume throughout the ascent & hold.
 */

export const KIND_STAY = -1;
export const KIND_CHAFF = 0;
export const KIND_MEMBER = 1;

export interface Assignment {
  slot: TargetSlot;
  source: SourceGlyph;
  liftTime: number;
}

export interface MappingStats {
  sources: number;
  members: number;
  chaff: number;
  stays: number;
  identityMapped: number;
  searchMapped: number;
  fallbackClones: number;
}

export type CameraSampler = (t: number, out: CameraFrame) => CameraFrame;

/* ------------------------------------------------------------------ */
/*  1. Assign quote slots to real paper characters                     */
/* ------------------------------------------------------------------ */

export function assignSlots(
  sources: SourceGlyph[],
  slots: TargetSlot[],
  typedGlyphs: SourceGlyph[],
  stats: MappingStats,
  seed = 99,
): Assignment[] {
  const rnd = mulberry32(seed);
  const used = new Set<number>();
  const assignments: Assignment[] = [];

  const typedIds = new Set(typedGlyphs.map((g) => g.id));
  const byChar = new Map<string, SourceGlyph[]>();
  for (const g of sources) {
    if (g.onCarriage || typedIds.has(g.id)) continue;
    let arr = byChar.get(g.char);
    if (!arr) byChar.set(g.char, (arr = []));
    arr.push(g);
  }

  // --- 1:1 identity mapping of the freshly typed line on the platen ------
  let typedCursor = 0;
  const typedSlots = slots.filter((s) => s.source === "typed");
  for (const slot of typedSlots) {
    const g = typedGlyphs[typedCursor];
    if (g && g.char === slot.char) {
      used.add(g.id);
      assignments.push({
        slot,
        source: g,
        liftTime: TIMELINE.memberLiftStart + typedCursor * 0.055 + rnd() * 0.06,
      });
      stats.identityMapped++;
      typedCursor++;
    } else {
      const alt = harvest(slot, byChar, used, null, sources, stats);
      assignments.push({
        slot,
        source: alt,
        liftTime: TIMELINE.memberLiftStart + 0.7 + rnd() * 0.6,
      });
    }
  }

  // --- Word-clustered nearest-neighbour harvesting from the 7 desk pages ---
  const pageGlyphs = sources.filter((g) => !g.onCarriage);
  const pageSlots = slots.filter((s) => s.source === "pages");
  let currentWord = -1;
  let currentLine = -1;
  let seedPoint: THREE.Vector3 | null = null;
  let wordLift = 0;

  for (const slot of pageSlots) {
    if (slot.word !== currentWord || slot.line !== currentLine) {
      currentWord = slot.word;
      currentLine = slot.line;
      seedPoint = pageGlyphs[Math.floor(rnd() * pageGlyphs.length)].position;
      wordLift =
        TIMELINE.chaffLiftStart +
        0.35 +
        ((slot.line - 2) * 5 + slot.word) * 0.28 +
        rnd() * 0.35;
    }
    const g = harvest(slot, byChar, used, seedPoint, sources, stats);
    assignments.push({
      slot,
      source: g,
      liftTime: wordLift + slot.charInWord * 0.075,
    });
  }

  return assignments;
}

function harvest(
  slot: TargetSlot,
  byChar: Map<string, SourceGlyph[]>,
  used: Set<number>,
  seedPoint: THREE.Vector3 | null,
  sources: SourceGlyph[],
  stats: MappingStats,
): SourceGlyph {
  const tryChars = [slot.char, slot.char.toLowerCase(), slot.char.toUpperCase()];
  for (const ch of tryChars) {
    const pool = byChar.get(ch);
    if (!pool) continue;
    let best: SourceGlyph | null = null;
    let bestD = Infinity;
    for (const g of pool) {
      if (used.has(g.id)) continue;
      const d = seedPoint ? g.position.distanceToSquared(seedPoint) : 0;
      if (d < bestD) {
        bestD = d;
        best = g;
        if (!seedPoint) break;
      }
    }
    if (best) {
      used.add(best.id);
      stats.searchMapped++;
      return best;
    }
  }

  // Last-resort over-strike at the nearest page character coordinate (still on paper)
  let nearest = sources[0];
  if (seedPoint) {
    let bestD = Infinity;
    for (const g of sources) {
      if (g.onCarriage) continue;
      const d = g.position.distanceToSquared(seedPoint);
      if (d < bestD) {
        bestD = d;
        nearest = g;
      }
    }
  }
  const clone: SourceGlyph = {
    ...nearest,
    id: sources.length,
    char: slot.char,
    position: nearest.position.clone(),
    quaternion: nearest.quaternion.clone(),
  };
  sources.push(clone);
  used.add(clone.id);
  stats.fallbackClones++;
  return clone;
}

/* ------------------------------------------------------------------ */
/*  2. Pack GPU instanced attribute buffers                            */
/* ------------------------------------------------------------------ */

export interface ParticleBuffers {
  count: number;
  origin: Float32Array;     // vec3  rest position on the paper mesh
  originQuat: Float32Array; // vec4  rest orientation on the paper mesh
  target: Float32Array;     // vec3  destination (quote slot or sea-of-letters drift point)
  targetQuat: Float32Array; // vec4  destination orientation
  glyph: Float32Array;      // vec2  atlas cell UV origin
  timing: Float32Array;     // vec4  (appear, lift, duration, kind)
  seed: Float32Array;       // vec4  per-particle random numbers
  scale: Float32Array;      // vec2  (origin size on paper, airborne/target size)
  carriage: Float32Array;   // float 1 = rides on the typewriter carriage
  /** Pairs of 3D points (origin -> target) for the mapping trajectory overlay. */
  memberLinks: Float32Array;
}

export function buildParticleBuffers(
  sources: SourceGlyph[],
  assignments: Assignment[],
  atlas: GlyphAtlas,
  cameraAt: CameraSampler,
  stats: MappingStats,
  seed = 1234,
): ParticleBuffers {
  const rnd = mulberry32(seed);
  const n = sources.length;
  const b: ParticleBuffers = {
    count: n,
    origin: new Float32Array(n * 3),
    originQuat: new Float32Array(n * 4),
    target: new Float32Array(n * 3),
    targetQuat: new Float32Array(n * 4),
    glyph: new Float32Array(n * 2),
    timing: new Float32Array(n * 4),
    seed: new Float32Array(n * 4),
    scale: new Float32Array(n * 2),
    carriage: new Float32Array(n),
    memberLinks: new Float32Array(assignments.length * 6),
  };

  const bySource = new Map<number, Assignment>();
  for (const a of assignments) bySource.set(a.source.id, a);

  const frame: CameraFrame = {
    position: new THREE.Vector3(),
    quaternion: new THREE.Quaternion(),
  };
  const right = new THREE.Vector3();
  const up = new THREE.Vector3();
  const fwd = new THREE.Vector3();
  const tgt = new THREE.Vector3();
  const q = new THREE.Quaternion();
  const e = new THREE.Euler();

  // Lift-off wave origin starts near the typewriter front and ripples out over all 7 pages
  const waveOrigin = new THREE.Vector3(0, 0.12, -0.05);
  let linkIdx = 0;

  for (let i = 0; i < n; i++) {
    const g = sources[i];
    const a = bySource.get(g.id);

    b.origin.set([g.position.x, g.position.y, g.position.z], i * 3);
    b.originQuat.set(
      [g.quaternion.x, g.quaternion.y, g.quaternion.z, g.quaternion.w],
      i * 4,
    );
    b.glyph.set(atlas.cellOf(g.char), i * 2);
    b.seed.set([rnd(), rnd(), rnd(), rnd()], i * 4);
    b.carriage[i] = g.onCarriage ? 1 : 0;
    const appear = g.typedAt >= 0 ? g.typedAt : -1;

    if (a) {
      // ---- Quote member: paper coordinate -> 3D quote formation slot ----
      const s = a.slot;
      const duration = Math.max(4.5, s.arrival - a.liftTime);
      b.target.set([s.position.x, s.position.y, s.position.z], i * 3);
      b.targetQuat.set(
        [s.quaternion.x, s.quaternion.y, s.quaternion.z, s.quaternion.w],
        i * 4,
      );
      b.timing.set([appear, a.liftTime, duration, KIND_MEMBER], i * 4);
      b.scale.set([g.size, s.size], i * 2);
      b.memberLinks.set(
        [
          g.position.x,
          g.position.y,
          g.position.z,
          s.position.x,
          s.position.y,
          s.position.z,
        ],
        linkIdx * 6,
      );
      linkIdx++;
      stats.members++;
      continue;
    }

    // ---- 100% of all non-quote glyphs on all visible pages lift off! ----
    // (`reviews.txt`: "For better effect, all the letters on all visible pages should lift off.")
    const dist = g.position.distanceTo(waveOrigin);
    const radialNorm = Math.min(1, dist / 0.62);
    // Top lines on a sheet peel slightly earlier than lower lines, like a breeze lifting the text
    const lineWave = (g.u * 0.25 + g.v * 0.75) * 0.9;
    const surfaceStagger = g.onCarriage ? 0.0 : 0.35 + (g.surfaceId % 4) * 0.28;
    const lift =
      TIMELINE.chaffLiftStart +
      radialNorm * (TIMELINE.chaffLiftSpread * 0.62) +
      lineWave +
      surfaceStagger +
      rnd() * 0.95;

    // Long, unhurried flight duration so the sea of alphabets stays lush and dense
    // throughout the entire camera pan and quote assembly phase
    const duration = 9.2 + rnd() * 7.8;

    // Place chaff destination in the camera's frustum corridor between mid-ascent and hold
    const sampleTime = Math.min(TIMELINE.duration - 1.5, lift + duration * (0.55 + rnd() * 0.35));
    cameraAt(sampleTime, frame);
    right.set(1, 0, 0).applyQuaternion(frame.quaternion);
    up.set(0, 1, 0).applyQuaternion(frame.quaternion);
    fwd.set(0, 0, -1).applyQuaternion(frame.quaternion);

    // Multi-layered depth distribution:
    //  - 25% foreground bokeh letters drifting close to the lens (1.0m .. 2.4m)
    //  - 50% mid-ground swirling sea around the quote plane (2.4m .. 5.4m)
    //  - 25% deep background atmospheric letters (5.4m .. 8.2m)
    const layer = rnd();
    const fz =
      layer < 0.25
        ? 1.0 + rnd() * 1.4
        : layer < 0.75
          ? 2.4 + rnd() * 3.0
          : 5.4 + rnd() * 2.8;

    const spreadX = (rnd() - 0.5) * 1.45 * fz;
    const spreadY = (rnd() - 0.46) * 0.92 * fz;

    tgt
      .copy(frame.position)
      .addScaledVector(fwd, fz)
      .addScaledVector(right, spreadX)
      .addScaledVector(up, spreadY);

    // Slightly bias orientation toward the camera with organic 3D tilt so letters
    // in the sea of alphabets are readable from multiple angles as they tumble
    q.copy(frame.quaternion).multiply(
      new THREE.Quaternion().setFromEuler(
        e.set(
          (rnd() - 0.5) * 1.35,
          (rnd() - 0.5) * 1.35,
          (rnd() - 0.5) * Math.PI * 1.5,
        ),
      ),
    );

    // Well-proportioned letter sizes in the sea of alphabets (praised in `fable_low` review)
    const seaSize = 0.072 + Math.pow(rnd(), 0.75) * 0.145;

    b.target.set([tgt.x, tgt.y, tgt.z], i * 3);
    b.targetQuat.set([q.x, q.y, q.z, q.w], i * 4);
    b.timing.set([appear, lift, duration, KIND_CHAFF], i * 4);
    b.scale.set([g.size, seaSize], i * 2);
    stats.chaff++;
  }

  b.memberLinks = b.memberLinks.subarray(0, linkIdx * 6);
  stats.sources = n;
  return b;
}

export function emptyStats(): MappingStats {
  return {
    sources: 0,
    members: 0,
    chaff: 0,
    stays: 0,
    identityMapped: 0,
    searchMapped: 0,
    fallbackClones: 0,
  };
}
