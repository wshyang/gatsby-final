import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { CameraRig } from "./CameraRig";
import { City } from "./City";
import {
  FORMATION,
  PAGE_TEXTS,
  PALETTE,
  SHEET_TEXT,
  TIMELINE,
  TYPE,
  TYPED_LINE,
  WORLD,
} from "./config";
import { Desk } from "./Desk";
import { ASCII_PRINTABLE, GlyphAtlas, waitForFont } from "./GlyphAtlas";
import { GlyphParticles } from "./GlyphParticles";
import {
  assignSlots,
  buildParticleBuffers,
  emptyStats,
  MappingStats,
  ParticleBuffers,
} from "./Mapping";
import { createFlatPages, PaperSurface, PlatenSheet } from "./PaperSurface";
import { PostFX } from "./PostFX";
import {
  layoutFormation,
  layoutOnSurface,
  SourceGlyph,
  TargetSlot,
  wrapParagraphs,
} from "./TextLayout";
import { makePaperTexture } from "./textures";
import { Typewriter } from "./Typewriter";

/**
 * GatsbyScene
 * -----------
 * Builds the 3D world and drives every subsystem from a single deterministic clock `time`.
 *
 *   build:  8 paper surfaces -> text layout (SourceGlyph) -> quote layout (TargetSlot)
 *           -> assignment -> GPU instanced buffers -> single draw call
 *   frame:  t -> camera rig, fog/reveal/blur-to-focus ramps, live typing, shader uniforms
 */

export interface SceneStats extends MappingStats {
  slots: number;
  pages: number;
  fontUsed: string;
}

export interface LiveParticleCounts {
  onPaper: number;
  inFlight: number;
  settled: number;
}

export interface SceneCallbacks {
  onTime?: (t: number, counts: LiveParticleCounts) => void;
  onReady?: (stats: SceneStats) => void;
}

export const PHASES: { from: number; name: string; blurb: string }[] = [
  {
    from: 0,
    name: "I. The Source",
    blurb:
      "Close-up on the Underwood platen & uncorrupted radial key strikers typing the final line onto the sheet.",
  },
  {
    from: TIMELINE.memberLiftStart,
    name: "II. Slow Peel & Lift-Off",
    blurb:
      "Camera slowly dollies back over 8 manuscript pages as 100% of the printed characters gently uncurl off the paper.",
  },
  {
    from: 9.8,
    name: "III. Sea of Alphabets",
    blurb:
      "Thousands of paper-originated letters swirl around the rising camera while the Manhattan skyline blurs into view.",
  },
  {
    from: TIMELINE.firstArrival,
    name: "IV. Coalescence",
    blurb:
      "The city racks into sharp focus as tumbling characters magnetically snap into the 4-line floating quote.",
  },
  {
    from: FORMATION[FORMATION.length - 1].arrival + 1.4,
    name: "V. Hold Over Manhattan",
    blurb:
      "The assembled quote hangs in 3D space against the 1920s New York skyline with gentle camera parallax.",
  },
  {
    from: TIMELINE.dissolve[0],
    name: "VI. Dissolve",
    blurb: "Letters release from the formation and drift outward into the night snow.",
  },
];

export function phaseAt(t: number) {
  let p = PHASES[0];
  for (const ph of PHASES) if (t >= ph.from) p = ph;
  return p;
}

const smooth = (a: number, b: number, x: number) => {
  const s = THREE.MathUtils.clamp((x - a) / (b - a), 0, 1);
  return s * s * (3 - 2 * s);
};

export class GatsbyScene {
  readonly renderer: THREE.WebGLRenderer;
  readonly scene = new THREE.Scene();
  readonly camera: THREE.PerspectiveCamera;
  readonly rig = new CameraRig();

  time = 0;
  playing = true;
  speed = 1;
  loop = true;

  private desk!: Desk;
  private typewriter!: Typewriter;
  private surfaces: PaperSurface[] = [];
  private particles!: GlyphParticles;
  private buffers!: ParticleBuffers;
  private city!: City;
  private post!: PostFX;
  private typingEvents: { time: number; char: string }[] = [];
  private raf = 0;
  private lastStamp = 0;
  private lastReported = -1;
  private ready = false;
  private disposed = false;
  private readonly sample = CameraRig.newSample();
  private readonly fogColor = new THREE.Color();
  private readonly deskFog = new THREE.Color(PALETTE.deskFog);
  private readonly cityFog = new THREE.Color(PALETTE.cityFog);
  private readonly callbacks: SceneCallbacks;
  private readonly canvas: HTMLCanvasElement;

  constructor(canvas: HTMLCanvasElement, callbacks: SceneCallbacks = {}) {
    this.canvas = canvas;
    this.callbacks = callbacks;
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      powerPreference: "high-performance",
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.06;
    this.camera = new THREE.PerspectiveCamera(38, 1, 0.015, 1200);
    (window as unknown as { __gatsby?: GatsbyScene }).__gatsby = this;
  }

  /* ------------------------------------------------------------------ */
  /*  Build                                                             */
  /* ------------------------------------------------------------------ */
  async init() {
    const fontOk = await waitForFont("Special Elite");
    if (this.disposed) return;

    // 1. Glyph Atlases
    const typeAtlas = new GlyphAtlas({
      chars: ASCII_PRINTABLE,
      cell: 128,
      cols: 16,
      family: `"Special Elite", "Courier Prime", "Courier New", Courier, monospace`,
      emScale: 1 / TYPE.quadScale,
      baselineShift: 0.22,
      distress: true,
      seed: 7,
    });
    const legendAtlas = new GlyphAtlas({
      chars: "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890,.?;:'\"-!",
      cell: 64,
      cols: 8,
      family: `Georgia, "Times New Roman", serif`,
      emScale: 0.62,
      baselineShift: 0.34,
      distress: false,
    });

    // 2. Environment reflections for chrome & glass keys
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    this.scene.environmentIntensity = 0.16;
    pmrem.dispose();

    // 3. Desk + Photorealistic 3D Typewriter
    this.desk = new Desk();
    this.scene.add(this.desk.group);
    this.typewriter = new Typewriter(legendAtlas, null);
    this.typewriter.group.position.set(0, 0, -0.22);
    this.typewriter.group.updateMatrixWorld(true);
    this.desk.group.add(this.typewriter.group);

    // 4. Physical Paper Surfaces (7 desk manuscript pages + 1 curved platen sheet)
    let surfaceId = 0;
    const pages = createFlatPages(surfaceId);
    surfaceId += pages.length;
    for (const p of pages) this.desk.group.add(p.mesh);

    const sheetLines = [...wrapParagraphs(SHEET_TEXT), "", TYPED_LINE];
    const typedLineIndex = sheetLines.length - 1;
    const sheet = new PlatenSheet(
      surfaceId++,
      this.typewriter.group.matrixWorld,
      sheetLines.length,
      makePaperTexture({ seed: 500, age: 0.28 }),
    );
    this.typewriter.attachSheet(sheet.mesh);
    this.surfaces = [...pages, sheet];

    // 5. Text layout: every character pinned to a real paper coordinate (u, v)
    let glyphId = 0;
    const nextId = () => glyphId++;
    const sources: SourceGlyph[] = [];
    pages.forEach((page, i) => {
      sources.push(
        ...layoutOnSurface(
          page,
          wrapParagraphs(PAGE_TEXTS[i % PAGE_TEXTS.length]),
          nextId,
          { seed: 31 + i },
        ),
      );
    });
    const sheetGlyphs = layoutOnSurface(sheet, sheetLines, nextId, {
      typedLines: new Set([typedLineIndex]),
      typingStart: TIMELINE.typingStart,
      typingInterval: TIMELINE.typingInterval,
      seed: 99,
    });
    sources.push(...sheetGlyphs);
    const typedGlyphs = sheetGlyphs.filter((g) => g.line === typedLineIndex);
    this.typingEvents = Array.from(TYPED_LINE).map((char, i) => ({
      char,
      time: TIMELINE.typingStart + i * TIMELINE.typingInterval,
    }));

    // 6. Quote formation layout in the settled camera's 3D frame
    const holdFrame = this.rig.sample(TIMELINE.firstArrival + 2.2);
    let slotId = 0;
    const slots: TargetSlot[] = layoutFormation(
      FORMATION,
      holdFrame,
      WORLD.formationDistance,
      () => slotId++,
    );

    // 7. Data Mapping + GPU Instanced Buffers (100% of page glyphs lift off!)
    const stats = emptyStats();
    const assignments = assignSlots(sources, slots, typedGlyphs, stats);
    this.buffers = buildParticleBuffers(
      sources,
      assignments,
      typeAtlas,
      (t, out) => this.rig.frameAt(t, out),
      stats,
    );
    this.particles = new GlyphParticles(this.buffers, typeAtlas);
    this.scene.add(this.particles.mesh, this.particles.links);

    // 8. Hybrid 3D + Blur-to-Focus Manhattan Cityscape & Filmic PostFX
    this.city = new City();
    this.scene.add(this.city.group);
    const { width, height } = this.size();
    this.post = new PostFX(this.renderer, this.scene, this.camera, width, height);

    this.ready = true;
    this.resize();
    this.callbacks.onReady?.({
      ...stats,
      slots: slots.length,
      pages: this.surfaces.length,
      fontUsed: fontOk ? "Special Elite" : "Courier (fallback)",
    });
    this.start();
  }

  /* ------------------------------------------------------------------ */
  /*  Per-frame state application                                       */
  /* ------------------------------------------------------------------ */
  setTime(t: number) {
    this.time = THREE.MathUtils.clamp(t, 0, TIMELINE.duration);
    this.apply(this.time);
  }

  /** Compute live particle state counts at time `t` from the GPU timing buffer. */
  liveCountsAt(t: number): LiveParticleCounts {
    if (!this.buffers) return { onPaper: 0, inFlight: 0, settled: 0 };
    const timing = this.buffers.timing;
    const n = this.buffers.count;
    let onPaper = 0;
    let inFlight = 0;
    let settled = 0;
    for (let i = 0; i < n; i++) {
      const idx = i * 4;
      const appear = timing[idx];
      if (appear >= 0 && t < appear) continue;
      const lift = timing[idx + 1];
      const dur = timing[idx + 2];
      const kind = timing[idx + 3];
      if (t <= lift) {
        onPaper++;
      } else if (kind > 0.5 && t >= lift + dur) {
        settled++;
      } else {
        inFlight++;
      }
    }
    return { onPaper, inFlight, settled };
  }

  private apply(t: number) {
    if (!this.ready) return;

    // 1. Camera rig
    const cam = this.rig.sample(t, this.sample);
    this.camera.position.copy(cam.position);
    this.camera.quaternion.copy(cam.quaternion);
    if (Math.abs(this.camera.fov - cam.fov) > 1e-3) {
      this.camera.fov = cam.fov;
      this.camera.updateProjectionMatrix();
    }

    // 2. Atmosphere, fog, and city blur-to-focus ramps
    const reveal = smooth(TIMELINE.cityReveal[0], TIMELINE.cityReveal[1], t);
    const cityBlur = 1 - smooth(TIMELINE.cityFocus[0], TIMELINE.cityFocus[1], t);
    const fogDensity = Math.exp(
      THREE.MathUtils.lerp(Math.log(0.65), Math.log(0.0085), reveal),
    );
    this.fogColor.copy(this.deskFog).lerp(this.cityFog, reveal);
    const deskFade = 1 - smooth(TIMELINE.deskFade[0], TIMELINE.deskFade[1], t);
    const dissolve = smooth(TIMELINE.dissolve[0], TIMELINE.dissolve[1], t);
    const fade =
      smooth(TIMELINE.fadeIn[0], TIMELINE.fadeIn[1], t) *
      (1 - smooth(TIMELINE.fadeOut[0], TIMELINE.fadeOut[1], t));

    // 3. Live typing & uncorrupted type-bar striker animation
    const carriageX = this.carriageXAt(t);
    this.typewriter.setCarriageX(carriageX);
    let active: { time: number; char: string } | null = null;
    for (const ev of this.typingEvents) {
      if (t >= ev.time && t - ev.time < 0.088) active = ev;
    }
    this.typewriter.strike(
      active ? active.char : null,
      active ? (t - active.time) / 0.088 : 0,
    );

    // 4. Desk & paper surface dissolve as camera ascends into the night sky
    this.desk.setOpacity(deskFade);
    this.typewriter.setOpacity(deskFade);
    for (const s of this.surfaces) {
      const m = s.mesh.material as THREE.MeshStandardMaterial;
      const transparent = deskFade < 0.999;
      if (m.transparent !== transparent) {
        m.transparent = transparent;
        m.needsUpdate = true;
      }
      m.opacity = deskFade;
    }

    // 5. Shader uniforms
    const { height } = this.size();
    const dpr = this.renderer.getPixelRatio();
    const fovRad = THREE.MathUtils.degToRad(this.camera.fov);
    const pixelsPerUnit = (height * dpr) / (2 * Math.tan(fovRad / 2));

    this.particles.update({
      time: t,
      carriageX,
      focusDist: cam.focusDist,
      focusRange: cam.focusRange,
      deskFade,
      dissolve,
      fogDensity,
      fogColor: this.fogColor,
      opacity: 1,
      pixelsPerUnit,
    });

    this.city.update({
      time: t,
      cameraPos: this.camera.position,
      fogColor: this.fogColor,
      fogDensity,
      reveal,
      cityBlur,
    });

    this.renderer.setClearColor(this.fogColor, 1);
    this.post.update(t, fade);
  }

  /** Carriage X offset so the active column sits directly under the type guide. */
  private carriageXAt(t: number): number {
    const xOf = (col: number) =>
      -(TYPE.marginLeft + (col + 0.5) * TYPE.cellWidth - TYPE.pageWidth / 2);
    let k = -1;
    for (let i = 0; i < this.typingEvents.length; i++) {
      if (this.typingEvents[i].time <= t) k = i;
    }
    if (k < 0) return xOf(0);
    const since = t - this.typingEvents[k].time;
    const step = smooth(0.012, 0.06, since);
    return THREE.MathUtils.lerp(xOf(k), xOf(k + 1), step);
  }

  /* ------------------------------------------------------------------ */
  /*  Animation loop & lifecycle                                        */
  /* ------------------------------------------------------------------ */
  start() {
    cancelAnimationFrame(this.raf);
    this.lastStamp = performance.now();
    const tick = (now: number) => {
      if (this.disposed) return;
      this.raf = requestAnimationFrame(tick);
      const dt = Math.min(0.1, (now - this.lastStamp) / 1000);
      this.lastStamp = now;
      if (this.playing) {
        this.time += dt * this.speed;
        if (this.time >= TIMELINE.duration) {
          this.time = this.loop ? 0 : TIMELINE.duration;
        }
      }
      this.apply(this.time);
      this.post.render();
      if (Math.abs(this.time - this.lastReported) > 0.08) {
        this.lastReported = this.time;
        this.callbacks.onTime?.(this.time, this.liveCountsAt(this.time));
      }
    };
    this.raf = requestAnimationFrame(tick);
  }

  setShowMapping(show: boolean) {
    if (this.particles) this.particles.links.visible = show;
  }

  private size() {
    const parent = this.canvas.parentElement;
    return {
      width: parent?.clientWidth || window.innerWidth,
      height: parent?.clientHeight || window.innerHeight,
    };
  }

  resize() {
    const { width, height } = this.size();
    this.renderer.setSize(width, height, false);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.post?.setSize(width, height, this.renderer.getPixelRatio());
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.particles?.dispose();
    this.post?.dispose();
    this.scene.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (mesh.geometry) mesh.geometry.dispose();
      const mat = mesh.material as THREE.Material | THREE.Material[] | undefined;
      if (Array.isArray(mat)) mat.forEach((m) => m.dispose());
      else mat?.dispose();
    });
    this.renderer.dispose();
  }
}
