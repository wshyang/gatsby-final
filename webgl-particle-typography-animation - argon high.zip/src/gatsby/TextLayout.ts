import * as THREE from "three";
import { FormationLine, TYPE } from "./config";
import { mulberry32, normalizeChar } from "./GlyphAtlas";
import { newPose, PaperSurface } from "./PaperSurface";

/* ------------------------------------------------------------------ */
/*  Data model                                                         */
/* ------------------------------------------------------------------ */

/**
 * A glyph as it physically exists on a sheet of paper.
 * `position` and `quaternion` are computed from `surface.poseAt(u, v)` so
 * every character starts at an exact coordinate on a rendered paper mesh.
 */
export interface SourceGlyph {
  id: number;
  char: string;
  surfaceId: number;
  line: number;
  col: number;
  /** Normalized paper coordinates in [0, 1]. */
  u: number;
  v: number;
  position: THREE.Vector3;
  quaternion: THREE.Quaternion;
  /** Quad side length in world units on the paper. */
  size: number;
  /** Second at which the typewriter strikes this character (-1 = already printed). */
  typedAt: number;
  /** Rides on the typewriter carriage (needs live carriage X offset). */
  onCarriage: boolean;
}

/** One character cell in the floating 3D quote formation. */
export interface TargetSlot {
  id: number;
  char: string;
  line: number;
  word: number;
  /** Index of this character within its word. */
  charInWord: number;
  position: THREE.Vector3;
  quaternion: THREE.Quaternion;
  size: number;
  /** Second at which the glyph locks into place in the quote. */
  arrival: number;
  source: FormationLine["source"];
}

/* ------------------------------------------------------------------ */
/*  Manuscript paragraph wrapping                                      */
/* ------------------------------------------------------------------ */

/** Greedy word wrap with a 5-space paragraph indent and blank line separator. */
export function wrapParagraphs(paragraphs: string[], columns = TYPE.columns): string[] {
  const lines: string[] = [];
  for (const para of paragraphs) {
    let line = "     ";
    for (const word of para.split(/\s+/)) {
      if (line.trim().length === 0) {
        line += word;
      } else if (line.length + 1 + word.length <= columns) {
        line += " " + word;
      } else {
        lines.push(line);
        line = word;
      }
    }
    if (line.trim().length) lines.push(line);
    lines.push("");
  }
  if (lines[lines.length - 1] === "") lines.pop();
  return lines;
}

/* ------------------------------------------------------------------ */
/*  Layout onto a physical paper surface                               */
/* ------------------------------------------------------------------ */

export interface LayoutOptions {
  typingStart?: number;
  typingInterval?: number;
  typedLines?: Set<number>;
  seed?: number;
}

const _q = new THREE.Quaternion();
const _axisZ = new THREE.Vector3(0, 0, 1);
const _up = new THREE.Vector3();

/**
 * Place monospace lines on a `PaperSurface` at 10 cpi / 6 lpi.
 * Returns one `SourceGlyph` per non-space character.
 */
export function layoutOnSurface(
  surface: PaperSurface,
  lines: string[],
  nextId: () => number,
  opts: LayoutOptions = {},
): SourceGlyph[] {
  const out: SourceGlyph[] = [];
  const rnd = mulberry32(opts.seed ?? surface.id * 7919 + 13);
  const pose = newPose();
  const size = TYPE.lineHeight * TYPE.quadScale;
  let strike = 0;

  lines.forEach((text, line) => {
    const typed = opts.typedLines?.has(line) ?? false;
    for (let col = 0; col < text.length && col < TYPE.columns; col++) {
      const raw = text[col];
      if (raw === " ") {
        if (typed) strike++;
        continue;
      }
      const char = normalizeChar(raw);
      const u = (TYPE.marginLeft + (col + 0.5) * TYPE.cellWidth) / surface.width;
      const v = (TYPE.marginTop + (line + 0.5) * TYPE.lineHeight) / surface.height;
      surface.poseAt(u, v, pose);

      // Subtle mechanical typewriter baseline jitter & micro-tilt
      const wobble = (rnd() - 0.5) * 0.11 * TYPE.lineHeight;
      _up.set(0, 1, 0).applyQuaternion(pose.quaternion);
      const position = pose.position.clone().addScaledVector(_up, wobble);
      const quaternion = pose.quaternion
        .clone()
        .multiply(_q.setFromAxisAngle(_axisZ, (rnd() - 0.5) * 0.036));

      const typedAt = typed
        ? (opts.typingStart ?? 0) + strike * (opts.typingInterval ?? 0.082)
        : -1;
      if (typed) strike++;

      out.push({
        id: nextId(),
        char,
        surfaceId: surface.id,
        line,
        col,
        u,
        v,
        position,
        quaternion,
        size,
        typedAt,
        onCarriage: surface.onCarriage,
      });
    }
  });
  return out;
}

/* ------------------------------------------------------------------ */
/*  Floating quote formation in 3D space                               */
/* ------------------------------------------------------------------ */

export interface CameraFrame {
  position: THREE.Vector3;
  quaternion: THREE.Quaternion;
}

/**
 * Lay out the multi-line floating quote in the settled camera's 3D reference
 * frame so the words hang legibly over the Manhattan skyline with subtle
 * per-word depth parallax.
 */
export function layoutFormation(
  lines: FormationLine[],
  camera: CameraFrame,
  distance: number,
  nextId: () => number,
): TargetSlot[] {
  const right = new THREE.Vector3(1, 0, 0).applyQuaternion(camera.quaternion);
  const up = new THREE.Vector3(0, 1, 0).applyQuaternion(camera.quaternion);
  const forward = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion);
  const centre = camera.position.clone().addScaledVector(forward, distance);

  const facing = new THREE.Quaternion().setFromRotationMatrix(
    new THREE.Matrix4().makeBasis(right, up, forward.clone().negate()),
  );
  const rnd = mulberry32(4242);
  const slots: TargetSlot[] = [];

  lines.forEach((line, li) => {
    const advance = (0.59 / TYPE.quadScale) * line.size;
    const width = line.text.length * advance;
    let word = 0;
    let charInWord = 0;
    let wordDepth = (rnd() - 0.5) * 0.22;
    let wordLift = (rnd() - 0.5) * 0.06 * line.size;

    for (let col = 0; col < line.text.length; col++) {
      const ch = line.text[col];
      if (ch === " ") {
        word++;
        charInWord = 0;
        wordDepth = (rnd() - 0.5) * 0.22;
        wordLift = (rnd() - 0.5) * 0.06 * line.size;
        continue;
      }
      const x = -width / 2 + (col + 0.5) * advance + line.offset[0];
      const y = line.offset[1] + wordLift;
      const z = line.offset[2] + wordDepth;
      const position = centre
        .clone()
        .addScaledVector(right, x)
        .addScaledVector(up, y)
        .addScaledVector(forward, -z);
      const quaternion = facing
        .clone()
        .multiply(_q.setFromAxisAngle(_axisZ, (rnd() - 0.5) * 0.025));

      slots.push({
        id: nextId(),
        char: normalizeChar(ch),
        line: li,
        word,
        charInWord,
        position,
        quaternion,
        size: line.size,
        arrival: line.arrival + word * line.wordStagger + charInWord * 0.045,
        source: line.source,
      });
      charInWord++;
    }
  });
  return slots;
}
