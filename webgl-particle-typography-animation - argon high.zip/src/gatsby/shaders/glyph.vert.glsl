// ---------------------------------------------------------------------------
//  Glyph particle – vertex stage
//
//  One instance = one typewritten character. Every instance starts *exactly*
//  on its physical paper surface (`aOrigin` / `aOriginQuat`, derived from
//  `PaperSurface.poseAt(u, v)`) and travels along a two-stage trajectory:
//    Stage 1: Slow, tactile peel & flutter just above the paper surface normal
//    Stage 2: Wide 3D arc through a swirling sea of alphabets into `aTarget`
// ---------------------------------------------------------------------------

attribute vec3  aOrigin;      // rest position on the paper mesh (world)
attribute vec4  aOriginQuat;  // rest orientation (+X reading dir, +Y up page, +Z paper normal)
attribute vec3  aTarget;      // destination (quote slot or sea-of-letters point)
attribute vec4  aTargetQuat;  // destination orientation
attribute vec2  aGlyph;       // atlas cell UV origin
attribute vec4  aTiming;      // (appear, lift, duration, kind)  kind: 0 chaff, 1 member
attribute vec4  aSeed;        // per-particle deterministic random numbers
attribute vec2  aScale;       // (size on paper, size in air / quote)
attribute float aCarriage;    // 1 -> rides on the typewriter carriage while typing

uniform float uTime;
uniform float uCarriageX;
uniform float uFocusDist;     // per-glyph depth-of-field focus distance
uniform float uFocusRange;
uniform float uDeskFade;      // 1 = desk visible, 0 = dissolved
uniform float uDissolve;      // 0 .. 1 at the end of the loop
uniform float uFogDensity;
uniform vec2  uCellSize;
uniform float uPixelsPerUnit; // viewport height (px) / (2 * tan(fov/2))
uniform float uCellPx;        // atlas cell size in texels

varying vec2  vUv;
varying vec2  vLocal;         // 0..1 inside the quad
varying float vAlpha;
varying float vDefocus;
varying float vBias;          // mip bias used for optical bokeh blur
varying float vLit;           // 0 = dark ribbon ink on paper .. 1 = warm luminous airborne glyph
varying float vFog;

const float PI = 3.141592653589793;

/* ---- quaternion math --------------------------------------------------- */
vec3 qrot(vec4 q, vec3 v) {
  return v + 2.0 * cross(q.xyz, cross(q.xyz, v) + q.w * v);
}
vec4 qmul(vec4 a, vec4 b) {
  return vec4(a.w * b.xyz + b.w * a.xyz + cross(a.xyz, b.xyz), a.w * b.w - dot(a.xyz, b.xyz));
}
vec4 qaxis(vec3 axis, float ang) {
  float h = ang * 0.5;
  return vec4(normalize(axis) * sin(h), cos(h));
}
vec4 qnlerp(vec4 a, vec4 b, float t) {
  if (dot(a, b) < 0.0) b = -b;
  return normalize(mix(a, b, t));
}

/* ---- custom cinematic easing curves ------------------------------------ */
// Slow, weighted lift-off start -> brisk mid-air stream -> deliberate magnetic settle
float easeLiftAndSnap(float x) {
  if (x < 0.45) {
    float u = x / 0.45;
    return 0.32 * u * u * u;
  } else {
    float u = (x - 0.45) / 0.55;
    return 0.32 + 0.68 * (1.0 - pow(1.0 - u, 3.2));
  }
}

float easeChaffDrift(float x) {
  // Very gentle peel off the page, then smooth continuous rise through the sea of letters
  return pow(x, 2.15) * (2.15 - 1.15 * x);
}

float smooth01(float x) {
  return x * x * (3.0 - 2.0 * x);
}

vec3 bezier(vec3 p0, vec3 p1, vec3 p2, vec3 p3, float t) {
  float u = 1.0 - t;
  return u * u * u * p0 + 3.0 * u * u * t * p1 + 3.0 * u * t * t * p2 + t * t * t * p3;
}

void main() {
  float t      = uTime;
  float appear = aTiming.x;
  float lift   = aTiming.y;
  float dur    = aTiming.z;
  float kind   = aTiming.w;
  bool  member = kind > 0.5;
  bool  chaff  = kind > -0.5 && kind < 0.5;

  // Glyphs typed live on the platen only appear once struck by the type bar
  float visible = appear < 0.0 ? 1.0 : step(appear, t);

  // Carriage-bound glyphs slide left with the platen while the line is typed
  vec3 origin = aOrigin + vec3(uCarriageX * aCarriage, 0.0, 0.0);

  // Normalized flight progress 0 -> 1
  float rawT = max(0.0, (t - lift) / dur);
  float p = clamp(rawT, 0.0, 1.0);
  float e = member ? easeLiftAndSnap(p) : easeChaffDrift(p);

  /* ---- 1. Two-stage trajectory (slow paper peel -> 3D sea -> target) ---- */
  vec3 n    = qrot(aOriginQuat, vec3(0.0, 0.0, 1.0));   // local paper surface normal
  vec3 up   = vec3(0.0, 1.0, 0.0);
  vec3 span = aTarget - origin;
  float dist = max(length(span), 1e-4);
  vec3 dir  = span / dist;
  vec3 side1 = normalize(cross(dir, abs(dir.y) > 0.9 ? vec3(1.0, 0.0, 0.0) : up));
  vec3 side2 = cross(dir, side1);

  // Control point 1 stays close to the paper surface so the initial lift-off
  // peels gently upward along the page normal without yanking the character away
  vec3 c1 = origin
          + n  * (0.045 + 0.095 * aSeed.x)
          + up * (0.06  + 0.14  * aSeed.y);

  // Control point 2 sweeps through a wide atmospheric arc in the mid-air stream
  float arc = dist * (0.16 + 0.22 * aSeed.z);
  vec3 c2 = mix(origin, aTarget, 0.58)
          + side1 * (aSeed.y - 0.5) * 1.85 * arc
          + up    * (0.35 + 0.35 * aSeed.w) * arc;

  vec3 pos = bezier(origin, c1, c2, aTarget, e);

  // Delicate paper-surface uncurling flutter during the initial peel
  float peelFlutter = smoothstep(0.0, 0.14, p) * (1.0 - smoothstep(0.14, 0.48, p));
  pos += (n * (0.018 + 0.032 * aSeed.x) + side1 * sin(t * 2.8 + aSeed.y * 12.0) * 0.016) * peelFlutter;

  // 3D curl & vortex swirl while suspended in the sea of alphabets
  // (decays cleanly to zero at both ends for quote members; lingers for chaff)
  float air = member ? pow(sin(p * PI), 1.15) : sin(min(p, 0.88) * PI);
  float phase = t * (0.78 + 0.55 * aSeed.x) + aSeed.w * 6.2831853;
  float swirlR = (0.035 + 0.085 * aSeed.z) * min(dist, 4.2) * air * smoothstep(0.06, 0.32, p);
  pos += (side1 * sin(phase) + side2 * cos(phase * 0.85)) * swirlR;
  pos += up * sin(t * 0.72 + aSeed.y * 9.0) * 0.065 * air * smoothstep(0.05, 0.3, p);

  // Keep chaff gently drifting in the night air even after reaching their target zone
  if (chaff && rawT > 1.0) {
    float extra = rawT - 1.0;
    pos += vec3(
      sin(t * 0.45 + aSeed.x * 15.0) * 0.18,
      extra * 0.22 + cos(t * 0.38 + aSeed.y * 11.0) * 0.12,
      sin(t * 0.32 + aSeed.z * 19.0) * 0.18
    ) * min(extra, 1.5);
  }

  // Settled quote letters breathe subtly together in the night breeze
  float settled = member ? step(0.999, p) : 0.0;
  pos += vec3(
    cos(t * 0.55 + aTarget.x * 0.7) * 0.008 * aScale.y,
    sin(t * 0.75 + aTarget.x * 0.9 + aTarget.y * 1.2) * 0.018 * aScale.y,
    0.0
  ) * settled;

  // End-of-loop dissolve: quote and remaining sea drift outward into the night snow
  vec3 away = qrot(aTargetQuat, vec3(0.0, 0.0, -1.0));
  float dis = uDissolve * uDissolve;
  pos += (away * 1.1 + up * 0.55 + side1 * (aSeed.x - 0.5) * 1.1) * dis * (0.6 + aSeed.w);

  /* ---- 2. Orientation & 3D tumbling ------------------------------------ */
  vec4 q = qnlerp(aOriginQuat, aTargetQuat, e);
  // Whole-integer number of tumbles so quote letters land strictly flat in their slot
  float turns = member ? floor(1.0 + aSeed.w * 2.0) : floor(1.0 + aSeed.w * 3.0);
  vec3 axis = normalize(vec3(aSeed.x - 0.5, aSeed.y - 0.5, aSeed.z - 0.5) + vec3(0.001));
  float tumbleProg = member ? smooth01(p) : smooth01(min(rawT, 1.35) / 1.35);
  q = qmul(q, qaxis(axis, tumbleProg * turns * 2.0 * PI));
  q = qmul(q, qaxis(vec3(0.0, 1.0, 0.0), dis * 2.2 * (aSeed.z - 0.5)));

  /* ---- 3. Scale & world vertex ----------------------------------------- */
  // Delay scale expansion slightly so letters stay paper-sized while peeling off the sheet
  float scaleE = pow(e, 1.32);
  float sc = mix(aScale.x, aScale.y, scaleE);
  vec3 local = vec3(position.xy * sc, 0.0);
  // Sit 0.35mm above the paper mesh at rest so ink never z-fights with the sheet
  vec3 world = pos + qrot(q, local) + n * 0.00038 * (1.0 - smoothstep(0.0, 0.08, p));

  /* ---- 4. Visibility & optical depth of field -------------------------- */
  float onPaper = 1.0 - step(0.0001, p);
  float alpha = visible;
  alpha *= mix(1.0, uDeskFade, onPaper);
  if (chaff) {
    // Keep the sea of alphabets lush and visible much longer (`rawT` up to 1.35)
    alpha *= (1.0 - smoothstep(0.78, 1.35, rawT)) * 0.88;
  }
  alpha *= mix(0.86 + 0.14 * aSeed.z, 1.0, e);
  alpha *= 1.0 - uDissolve;

  vec4 mv = modelViewMatrix * vec4(world, 1.0);
  float depth = -mv.z;
  float defocus = abs(depth - uFocusDist) / max(uFocusRange, 1e-3);
  float quadPx = sc * uPixelsPerUnit / max(depth, 1e-3);
  float baseLod = log2(uCellPx / max(quadPx, 1.0));
  vBias = clamp(min(defocus * 1.9, 3.3 - baseLod), 0.0, 2.9);
  vDefocus = defocus;
  vFog = 1.0 - exp(-pow(depth * uFogDensity, 2.0));
  vLit = smoothstep(0.04, 0.48, p) * (member ? 1.0 : 0.84);
  vAlpha = alpha;
  vLocal = uv;
  vUv = aGlyph + uv * uCellSize;

  gl_Position = projectionMatrix * mv;
}
