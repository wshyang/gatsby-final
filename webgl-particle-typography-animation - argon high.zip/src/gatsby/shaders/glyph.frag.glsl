// ---------------------------------------------------------------------------
//  Glyph particle – fragment stage
//  Samples the mipmapped typewriter atlas; per-particle defocus is rendered
//  via mip bias + soft edge feathering + optical bokeh roll-off.
// ---------------------------------------------------------------------------
uniform sampler2D uAtlas;
uniform vec3  uInk;
uniform vec3  uCream;
uniform vec3  uFogColor;
uniform float uOpacity;

varying vec2  vUv;
varying vec2  vLocal;
varying float vAlpha;
varying float vDefocus;
varying float vBias;
varying float vLit;
varying float vFog;

void main() {
  float ink = texture2D(uAtlas, vUv, vBias).a;
  // Feather quad borders on heavily defocused bokeh letters so no hard square edge shows
  float border = max(abs(vLocal.x - 0.5), abs(vLocal.y - 0.5));
  float feather = smoothstep(0.5, 0.35, border);
  ink *= mix(1.0, feather, clamp(vBias / 2.4, 0.0, 1.0));

  float soft = 1.0 / (1.0 + vDefocus * 0.82);
  float a = ink * vAlpha * soft * uOpacity;
  if (a < 0.004) discard;

  // Dark ribbon ink on the manuscript page -> warm luminous ivory/gold once airborne
  vec3 airborneCol = uCream * (1.0 + 0.42 * vLit);
  vec3 col = mix(uInk, airborneCol, vLit);
  col = mix(col, uFogColor, vFog * (1.0 - 0.38 * vLit));

  gl_FragColor = vec4(col, a);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}
