import * as THREE from "three";

/**
 * GlyphAtlas
 * ----------
 * Packs printable ASCII characters into a mipmapped 2D texture atlas.
 * Used both for the distressed typewriter ribbon glyphs on the paper / in flight
 * and for the serif legends on the glass typewriter keys.
 */

export const ASCII_PRINTABLE = (() => {
  let s = "";
  for (let c = 33; c <= 126; c++) s += String.fromCharCode(c);
  return s;
})();

/** Deterministic 32-bit PRNG (Mulberry32). */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Normalise smart quotes / dashes to printable ASCII. */
export function normalizeChar(ch: string): string {
  if (ch === "\u2018" || ch === "\u2019") return "'";
  if (ch === "\u201c" || ch === "\u201d") return '"';
  if (ch === "\u2013" || ch === "\u2014") return "-";
  return ch;
}

export async function waitForFont(family: string, timeoutMs = 2600): Promise<boolean> {
  if (typeof document === "undefined" || !("fonts" in document)) return false;
  try {
    await Promise.race([
      Promise.all([
        document.fonts.load(`64px "${family}"`),
        document.fonts.ready,
      ]),
      new Promise((resolve) => setTimeout(resolve, timeoutMs)),
    ]);
    return document.fonts.check(`64px "${family}"`);
  } catch {
    return false;
  }
}

export interface AtlasOptions {
  chars: string;
  cell: number;
  cols: number;
  family: string;
  /** Font size as fraction of `cell`. */
  emScale?: number;
  /** Baseline offset from bottom of cell as fraction of `cell`. */
  baselineShift?: number;
  /** Add subtle ribbon weave / ink distress. */
  distress?: boolean;
  seed?: number;
}

export class GlyphAtlas {
  readonly texture: THREE.CanvasTexture;
  readonly cellSize: THREE.Vector2;
  readonly cellPx: number;
  private readonly map = new Map<string, [number, number]>();
  private readonly fallback: [number, number];

  constructor(opts: AtlasOptions) {
    const {
      chars,
      cell,
      cols,
      family,
      emScale = 0.78,
      baselineShift = 0.22,
      distress = false,
      seed = 1,
    } = opts;

    const rows = Math.ceil(chars.length / cols);
    const width = cols * cell;
    const height = THREE.MathUtils.ceilPowerOfTwo(rows * cell);

    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d")!;
    ctx.clearRect(0, 0, width, height);

    const fontPx = Math.round(cell * emScale);
    ctx.font = `${fontPx}px ${family}`;
    ctx.textAlign = "center";
    ctx.textBaseline = "alphabetic";
    ctx.fillStyle = "#ffffff";

    const rnd = mulberry32(seed);

    for (let i = 0; i < chars.length; i++) {
      const ch = chars[i];
      const col = i % cols;
      const row = Math.floor(i / cols);
      const cx = (col + 0.5) * cell;
      const cy = (row + 1 - baselineShift) * cell;

      if (distress) {
        // Double-strike halo simulating cloth ribbon ink bleed into bond paper fibres
        ctx.save();
        ctx.shadowColor = "rgba(255,255,255,0.42)";
        ctx.shadowBlur = cell * 0.032;
        ctx.fillText(ch, cx, cy);
        ctx.restore();

        // Main sharp typewriter strike
        ctx.fillText(ch, cx, cy);

        // Slight secondary over-strike for authentic mechanical ribbon feel
        ctx.save();
        ctx.globalAlpha = 0.32;
        ctx.fillText(ch, cx + (rnd() - 0.5) * 1.2, cy + (rnd() - 0.5) * 1.2);
        ctx.restore();
      } else {
        ctx.fillText(ch, cx, cy);
      }

      // UV origin at bottom-left of the cell (Canvas Y=0 is top, UV V=1 is top)
      const u = (col * cell) / width;
      const v = 1 - ((row + 1) * cell) / height;
      this.map.set(ch, [u, v]);
    }

    if (distress) {
      // Subtle cloth-ribbon grain across the ink alpha channel
      const img = ctx.getImageData(0, 0, width, height);
      const d = img.data;
      for (let i = 0; i < d.length; i += 4) {
        const a = d[i + 3];
        if (a > 8) {
          const grain = 0.86 + 0.14 * rnd();
          d[i + 3] = Math.min(255, Math.round(a * grain));
        }
      }
      ctx.putImageData(img, 0, 0);
    }

    this.fallback = this.map.get("?") ?? [0, 0];
    this.cellSize = new THREE.Vector2(cell / width, cell / height);
    this.cellPx = cell;

    this.texture = new THREE.CanvasTexture(canvas);
    this.texture.generateMipmaps = true;
    this.texture.minFilter = THREE.LinearMipmapLinearFilter;
    this.texture.magFilter = THREE.LinearFilter;
    this.texture.needsUpdate = true;
  }

  cellOf(ch: string): [number, number] {
    return this.map.get(normalizeChar(ch)) ?? this.fallback;
  }
}
