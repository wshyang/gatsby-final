import * as THREE from "three";
import { WORLD } from "./config";
import { CameraFrame } from "./TextLayout";

/**
 * CameraRig
 * ---------
 * Smooth cinematic camera choreography designed to address `reviews.txt`:
 *  - Slower, weighted zoom-out from the typewriter platen (`t = 5.0s -> 10.2s`)
 *    so the viewer watches characters slowly unstick from both the platen sheet
 *    and all 7 scattered desk pages.
 *  - Continuous, unhurried crane & upward pan (`t = 10.2s -> 17.6s`) within a
 *    cohesive ~4m world height (avoiding the 30m jump in `fable_max`), gliding
 *    through the dense sea of floating alphabets as the city comes into focus.
 *  - Gentle lateral parallax drift (`t = 17.6s -> 28.0s`) while the quote holds.
 */
export type Ease = "linear" | "in" | "out" | "inout" | "soft";

export interface CameraKey {
  t: number;
  pos: [number, number, number];
  look: [number, number, number];
  fov: number;
  /** Explicit focus distance (defaults to |look - pos|). */
  focus?: number;
  /** Relative depth-of-field width (fraction of focus distance). */
  dof?: number;
  ease?: Ease;
}

export interface CameraSample extends CameraFrame {
  fov: number;
  focusDist: number;
  focusRange: number;
  look: THREE.Vector3;
}

function applyEase(s: number, ease: Ease): number {
  switch (ease) {
    case "linear":
      return s;
    case "in":
      return s * s * (2 - s * 0.5) * (s * 0.6667);
    case "out":
      return 1 - Math.pow(1 - s, 2.6);
    case "soft":
      // Quintic C2 smoothstep for ultra-gentle camera starts and stops
      return s * s * s * (s * (s * 6 - 15) + 10);
    default:
      return s * s * (3 - 2 * s);
  }
}

/** Printing point of the typewriter in world space (typewriter sits at z = -0.22). */
const PP_Z = -0.338;

export const CAMERA_KEYS: CameraKey[] = [
  // 1. Intimate close-up on the platen & open type-basket strikers during live typing
  {
    t: 0.0,
    pos: [0.098, 0.258, -0.118],
    look: [-0.01, 0.184, PP_Z],
    fov: 38,
    dof: 0.55,
  },
  {
    t: 4.9,
    pos: [0.068, 0.272, -0.062],
    look: [-0.004, 0.182, PP_Z],
    fov: 38.5,
    dof: 0.55,
    ease: "inout",
  },
  // 2. Slow, deliberate dolly-back over the typewriter and the 7 manuscript pages
  //    as the first wave of letters gently peels off the paper surfaces
  {
    t: 7.8,
    pos: [0.048, 0.42, 0.28],
    look: [0.0, 0.15, -0.16],
    fov: 40,
    dof: 0.62,
    ease: "inout",
  },
  {
    t: 10.6,
    pos: [0.025, 0.64, 0.68],
    look: [0.0, 0.18, -0.12],
    fov: 42,
    dof: 0.65,
    ease: "linear",
  },
  // 3. Gradual crane ascent & smooth upward tilt through the rising sea of alphabets
  {
    t: 13.8,
    pos: [0.008, 1.78, 1.88],
    look: [0.0, 1.32, -2.1],
    fov: 43,
    focus: 2.8,
    dof: 0.48,
    ease: "linear",
  },
  // 4. Camera settles gently over the night skyline as the quote coalesces
  {
    t: 17.6,
    pos: [0.0, 3.8, 3.6],
    look: [0.0, 3.35, -8.0],
    fov: 44,
    focus: WORLD.formationDistance,
    dof: 0.38,
    ease: "out",
  },
  // 5. Slow, atmospheric parallax drift while the quote is read over Manhattan
  {
    t: 28.0,
    pos: [0.68, 3.72, 3.74],
    look: [0.14, 3.36, -8.0],
    fov: 44,
    focus: WORLD.formationDistance,
    dof: 0.38,
    ease: "linear",
  },
];

export class CameraRig {
  private readonly keys: CameraKey[];
  private readonly posSpline: THREE.CatmullRomCurve3;
  private readonly lookSpline: THREE.CatmullRomCurve3;
  private readonly a = new THREE.Vector3();
  private readonly b = new THREE.Vector3();
  private readonly m = new THREE.Matrix4();

  constructor(keys: CameraKey[] = CAMERA_KEYS) {
    this.keys = keys;
    this.posSpline = new THREE.CatmullRomCurve3(
      keys.map((k) => new THREE.Vector3(...k.pos)),
      false,
      "centripetal",
      0.35,
    );
    this.lookSpline = new THREE.CatmullRomCurve3(
      keys.map((k) => new THREE.Vector3(...k.look)),
      false,
      "centripetal",
      0.35,
    );
  }

  /** Sample the camera rig at time `t` (seconds). */
  sample(t: number, out: CameraSample = CameraRig.newSample()): CameraSample {
    const keys = this.keys;
    let i = 0;
    while (i < keys.length - 2 && t >= keys[i + 1].t) i++;
    const k0 = keys[i];
    const k1 = keys[i + 1];
    const raw = THREE.MathUtils.clamp((t - k0.t) / Math.max(1e-6, k1.t - k0.t), 0, 1);
    const s = applyEase(raw, k1.ease ?? "inout");

    // Blend piecewise eased segment with centripetal spline during the crane/pan
    // (segments 1..4) so the zoom-out and pan are completely C1-smooth without jerks
    const splineU = THREE.MathUtils.clamp((i + s) / (keys.length - 1), 0, 1);
    const linPos = this.a.set(...k0.pos).lerp(this.b.set(...k1.pos), s).clone();
    const linLook = this.a.set(...k0.look).lerp(this.b.set(...k1.look), s).clone();

    const spPos = this.posSpline.getPoint(splineU);
    const spLook = this.lookSpline.getPoint(splineU);

    const splineBlend = i >= 1 && i <= 4 ? 0.65 : 0.2;
    out.position.copy(linPos).lerp(spPos, splineBlend);
    out.look.copy(linLook).lerp(spLook, splineBlend);

    out.fov = THREE.MathUtils.lerp(k0.fov, k1.fov, s);
    const f0 = k0.focus ?? this.a.set(...k0.pos).distanceTo(this.b.set(...k0.look));
    const f1 = k1.focus ?? this.a.set(...k1.pos).distanceTo(this.b.set(...k1.look));
    out.focusDist = THREE.MathUtils.lerp(f0, f1, s);
    out.focusRange =
      out.focusDist * THREE.MathUtils.lerp(k0.dof ?? 0.45, k1.dof ?? 0.45, s) + 0.03;

    this.m.lookAt(out.position, out.look, THREE.Object3D.DEFAULT_UP);
    out.quaternion.setFromRotationMatrix(this.m);
    return out;
  }

  /** Helper used while baking chaff trajectories in camera space. */
  frameAt(t: number, out: CameraFrame): CameraFrame {
    const s = this.sample(t);
    out.position.copy(s.position);
    out.quaternion.copy(s.quaternion);
    return out;
  }

  static newSample(): CameraSample {
    return {
      position: new THREE.Vector3(),
      quaternion: new THREE.Quaternion(),
      look: new THREE.Vector3(),
      fov: 40,
      focusDist: 1,
      focusRange: 0.5,
    };
  }
}
