import * as THREE from "three";
import { makeWoodTexture } from "./textures";

/**
 * Desk
 * ----
 * The 1920s walnut study desk and warm tungsten desk lamp that illuminate
 * the typewriter and the 7 scattered manuscript pages during the opening shot.
 */
export class Desk {
  readonly group = new THREE.Group();
  private readonly surfaceMat: THREE.MeshStandardMaterial;
  private readonly keyLight: THREE.SpotLight;
  private readonly fillLight: THREE.PointLight;
  private readonly rimLight: THREE.DirectionalLight;
  private readonly keyIntensity = 4.6;
  private readonly fillIntensity = 0.72;
  private readonly rimIntensity = 0.58;

  constructor() {
    const { map, bump } = makeWoodTexture(21);
    this.surfaceMat = new THREE.MeshStandardMaterial({
      map,
      bumpMap: bump,
      bumpScale: 0.0018,
      roughness: 0.64,
      metalness: 0.06,
    });

    const topGeo = new THREE.PlaneGeometry(3.4, 2.6, 1, 1);
    topGeo.rotateX(-Math.PI / 2);
    const top = new THREE.Mesh(topGeo, this.surfaceMat);
    top.receiveShadow = true;
    this.group.add(top);

    // Warm overhead desk lamp casting a pool of amber light across typewriter & pages
    this.keyLight = new THREE.SpotLight(
      0xffcf91,
      this.keyIntensity,
      4.5,
      THREE.MathUtils.degToRad(56),
      0.68,
      1.35,
    );
    this.keyLight.position.set(-0.42, 0.96, 0.34);
    this.keyLight.target.position.set(0.0, 0.06, 0.06);
    this.keyLight.castShadow = true;
    this.keyLight.shadow.mapSize.set(1024, 1024);
    this.keyLight.shadow.camera.near = 0.2;
    this.keyLight.shadow.camera.far = 3.2;
    this.keyLight.shadow.bias = -0.00035;
    this.group.add(this.keyLight, this.keyLight.target);

    // Soft warm bounce light from the front-right so the open type-basket well is well-lit
    this.fillLight = new THREE.PointLight(0xffb870, this.fillIntensity, 3.0, 1.5);
    this.fillLight.position.set(0.45, 0.48, 0.42);
    this.group.add(this.fillLight);

    // Cool moonlight rim from behind the platen to catch the chrome rails & type bars
    this.rimLight = new THREE.DirectionalLight(0x9cb8e8, this.rimIntensity);
    this.rimLight.position.set(0.28, 0.65, -0.85);
    this.group.add(this.rimLight);
  }

  setOpacity(o: number) {
    const transparent = o < 0.999;
    if (this.surfaceMat.transparent !== transparent) {
      this.surfaceMat.transparent = transparent;
      this.surfaceMat.needsUpdate = true;
    }
    this.surfaceMat.opacity = o;
    this.keyLight.intensity = this.keyIntensity * o;
    this.fillLight.intensity = this.fillIntensity * o;
    this.rimLight.intensity = this.rimIntensity * o;
    this.group.visible = o > 0.002;
  }
}
