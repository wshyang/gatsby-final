/// <reference types="vite/client" />

declare module "*.glsl?raw" {
  const content: string;
  export default content;
}

declare module "*.jpg" {
  const src: string;
  export default src;
}
