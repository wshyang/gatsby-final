import { useEffect, useRef, useState } from "react";
import {
  Play,
  Pause,
  RotateCcw,
  Eye,
  EyeOff,
  Film,
  Info,
  X,
  FileText,
  Wind,
  Sparkles,
  Keyboard,
} from "lucide-react";
import { GatsbyScene, PHASES, SEQUENCE_SECONDS, type SceneStats } from "./gatsby/scene";

/** Make sure the typewriter webfont is ready before we rasterise the atlas. */
async function waitForFont() {
  try {
    await Promise.race([
      document.fonts.load('46px "Special Elite"'),
      new Promise((r) => setTimeout(r, 2500)),
    ]);
  } catch {
    /* fall back to Courier */
  }
}

const REF_CLIP_URL = "https://github.com/wshyang/gatsby-final/blob/main/66.0-88.0.mp4";

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sceneRef = useRef<GatsbyScene | null>(null);
  const [ready, setReady] = useState(false);
  const [progress, setProgress] = useState(0);
  const [playing, setPlaying] = useState(true);
  const [stats, setStats] = useState<SceneStats>({ total: 0, onPaper: 0, inFlight: 0, settled: 0 });
  const [hud, setHud] = useState(true);
  const [about, setAbout] = useState(false);

  useEffect(() => {
    let scene: GatsbyScene | null = null;
    let raf = 0;
    let cancelled = false;

    waitForFont().then(() => {
      if (cancelled || !canvasRef.current) return;
      scene = new GatsbyScene(canvasRef.current);
      sceneRef.current = scene;
      setReady(true);
      let last = 0;
      const poll = (now: number) => {
        if (!scene) return;
        if (now - last > 100) {
          last = now;
          setProgress(scene.progress);
          setPlaying(scene.playing);
          setStats(scene.stats());
        }
        raf = requestAnimationFrame(poll);
      };
      raf = requestAnimationFrame(poll);
    });

    return () => {
      cancelled = true;
      cancelAnimationFrame(raf);
      scene?.dispose();
      sceneRef.current = null;
    };
  }, []);

  const phaseIndex = PHASES.reduce((acc, p, i) => (progress >= p.at ? i : acc), 0);
  const phase = PHASES[phaseIndex];
  const seconds = progress * SEQUENCE_SECONDS;
  const finished = progress >= 1;

  const togglePlay = () => {
    const s = sceneRef.current;
    if (!s) return;
    if (s.progress >= 1) s.restart();
    else s.playing = !s.playing;
  };

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-[#05070d] text-[#e8dcc0] select-none">
      <canvas ref={canvasRef} className="block h-full w-full" />

      {/* loading */}
      {!ready && (
        <div className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-4 bg-[#05070d]">
          <p className="deco text-3xl font-light uppercase tracking-[0.35em] text-[#e8dcc0]">Gatsby</p>
          <div className="h-px w-40 bg-gradient-to-r from-transparent via-[#c9b27a] to-transparent" />
          <p className="type animate-pulse text-xs tracking-[0.3em] text-[#c9b27a]">Threading the ribbon…</p>
        </div>
      )}

      {/* ── top title bar ─────────────────────────────────────────── */}
      <header
        className={`pointer-events-none absolute left-0 right-0 top-0 flex items-start justify-between p-5 transition-opacity duration-700 sm:p-7 ${hud ? "opacity-100" : "opacity-0"}`}
      >
        <div>
          <p className="text-[10px] uppercase tracking-[0.45em] text-[#c9b27a]">WebGL · Instanced Particle Typography</p>
          <h1 className="deco mt-1 text-2xl font-light uppercase tracking-[0.25em] sm:text-3xl">The Great Gatsby</h1>
          <p className="mt-1 text-[11px] italic text-[#9a8f78]">Opening sequence study · 00:66 – 00:88 · Baz Luhrmann, 2013</p>
        </div>

        {/* live particle telemetry — proves every glyph came off a page */}
        <div className="hidden text-right text-[11px] leading-6 text-[#9a8f78] sm:block">
          <p className="flex items-center justify-end gap-2">
            <span className="text-[#e8dcc0] tabular-nums">{stats.total.toLocaleString()}</span> typed characters
            <Keyboard size={12} className="text-[#c9b27a]" aria-hidden />
          </p>
          <p className="flex items-center justify-end gap-2">
            <span className="text-[#e8dcc0] tabular-nums">{stats.onPaper.toLocaleString()}</span> on paper
            <FileText size={12} className="text-[#c9b27a]" aria-hidden />
          </p>
          <p className="flex items-center justify-end gap-2">
            <span className="text-[#f5e6b8] tabular-nums">{stats.inFlight.toLocaleString()}</span> airborne
            <Wind size={12} className="text-[#f5e6b8]" aria-hidden />
          </p>
          <p className="flex items-center justify-end gap-2">
            <span className="text-white tabular-nums">{stats.settled.toLocaleString()}</span> settled
            <Sparkles size={12} className="text-white" aria-hidden />
          </p>
        </div>
      </header>

      {/* ── bottom control deck ───────────────────────────────────── */}
      <footer
        className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t from-[#05070d]/85 to-transparent p-5 pt-12 transition-opacity duration-700 sm:p-7 sm:pt-14 ${hud ? "opacity-100" : "pointer-events-none opacity-0"}`}
      >
        <div className="mx-auto max-w-5xl">
          {/* act chips — every chapter is visible and one click away */}
          <div className="mb-4 flex flex-wrap items-center gap-2">
            {PHASES.map((p, i) => (
              <button
                key={p.at}
                onClick={() => sceneRef.current?.seek(p.at + 0.001)}
                title={`Jump to ${p.label}`}
                className={`deco border px-3 py-1 text-[11px] uppercase tracking-[0.2em] transition-colors ${
                  i === phaseIndex
                    ? "border-[#c9b27a] bg-[#c9b27a]/15 text-[#f5e6b8]"
                    : "border-[#3a3326] text-[#9a8f78] hover:border-[#c9b27a]/60 hover:text-[#e8dcc0]"
                }`}
              >
                {p.label}
              </button>
            ))}
            <p className="ml-auto font-mono text-xs tabular-nums text-[#9a8f78]">
              {seconds.toFixed(1).padStart(4, "0")}s / {SEQUENCE_SECONDS}s
            </p>
          </div>

          <p className="mb-3 min-h-[1.25rem] text-xs italic text-[#9a8f78]">{phase.blurb}</p>

          {/* scrubber with diamond phase ticks */}
          <div className="relative">
            <div className="absolute inset-x-0 top-1/2 h-px -translate-y-1/2 bg-[#3a3326]" />
            <div
              className="absolute left-0 top-1/2 h-px -translate-y-1/2 bg-[#c9b27a]"
              style={{ width: `${progress * 100}%` }}
            />
            {PHASES.map((p) => (
              <button
                key={p.at}
                title={p.label}
                aria-label={`Seek to ${p.label}`}
                onClick={() => sceneRef.current?.seek(p.at + 0.001)}
                className="absolute top-1/2 h-2 w-2 -translate-x-1/2 -translate-y-1/2 rotate-45 border border-[#c9b27a] bg-[#05070d] hover:bg-[#c9b27a]"
                style={{ left: `${p.at * 100}%` }}
              />
            ))}
            <input
              type="range"
              min={0}
              max={1000}
              value={Math.round(progress * 1000)}
              onChange={(e) => sceneRef.current?.seek(Number(e.target.value) / 1000)}
              className="relative z-10 h-6 w-full cursor-pointer appearance-none bg-transparent"
              aria-label="Timeline"
            />
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-2 text-[11px] uppercase tracking-[0.2em]">
            <button
              onClick={togglePlay}
              className="flex items-center gap-2 border border-[#c9b27a]/60 px-4 py-1.5 transition-colors hover:bg-[#c9b27a]/15"
            >
              {finished ? <RotateCcw size={13} aria-hidden /> : playing ? <Pause size={13} aria-hidden /> : <Play size={13} aria-hidden />}
              {finished ? "Replay" : playing ? "Pause" : "Play"}
            </button>
            <button
              onClick={() => sceneRef.current?.restart()}
              className="flex items-center gap-2 border border-[#3a3326] px-4 py-1.5 transition-colors hover:border-[#c9b27a]/60"
            >
              <RotateCcw size={13} aria-hidden /> Restart
            </button>
            <button
              onClick={() => setAbout(true)}
              className="flex items-center gap-2 border border-[#3a3326] px-4 py-1.5 transition-colors hover:border-[#c9b27a]/60"
            >
              <Info size={13} aria-hidden /> How it works
            </button>
            <a
              href={REF_CLIP_URL}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 border border-[#3a3326] px-4 py-1.5 transition-colors hover:border-[#c9b27a]/60"
            >
              <Film size={13} aria-hidden /> Reference clip
            </a>
            <span className="ml-auto hidden text-[#5f574a] sm:inline">Space play · R restart · H hide interface</span>
          </div>
        </div>
      </footer>

      {/* hide / show HUD (always reachable) */}
      <button
        onClick={() => setHud((h) => !h)}
        title={hud ? "Hide interface (H)" : "Show interface (H)"}
        aria-label={hud ? "Hide interface" : "Show interface"}
        className={`absolute right-5 top-1/2 z-20 flex -translate-y-1/2 items-center gap-2 border border-[#3a3326] bg-[#05070d]/60 px-2.5 py-2 text-[#9a8f78] transition-all hover:border-[#c9b27a]/60 hover:text-[#e8dcc0] ${hud ? "opacity-40 hover:opacity-100" : "opacity-80"}`}
      >
        {hud ? <EyeOff size={14} aria-hidden /> : <Eye size={14} aria-hidden />}
      </button>

      {/* ── "How it works" drawer ─────────────────────────────────── */}
      {about && <AboutDrawer onClose={() => setAbout(false)} />}

      <KeyHandler
        onToggleHud={() => setHud((h) => !h)}
        onSpace={togglePlay}
        onRestart={() => sceneRef.current?.restart()}
        onEscape={() => setAbout(false)}
      />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Technique notes — the data mapping & pacing, in plain language      */
/* ------------------------------------------------------------------ */
function AboutDrawer({ onClose }: { onClose: () => void }) {
  return (
    <div className="absolute inset-0 z-40 flex justify-end bg-black/50" onClick={onClose}>
      <aside
        onClick={(e) => e.stopPropagation()}
        className="drawer-in h-full w-full max-w-md overflow-y-auto border-l border-[#3a3326] bg-[#0a0d16]/95 p-7 backdrop-blur-sm"
      >
        <div className="mb-5 flex items-start justify-between">
          <div>
            <p className="text-[10px] uppercase tracking-[0.4em] text-[#c9b27a]">Technique</p>
            <h2 className="deco mt-1 text-2xl font-light uppercase tracking-[0.2em]">How it works</h2>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="border border-[#3a3326] p-2 text-[#9a8f78] hover:border-[#c9b27a]/60 hover:text-[#e8dcc0]"
          >
            <X size={14} aria-hidden />
          </button>
        </div>

        <Section title="No spawning out of nowhere">
          Every particle is a character physically typed on one of the four sheets (three on the desk, one still in the
          platen). A CPU pass lays out each page, transforms every glyph into world space, and stores that exact point on
          the paper mesh as the particle's <em>source</em>. The GPU only ever interpolates between stored endpoints — it
          never invents a position or fades a glyph in from empty space.
        </Section>

        <Section title="The mapping table">
          Quote slots are filled greedily <em>by matching glyph</em>: a flying “G” really was a typed “G”, donated by the
          page nearest the lens. Each instance carries source position + page orientation, target position + quote
          orientation, both sizes, its atlas cell, a (delay, duration) pair and a mode: <b>stay</b> on the paper,{" "}
          <b>assemble</b> into the quote, or <b>scatter</b> into the ambient sea.
        </Section>

        <Section title="Cinematic pacing">
          Quote letters ride a three-act curve: a slow quadratic <em>peel</em> off the sheet, a long weightless{" "}
          <em>suspension</em>, then an ease-out-back <em>magnetic snap</em> that overshoots ~3% before settling. A
          reading-order stagger makes the sentence resolve left-to-right. The camera creeps, then retreats over a
          Catmull-Rom path while the desk lamp crossfades to cold city light.
        </Section>

        <Section title="Lessons from reviews.txt">
          Built on the best-reviewed parallel implementation (<em>fable low</em>) from wshyang/gatsby-final, then fixed
          the noted flaws: the zoom-out and lift-off are slower, <em>all</em> pages shed letters, the sea of type is
          denser (62% of unused glyphs) and never fully dissolves, and the assembly snaps deliberately instead of easing
          uniformly. The 2D city photograph is kept — its blur-to-focus rack was specifically praised.
        </Section>

        <Section title="Rendering">
          One instanced quad per character (~7k instances, a single draw call), a canvas-rasterised Special Elite glyph
          atlas (sharp ink in R, soft halo in G), quaternion slerp + whole-number tumbles so letters land perfectly flat,
          BokehPass depth-of-field that racks focus from paper to quote, plus a warm→cool grade, vignette and film grain.
        </Section>

        <p className="mt-6 border-t border-[#3a3326] pt-4 text-[10px] uppercase tracking-[0.3em] text-[#5f574a]">
          Text · F. Scott Fitzgerald, 1925 · public domain
        </p>
      </aside>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-5">
      <h3 className="deco mb-1.5 text-sm uppercase tracking-[0.25em] text-[#c9b27a]">{title}</h3>
      <p className="text-[13px] leading-6 text-[#b3a88e] [&_b]:text-[#e8dcc0] [&_em]:text-[#e8dcc0]">{children}</p>
    </section>
  );
}

function KeyHandler({
  onToggleHud,
  onSpace,
  onRestart,
  onEscape,
}: {
  onToggleHud: () => void;
  onSpace: () => void;
  onRestart: () => void;
  onEscape: () => void;
}) {
  useEffect(() => {
    const fn = (e: KeyboardEvent) => {
      if (e.key === "h" || e.key === "H") onToggleHud();
      if (e.key === "r" || e.key === "R") onRestart();
      if (e.key === "Escape") onEscape();
      if (e.key === " ") {
        e.preventDefault();
        onSpace();
      }
    };
    window.addEventListener("keydown", fn);
    return () => window.removeEventListener("keydown", fn);
  }, [onToggleHud, onSpace, onRestart, onEscape]);
  return null;
}
