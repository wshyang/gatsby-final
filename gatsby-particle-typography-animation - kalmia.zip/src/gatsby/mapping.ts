import * as THREE from "three";
import { CELL_PX, FONT_PX, BASELINE_PX, type GlyphAtlas } from "./atlas";

/**
 * DATA MAPPING: paper source  ->  quote destination
 * ==================================================
 *
 * The whole effect is a static table built once on the CPU. Each row is one
 * typewritten character that physically exists on a page. The GPU vertex
 * shader never invents positions – it only interpolates between the two
 * endpoints stored here.
 *
 *   SourceGlyph  (what is printed on the page)
 *     page       index of the sheet the character belongs to
 *     local      position on the page in page-local coordinates (page centre
 *                is origin, +x right, +y up, page lies in the z=0 plane)
 *     world      `local` transformed by the page's rigid transform – this is
 *                the exact point on the paper mesh the particle lifts off from
 *     sizeWorld  size of the glyph quad on the paper
 *
 *   Assignment   (what happens to it when the lift-off begins)
 *     mode 0 STAY     – remains printed on the page
 *     mode 1 ASSEMBLE – flies to a slot in the quote (target = slot position)
 *     mode 2 SCATTER  – lifts off, tumbles upward and dissolves (ambient chaff)
 *
 * Slot assignment is greedy-by-glyph: each quote character takes a page
 * character with the *same* glyph, preferring the page nearest the camera
 * at lift-off time, so a flying "G" really was a typed "G".
 */

export interface PageTransform {
  position: THREE.Vector3;
  quaternion: THREE.Quaternion;
  /** page size in world units */
  width: number;
  height: number;
}

export interface SourceGlyph {
  char: string;
  glyphIndex: number;
  page: number;
  local: THREE.Vector3;
  world: THREE.Vector3;
  sizeWorld: number;
}

export interface QuoteSlot {
  char: string;
  glyphIndex: number;
  world: THREE.Vector3;
  sizeWorld: number;
}

export interface GlyphInstanceData {
  count: number;
  source: Float32Array;       // vec3 world origin on paper
  sourceQuat: Float32Array;   // vec4 page orientation
  target: Float32Array;       // vec3 destination
  targetQuat: Float32Array;   // vec4 destination orientation
  sizes: Float32Array;        // vec2 (sourceSize, targetSize)
  glyph: Float32Array;        // float atlas cell index
  timing: Float32Array;       // vec2 (delay, duration) in normalised timeline units
  seed: Float32Array;         // float random seed
  mode: Float32Array;         // float 0 stay | 1 assemble | 2 scatter
  /** bookkeeping for the HUD */
  modes: number[];
  delays: number[];
  durations: number[];
}

/* ------------------------------------------------------------------ */
/* 1. Lay the typed text out on a page and lift it into world space     */
/* ------------------------------------------------------------------ */

export function layoutPage(
  text: string,
  pageIndex: number,
  xform: PageTransform,
  atlas: GlyphAtlas,
  fontSizeWorld: number,
  lineHeightWorld: number,
  marginX: number,
  marginTop: number,
): SourceGlyph[] {
  const out: SourceGlyph[] = [];
  const lines = text.split("\n");
  const advance = atlas.advanceEm * fontSizeWorld;
  // the quad is CELL_PX wide while the em is FONT_PX – scale accordingly
  const quadSize = fontSizeWorld * (CELL_PX / FONT_PX);
  // atlas glyphs are drawn with baseline at BASELINE_PX; the quad is centred
  // on the cell, so the quad centre sits this far above the baseline:
  const centreAboveBaseline = ((BASELINE_PX - CELL_PX / 2) / CELL_PX) * quadSize;

  const left = -xform.width / 2 + marginX;
  const top = xform.height / 2 - marginTop;

  lines.forEach((line, li) => {
    const baseline = top - li * lineHeightWorld;
    for (let ci = 0; ci < line.length; ci++) {
      const ch = line[ci];
      if (ch === " ") continue;
      const gi = atlas.index.get(ch);
      if (gi === undefined) continue;
      const x = left + ci * advance + advance / 2;
      // tiny mechanical jitter – real typewriters never align perfectly
      const jx = (Math.sin(li * 12.9898 + ci * 78.233) * 0.5) * advance * 0.08;
      const jy = (Math.cos(li * 4.123 + ci * 9.31) * 0.5) * fontSizeWorld * 0.06;
      const local = new THREE.Vector3(x + jx, baseline + centreAboveBaseline + jy, 0.004);
      const world = local.clone().applyQuaternion(xform.quaternion).add(xform.position);
      out.push({ char: ch, glyphIndex: gi, page: pageIndex, local, world, sizeWorld: quadSize });
    }
  });
  return out;
}

/* ------------------------------------------------------------------ */
/* 2. Lay the quote out in a 3D frame floating in front of the camera   */
/* ------------------------------------------------------------------ */

export function layoutQuote(
  lines: string[],
  atlas: GlyphAtlas,
  frame: { position: THREE.Vector3; quaternion: THREE.Quaternion },
  fontSizeWorld: number,
  lineHeightWorld: number,
): QuoteSlot[] {
  const slots: QuoteSlot[] = [];
  const advance = atlas.advanceEm * fontSizeWorld;
  const quadSize = fontSizeWorld * (CELL_PX / FONT_PX);
  const centreAboveBaseline = ((BASELINE_PX - CELL_PX / 2) / CELL_PX) * quadSize;
  const totalH = (lines.length - 1) * lineHeightWorld;

  lines.forEach((line, li) => {
    const width = line.length * advance;
    const baseline = totalH / 2 - li * lineHeightWorld - fontSizeWorld * 0.35;
    for (let ci = 0; ci < line.length; ci++) {
      const ch = line[ci];
      if (ch === " ") continue;
      const gi = atlas.index.get(ch);
      if (gi === undefined) continue;
      const local = new THREE.Vector3(-width / 2 + ci * advance + advance / 2, baseline + centreAboveBaseline, 0);
      const world = local.applyQuaternion(frame.quaternion).add(frame.position);
      slots.push({ char: ch, glyphIndex: gi, world, sizeWorld: quadSize });
    }
  });
  return slots;
}

/* ------------------------------------------------------------------ */
/* 3. Assign page characters to quote slots and pack GPU attributes     */
/* ------------------------------------------------------------------ */

function mulberry(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function buildInstanceData(
  sources: SourceGlyph[],
  slots: QuoteSlot[],
  pages: PageTransform[],
  quoteQuat: THREE.Quaternion,
  opts: {
    /** pages ordered by preference when choosing a donor character */
    pagePriority: number[];
    liftStart: number;      // timeline (0..1) when the first letter detaches
    liftSpread: number;     // how long the detaching keeps going
    flightDuration: number; // per-letter travel time (timeline units)
    scatterFraction: number;// share of unused letters that blow away
    assembleSpread: number; // extra delay spread so the quote locks in reading order
  },
): GlyphInstanceData {
  const rnd = mulberry(1922);
  const n = sources.length;

  // --- 3a. index donors by glyph, in page-priority order ---------------
  const pool = new Map<number, number[]>();
  const priorityRank = new Map<number, number>();
  opts.pagePriority.forEach((p, i) => priorityRank.set(p, i));
  const order = sources
    .map((_s, i) => i)
    .sort((a, b) => (priorityRank.get(sources[a].page) ?? 99) - (priorityRank.get(sources[b].page) ?? 99));
  for (const i of order) {
    const gi = sources[i].glyphIndex;
    if (!pool.has(gi)) pool.set(gi, []);
    pool.get(gi)!.push(i);
  }

  // --- 3b. greedy assignment: every quote slot gets a real typed glyph --
  const assignment = new Int32Array(n).fill(-1); // source -> slot
  const unmatched: QuoteSlot[] = [];
  for (let si = 0; si < slots.length; si++) {
    const list = pool.get(slots[si].glyphIndex);
    if (list && list.length) {
      // take a donor from somewhere in the preferred page (not always the first
      // occurrence, so letters come from all over the sheet)
      const take = Math.floor(rnd() * Math.min(list.length, 6));
      const srcIdx = list.splice(take, 1)[0];
      assignment[srcIdx] = si;
    } else {
      unmatched.push(slots[si]);
    }
  }
  if (unmatched.length) {
    // Should not happen with the provided pages, but keep the rule strict:
    // never create a glyph – just log the gap and leave the slot empty.
    console.warn("Quote slots without a matching typed glyph:", unmatched.map((u) => u.char).join(""));
  }

  // --- 3c. pack attributes ---------------------------------------------
  const d: GlyphInstanceData = {
    count: n,
    source: new Float32Array(n * 3),
    sourceQuat: new Float32Array(n * 4),
    target: new Float32Array(n * 3),
    targetQuat: new Float32Array(n * 4),
    sizes: new Float32Array(n * 2),
    glyph: new Float32Array(n),
    timing: new Float32Array(n * 2),
    seed: new Float32Array(n),
    mode: new Float32Array(n),
    modes: [],
    delays: [],
    durations: [],
  };

  const up = new THREE.Vector3(0, 1, 0);
  const scatterQuat = new THREE.Quaternion();

  for (let i = 0; i < n; i++) {
    const s = sources[i];
    const page = pages[s.page];
    const slot = assignment[i] >= 0 ? slots[assignment[i]] : null;

    let mode = 0;
    let target = s.world;
    let tq = page.quaternion;
    let tSize = s.sizeWorld;
    let delay = 0;
    let duration = 1;

    if (slot) {
      mode = 1;
      target = slot.world;
      tq = quoteQuat;
      tSize = slot.sizeWorld;
      // letters near the top of the sheet leave a touch earlier – reads as a gust
      const rowBias = THREE.MathUtils.clamp(0.5 - s.local.y / page.height, 0, 1);
      // reading-order bias: early characters of the quote depart (and therefore
      // snap in) first, so the sentence resolves left-to-right, line-by-line
      const readOrder = assignment[i] / Math.max(1, slots.length - 1);
      delay = opts.liftStart
        + rnd() * opts.liftSpread * 0.6
        + rowBias * opts.liftSpread * 0.15
        + readOrder * opts.assembleSpread;
      duration = opts.flightDuration * (0.85 + rnd() * 0.3);
    } else if (rnd() < opts.scatterFraction) {
      mode = 2;
      // drift up and away, roughly toward the camera's retreat direction
      target = s.world.clone().add(new THREE.Vector3((rnd() - 0.5) * 6, 3 + rnd() * 5, (rnd() - 0.2) * 5));
      scatterQuat.setFromAxisAngle(up, rnd() * Math.PI * 2);
      tq = scatterQuat.clone();
      tSize = s.sizeWorld * (1.5 + rnd());
      delay = opts.liftStart + rnd() * opts.liftSpread;
      // chaff travels slower than quote letters – it lingers as the ambient sea
      duration = opts.flightDuration * (1.3 + rnd() * 1.1);
    }

    d.source.set([s.world.x, s.world.y, s.world.z], i * 3);
    d.sourceQuat.set([page.quaternion.x, page.quaternion.y, page.quaternion.z, page.quaternion.w], i * 4);
    d.target.set([target.x, target.y, target.z], i * 3);
    d.targetQuat.set([tq.x, tq.y, tq.z, tq.w], i * 4);
    d.sizes.set([s.sizeWorld, tSize], i * 2);
    d.glyph[i] = s.glyphIndex;
    d.timing.set([delay, duration], i * 2);
    d.seed[i] = rnd();
    d.mode[i] = mode;
    d.modes.push(mode);
    d.delays.push(delay);
    d.durations.push(duration);
  }
  return d;
}
