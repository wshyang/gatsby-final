import * as THREE from "three";
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer.js";
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass.js";
import { BokehPass } from "three/examples/jsm/postprocessing/BokehPass.js";
import { ShaderPass } from "three/examples/jsm/postprocessing/ShaderPass.js";
import { OutputPass } from "three/examples/jsm/postprocessing/OutputPass.js";

import { buildGlyphAtlas, buildPaperTexture, buildWoodTexture, ATLAS_COLS, ATLAS_ROWS } from "./atlas";
import { layoutPage, layoutQuote, buildInstanceData, type PageTransform, type SourceGlyph, type GlyphInstanceData } from "./mapping";
import { glyphVertexShader, glyphFragmentShader, gradeShader } from "./shaders";
import { PAGE_TEXTS, QUOTE_LINES } from "./text";
import cityUrl from "../assets/city.jpg";

/**
 * Total length of the sequence in seconds (the reference clip runs 66s→88s,
 * stretched slightly here — reviews flagged the earlier zoom-out and lift-off
 * as too fast, so the camera and the letters are given room to breathe).
 */
export const SEQUENCE_SECONDS = 30;

/** Timeline milestones (normalised 0..1) – four acts, mirroring the film's rhythm. */
export const PHASES = [
  { at: 0.0, label: "I. The Source", blurb: "Typed pages on the desk – every character is a particle resting on the paper." },
  { at: 0.22, label: "II. Lift-off", blurb: "Letters peel slowly off every sheet along their own bezier paths, tumbling as they rise." },
  { at: 0.48, label: "III. Suspension", blurb: "A dense sea of type hangs weightless in the air as the city opens up below." },
  { at: 0.68, label: "IV. Assembly", blurb: "One by one, in reading order, the letters snap magnetically into the floating quote." },
];

export interface SceneStats {
  total: number;
  onPaper: number;
  inFlight: number;
  settled: number;
}

/* ------------------------------------------------------------------ */
/* Camera path                                                          */
/* ------------------------------------------------------------------ */
const CAM_KEYS = [
  { t: 0.0, pos: [1.1, 1.5, 3.6], look: [0.3, 0.1, 1.2] },   // close on the typed page
  { t: 0.24, pos: [0.7, 1.9, 3.9], look: [0.1, 0.35, 0.5] }, // slow creep as letters peel
  { t: 0.52, pos: [0.0, 3.6, 6.5], look: [0.0, 1.6, -2.0] }, // gentle pull-back begins
  { t: 0.78, pos: [0.0, 6.6, 10.0], look: [0.0, 5.6, -15.0] },// aerial reveal of the city
  { t: 1.0, pos: [0.0, 8.0, 12.0], look: [0.0, 7.0, -20.0] }, // rest on the finished quote
];
const FINAL_CAM_POS = new THREE.Vector3(...(CAM_KEYS[4].pos as [number, number, number]));
const FINAL_CAM_LOOK = new THREE.Vector3(...(CAM_KEYS[4].look as [number, number, number]));

export class GatsbyScene {
  readonly renderer: THREE.WebGLRenderer;
  readonly scene = new THREE.Scene();
  readonly camera: THREE.PerspectiveCamera;
  private composer: EffectComposer;
  private bokeh: BokehPass;
  private grade: ShaderPass;

  private glyphMaterial!: THREE.ShaderMaterial;
  private instanceData!: GlyphInstanceData;
  private posCurve: THREE.CatmullRomCurve3;
  private lookCurve: THREE.CatmullRomCurve3;
  private quoteCentre = new THREE.Vector3();
  private pageFocus = new THREE.Vector3(0.2, 0, 1.4);

  private cityPlane!: THREE.Mesh<THREE.PlaneGeometry, THREE.MeshBasicMaterial>;
  private lamp!: THREE.SpotLight;
  private sky!: THREE.HemisphereLight;

  progress = 0;
  playing = true;
  private clock = new THREE.Clock();
  private disposed = false;

  constructor(canvas: HTMLCanvasElement) {
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.camera = new THREE.PerspectiveCamera(42, 1, 0.05, 400);
    this.scene.background = new THREE.Color(0x05070d);
    this.scene.fog = new THREE.FogExp2(0x05070d, 0.028);

    this.posCurve = new THREE.CatmullRomCurve3(CAM_KEYS.map((k) => new THREE.Vector3(...(k.pos as [number, number, number]))), false, "centripetal");
    this.lookCurve = new THREE.CatmullRomCurve3(CAM_KEYS.map((k) => new THREE.Vector3(...(k.look as [number, number, number]))), false, "centripetal");

    this.buildEnvironment();
    this.buildTypewriter();
    const pages = this.buildPages();
    this.buildGlyphs(pages);

    // ----- post processing: DoF + grade -----
    this.composer = new EffectComposer(this.renderer);
    this.composer.addPass(new RenderPass(this.scene, this.camera));
    this.bokeh = new BokehPass(this.scene, this.camera, { focus: 3, aperture: 0.00009, maxblur: 0.0075 });
    this.composer.addPass(this.bokeh);
    this.grade = new ShaderPass(gradeShader);
    this.composer.addPass(this.grade);
    this.composer.addPass(new OutputPass());

    this.resize();
    window.addEventListener("resize", this.resize);
    this.renderer.setAnimationLoop(this.tick);
  }

  /* ---------------------------------------------------------------- */
  /* Scene construction                                                 */
  /* ---------------------------------------------------------------- */

  private buildEnvironment() {
    // desk
    const wood = buildWoodTexture();
    const desk = new THREE.Mesh(
      new THREE.PlaneGeometry(40, 30),
      new THREE.MeshStandardMaterial({ map: wood, roughness: 0.55, metalness: 0.05 }),
    );
    desk.rotation.x = -Math.PI / 2;
    desk.receiveShadow = true;
    this.scene.add(desk);

    // lights – a warm desk lamp, later joined by cold city light
    this.scene.add(new THREE.AmbientLight(0xffe2b8, 0.18));
    this.lamp = new THREE.SpotLight(0xffc98a, 160, 30, Math.PI / 4.5, 0.6, 1.6);
    this.lamp.position.set(2.5, 6, 2.5);
    this.lamp.target.position.set(0, 0, 0.5);
    this.lamp.castShadow = true;
    this.lamp.shadow.mapSize.set(2048, 2048);
    this.lamp.shadow.bias = -0.0005;
    this.scene.add(this.lamp, this.lamp.target);
    this.sky = new THREE.HemisphereLight(0x6f9fd8, 0x0a0f1c, 0);
    this.scene.add(this.sky);

    // the city backdrop – a vast plane far behind the desk; it only becomes
    // visible as the camera pulls back and the lamp dies down
    const cityTex = new THREE.TextureLoader().load(cityUrl);
    cityTex.colorSpace = THREE.SRGBColorSpace;
    this.cityPlane = new THREE.Mesh(
      new THREE.PlaneGeometry(220, 124),
      new THREE.MeshBasicMaterial({ map: cityTex, transparent: true, opacity: 0, fog: false, depthWrite: false }),
    );
    this.cityPlane.position.set(0, 14, -90);
    this.scene.add(this.cityPlane);

    // drifting dust motes in the lamp light (plain points, not glyphs)
    const n = 400;
    const pts = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) pts.set([(Math.random() - 0.5) * 10, Math.random() * 4, (Math.random() - 0.5) * 8 + 1], i * 3);
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(pts, 3));
    const dust = new THREE.Points(g, new THREE.PointsMaterial({ color: 0xffe0b0, size: 0.015, transparent: true, opacity: 0.35, depthWrite: false }));
    this.scene.add(dust);
  }

  private buildTypewriter() {
    const tw = new THREE.Group();
    tw.position.set(0, 0, -1.2);
    const enamel = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.3, metalness: 0.55 });
    const rubber = new THREE.MeshStandardMaterial({ color: 0x1b1a18, roughness: 0.95 });
    const chrome = new THREE.MeshStandardMaterial({ color: 0xcfcac0, roughness: 0.25, metalness: 0.9 });
    const keyTop = new THREE.MeshStandardMaterial({ color: 0xe9e1cd, roughness: 0.5 });

    const add = (geo: THREE.BufferGeometry, mat: THREE.Material, x: number, y: number, z: number, rot?: [number, number, number]) => {
      const m = new THREE.Mesh(geo, mat);
      m.position.set(x, y, z);
      if (rot) m.rotation.set(...rot);
      m.castShadow = true; m.receiveShadow = true;
      tw.add(m);
      return m;
    };

    add(new THREE.BoxGeometry(2.8, 0.45, 1.9), enamel, 0, 0.225, 0);            // base
    add(new THREE.BoxGeometry(2.5, 0.7, 1.05), enamel, 0, 0.8, -0.45);           // upper body
    add(new THREE.BoxGeometry(2.4, 0.08, 0.9), enamel, 0, 0.5, 0.35, [-0.25, 0, 0]); // keyboard deck
    add(new THREE.CylinderGeometry(0.24, 0.24, 3.0, 32), rubber, 0, 1.32, -0.6, [0, 0, Math.PI / 2]); // platen
    add(new THREE.CylinderGeometry(0.02, 0.02, 3.1, 12), chrome, 0, 1.5, -0.42, [0, 0, Math.PI / 2]); // paper bail
    add(new THREE.CylinderGeometry(0.16, 0.16, 0.12, 24), chrome, -1.58, 1.32, -0.6, [0, 0, Math.PI / 2]); // knobs
    add(new THREE.CylinderGeometry(0.16, 0.16, 0.12, 24), chrome, 1.58, 1.32, -0.6, [0, 0, Math.PI / 2]);
    add(new THREE.BoxGeometry(2.0, 0.05, 0.4), enamel, 0, 1.17, -0.12, [0.5, 0, 0]); // type basket cover
    add(new THREE.BoxGeometry(3.2, 0.05, 0.25), chrome, 0, 1.58, -0.6);         // carriage rail
    add(new THREE.BoxGeometry(0.1, 0.5, 0.1), chrome, -1.4, 1.75, -0.6);          // return lever
    add(new THREE.BoxGeometry(0.6, 0.06, 0.1), chrome, -1.62, 1.98, -0.6);

    // keys – 4 stepped rows
    const rows = ["QWERTYUIOP", "ASDFGHJKL;", "ZXCVBNM,.?", "1234567890"];
    const order = [3, 0, 1, 2];
    order.forEach((ri, rowIdx) => {
      const row = rows[ri];
      const z = -0.05 + rowIdx * 0.23;
      const y = 0.66 - rowIdx * 0.06;
      const offset = (rowIdx % 2) * 0.1 - 0.1;
      for (let i = 0; i < row.length; i++) {
        const x = (i - (row.length - 1) / 2) * 0.23 + offset;
        add(new THREE.CylinderGeometry(0.085, 0.07, 0.05, 20), chrome, x, y, z);
        add(new THREE.CylinderGeometry(0.07, 0.07, 0.02, 20), keyTop, x, y + 0.03, z);
        add(new THREE.CylinderGeometry(0.012, 0.012, 0.35, 6), chrome, x, y - 0.17, z - 0.1, [-0.5, 0, 0]);
      }
    });
    add(new THREE.BoxGeometry(1.3, 0.05, 0.12), keyTop, 0.1, 0.45, 0.88); // space bar

    this.scene.add(tw);
  }

  /** Lay the sheets out physically. Returns their rigid transforms. */
  private buildPages(): PageTransform[] {
    const W = 2.1, H = 2.8;
    const flat = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), -Math.PI / 2);
    const onDesk = (x: number, y: number, z: number, yaw: number): PageTransform => ({
      position: new THREE.Vector3(x, y, z),
      quaternion: new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), yaw).multiply(flat),
      width: W, height: H,
    });
    const pages: PageTransform[] = [
      onDesk(-1.25, 0.012, 1.55, 0.16),   // page 0 – "After Gatsby's death..." (closest to lens)
      onDesk(1.55, 0.006, 1.15, -0.22),   // page 1 – chapter one
      onDesk(0.35, 0.018, 2.55, 0.05),    // page 2 – green light
      {                                   // page 3 – sheet still in the machine, leaning back
        position: new THREE.Vector3(0, 2.45, -1.95),
        quaternion: new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), -0.18),
        width: W, height: H,
      },
    ];

    pages.forEach((p, i) => {
      const mesh = new THREE.Mesh(
        new THREE.PlaneGeometry(p.width, p.height),
        new THREE.MeshStandardMaterial({ map: buildPaperTexture(i + 1), roughness: 0.9, side: THREE.DoubleSide }),
      );
      mesh.position.copy(p.position);
      mesh.quaternion.copy(p.quaternion);
      mesh.receiveShadow = true;
      mesh.castShadow = i === 3;
      this.scene.add(mesh);
    });
    return pages;
  }

  /** Build the instanced particle system from the page layouts. */
  private buildGlyphs(pages: PageTransform[]) {
    const atlas = buildGlyphAtlas();

    // --- sources: every typed character, with its exact spot on the paper ---
    const sources: SourceGlyph[] = [];
    PAGE_TEXTS.forEach((text, i) => {
      sources.push(...layoutPage(text, i, pages[i], atlas, 0.05, 0.078, 0.1, 0.2));
    });

    // --- targets: the quote, floating in front of the final camera pose ---
    const dir = FINAL_CAM_LOOK.clone().sub(FINAL_CAM_POS).normalize();
    const framePos = FINAL_CAM_POS.clone().add(dir.multiplyScalar(11));
    const frameQuat = new THREE.Quaternion().setFromRotationMatrix(
      new THREE.Matrix4().lookAt(framePos, FINAL_CAM_POS, new THREE.Vector3(0, 1, 0)),
    );
    this.quoteCentre.copy(framePos);
    const slots = layoutQuote(QUOTE_LINES, atlas, { position: framePos, quaternion: frameQuat }, 0.55, 0.95);

    // --- mapping table ---
    this.instanceData = buildInstanceData(sources, slots, pages, frameQuat, {
      pagePriority: [0, 3, 2, 1],
      liftStart: PHASES[1].at,   // first detach as act II begins
      liftSpread: 0.34,          // ALL pages keep shedding letters for a long while
      flightDuration: 0.30,      // per-letter journey (three-act easing inside)
      scatterFraction: 0.62,     // 62% of unused type becomes the ambient sea (dense!)
      assembleSpread: 0.10,      // reading-order stagger for the magnetic snap
    });
    const d = this.instanceData;

    // --- geometry: one unit quad, instanced ---
    const geo = new THREE.InstancedBufferGeometry();
    const quad = new THREE.PlaneGeometry(1, 1);
    geo.index = quad.index;
    geo.setAttribute("position", quad.getAttribute("position"));
    geo.setAttribute("uv", quad.getAttribute("uv"));
    geo.instanceCount = d.count;
    geo.setAttribute("aSource", new THREE.InstancedBufferAttribute(d.source, 3));
    geo.setAttribute("aSourceQuat", new THREE.InstancedBufferAttribute(d.sourceQuat, 4));
    geo.setAttribute("aTarget", new THREE.InstancedBufferAttribute(d.target, 3));
    geo.setAttribute("aTargetQuat", new THREE.InstancedBufferAttribute(d.targetQuat, 4));
    geo.setAttribute("aSizes", new THREE.InstancedBufferAttribute(d.sizes, 2));
    geo.setAttribute("aGlyph", new THREE.InstancedBufferAttribute(d.glyph, 1));
    geo.setAttribute("aTiming", new THREE.InstancedBufferAttribute(d.timing, 2));
    geo.setAttribute("aSeed", new THREE.InstancedBufferAttribute(d.seed, 1));
    geo.setAttribute("aMode", new THREE.InstancedBufferAttribute(d.mode, 1));
    geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 5, 0), 60); // never frustum-cull

    this.glyphMaterial = new THREE.ShaderMaterial({
      vertexShader: glyphVertexShader,
      fragmentShader: glyphFragmentShader,
      uniforms: {
        uProgress: { value: 0 },
        uTime: { value: 0 },
        uAtlas: { value: atlas.texture },
        uAtlasGrid: { value: new THREE.Vector2(ATLAS_COLS, ATLAS_ROWS) },
        uInkColor: { value: new THREE.Color(0x1d1612) },
        uGlowColor: { value: new THREE.Color(0xfff3dc) },
      },
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    const mesh = new THREE.Mesh(geo, this.glyphMaterial);
    mesh.frustumCulled = false;
    mesh.renderOrder = 10;
    this.scene.add(mesh);
  }

  /* ---------------------------------------------------------------- */
  /* Per-frame update                                                   */
  /* ---------------------------------------------------------------- */

  private tick = () => {
    if (this.disposed) return;
    const dt = Math.min(this.clock.getDelta(), 0.1);
    const t = this.clock.elapsedTime;
    if (this.playing) {
      this.progress = Math.min(1, this.progress + dt / SEQUENCE_SECONDS);
      if (this.progress >= 1) this.playing = false;
    }
    const p = this.progress;

    // camera: progress -> curve parameter (piecewise so key times are honoured)
    let u = 0;
    for (let i = 0; i < CAM_KEYS.length - 1; i++) {
      const a = CAM_KEYS[i].t, b = CAM_KEYS[i + 1].t;
      if (p >= a && p <= b) { u = (i + (p - a) / (b - a)) / (CAM_KEYS.length - 1); break; }
    }
    const pos = this.posCurve.getPoint(u);
    const look = this.lookCurve.getPoint(u);
    // handheld micro-drift
    pos.x += Math.sin(t * 0.7) * 0.02; pos.y += Math.sin(t * 0.9 + 1) * 0.015;
    this.camera.position.copy(pos);
    this.camera.lookAt(look);

    // lighting crossfade: lamp -> city
    const night = THREE.MathUtils.smoothstep(p, 0.44, 0.82);
    this.lamp.intensity = 160 * (1 - night * 0.85);
    this.sky.intensity = night * 1.2;
    // the city photograph fades in behind the fog, then the DoF racks focus
    // onto it – the "blur coming into focus" trick praised in reviews.txt
    this.cityPlane.material.opacity = THREE.MathUtils.smoothstep(p, 0.42, 0.74);
    (this.scene.fog as THREE.FogExp2).density = 0.028 * (1 - night * 0.6);
    this.grade.uniforms.uCool.value = night;
    this.grade.uniforms.uTime.value = t;

    // depth of field follows the subject: pages first, then the quote
    const focusPoint = this.pageFocus.clone().lerp(this.quoteCentre, THREE.MathUtils.smoothstep(p, 0.54, 0.82));
    const b = this.bokeh.uniforms as Record<string, THREE.IUniform>;
    b.focus.value = this.camera.position.distanceTo(focusPoint);
    b.aperture.value = THREE.MathUtils.lerp(0.00012, 0.00004, night);

    this.glyphMaterial.uniforms.uProgress.value = p;
    this.glyphMaterial.uniforms.uTime.value = t;

    this.composer.render();
  };

  /** Counts for the HUD – derived from the same timing table the GPU uses. */
  stats(): SceneStats {
    const d = this.instanceData;
    let onPaper = 0, inFlight = 0, settled = 0;
    for (let i = 0; i < d.count; i++) {
      if (d.modes[i] === 0) { onPaper++; continue; }
      const lp = (this.progress - d.delays[i]) / d.durations[i];
      if (lp <= 0) onPaper++; else if (lp >= 1) settled++; else inFlight++;
    }
    return { total: d.count, onPaper, inFlight, settled };
  }

  seek(p: number) { this.progress = THREE.MathUtils.clamp(p, 0, 1); }
  restart() { this.progress = 0; this.playing = true; }

  resize = () => {
    const canvas = this.renderer.domElement;
    const w = canvas.clientWidth || window.innerWidth;
    const h = canvas.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.composer.setSize(w, h);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  };

  dispose() {
    this.disposed = true;
    this.renderer.setAnimationLoop(null);
    window.removeEventListener("resize", this.resize);
    this.renderer.dispose();
  }
}
