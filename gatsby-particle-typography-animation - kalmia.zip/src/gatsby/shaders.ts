/**
 * Instanced glyph shaders.
 *
 * Per instance we know exactly two poses: where the character is printed on
 * the paper (source) and where it must end up (target). The vertex shader
 * derives everything else – flight path, tumbling, scale, colour – from the
 * global timeline `uProgress` and the per-instance (delay, duration).
 */

export const glyphVertexShader = /* glsl */ `

  attribute vec3  aSource;
  attribute vec4  aSourceQuat;
  attribute vec3  aTarget;
  attribute vec4  aTargetQuat;
  attribute vec2  aSizes;     // (sourceSize, targetSize)
  attribute float aGlyph;
  attribute vec2  aTiming;    // (delay, duration)
  attribute float aSeed;
  attribute float aMode;      // 0 stay, 1 assemble, 2 scatter

  uniform float uProgress;    // 0..1 global timeline
  uniform float uTime;        // seconds, for idle motion
  uniform vec2  uAtlasGrid;   // (cols, rows)

  varying vec2  vUv;
  varying float vP;           // local flight progress 0..1
  varying float vMode;
  varying float vSeed;

  /* ---------- helpers ---------- */
  float hash(float n) { return fract(sin(n) * 43758.5453123); }

  vec4 qmul(vec4 a, vec4 b) {
    return vec4(a.w*b.xyz + b.w*a.xyz + cross(a.xyz, b.xyz), a.w*b.w - dot(a.xyz, b.xyz));
  }
  vec4 qaxis(vec3 axis, float ang) { return vec4(normalize(axis) * sin(ang*0.5), cos(ang*0.5)); }
  vec4 qslerp(vec4 a, vec4 b, float t) {
    float d = dot(a, b);
    if (d < 0.0) { b = -b; d = -d; }
    if (d > 0.9995) return normalize(mix(a, b, t));
    float th = acos(d);
    return (sin((1.0-t)*th) * a + sin(t*th) * b) / sin(th);
  }
  vec3 qrot(vec4 q, vec3 v) { return v + 2.0 * cross(q.xyz, cross(q.xyz, v) + q.w * v); }

  float easeInOut(float t) { return t * t * (3.0 - 2.0 * t); }
  float easeOutBack(float t) { float c = 1.3; return 1.0 + (c+1.0)*pow(t-1.0,3.0) + c*pow(t-1.0,2.0); }

  /* ---------- cinematic three-act flight curve (mode 1 only) ----------
     Mirrors the film's rhythm instead of a uniform ease:
       act 1  p 0.00–0.30 : the character slowly PEELS off the sheet
                            (quadratic ease-in, only 12% of the path)
       act 2  p 0.30–0.78 : SUSPENSION – it drifts weightlessly through
                            the mid-air sea (gentle, near-linear glide)
       act 3  p 0.78–1.00 : the magnetic SNAP – easeOutBack accelerates
                            hard into the slot and overshoots ~3% before
                            settling, so the quote "clicks" into place. */
  float flightEase(float p) {
    if (p < 0.30) { float t = p / 0.30; return 0.12 * t * t; }
    if (p < 0.78) { float t = (p - 0.30) / 0.48; return 0.12 + 0.55 * t; }
    float t = (p - 0.78) / 0.22;
    float c = 1.7;
    float b = 1.0 + (c + 1.0) * pow(t - 1.0, 3.0) + c * pow(t - 1.0, 2.0);
    return 0.67 + 0.33 * b;
  }

  void main() {
    /* ---- atlas uv for this glyph ---- */
    float col = mod(aGlyph, uAtlasGrid.x);
    float row = floor(aGlyph / uAtlasGrid.x);
    vUv = (vec2(col, uAtlasGrid.y - 1.0 - row) + uv) / uAtlasGrid;

    /* ---- local progress of this letter along its own journey ---- */
    float p = 0.0;
    if (aMode > 0.5) p = clamp((uProgress - aTiming.x) / aTiming.y, 0.0, 1.0);
    vP = p; vMode = aMode; vSeed = aSeed;

    // quote-bound letters use the three-act curve; chaff drifts on a plain ease
    float pe = aMode > 1.5 ? easeInOut(p) : flightEase(p);

    /* ---- flight path: cubic bezier from the paper to the slot ----
       The first control point is straight up off the sheet, so the letter is
       seen to *peel off the paper* before swinging toward its destination. */
    vec3 S = aSource;
    vec3 T = aTarget;
    vec3 sheetNormal = qrot(aSourceQuat, vec3(0.0, 0.0, 1.0));
    float h1 = hash(aSeed * 17.0), h2 = hash(aSeed * 31.0), h3 = hash(aSeed * 53.0);
    vec3 C1 = S + sheetNormal * (1.5 + h1 * 2.5) + vec3(h2 - 0.5, 0.0, h3 - 0.5) * 2.0;
    vec3 C2 = T + vec3((h3 - 0.5) * 6.0, 2.0 + h1 * 3.0, (h2 - 0.5) * 4.0);
    if (aMode > 1.5) { C2 = mix(S, T, 0.6) + vec3(0.0, 2.0, 0.0); }

    float t = pe, it = 1.0 - pe;
    vec3 pos = it*it*it*S + 3.0*it*it*t*C1 + 3.0*it*t*t*C2 + t*t*t*T;

    /* turbulence while airborne (zero at both ends) */
    float air = sin(p * 3.14159);
    pos += air * vec3(
      sin(uTime * 1.7 + aSeed * 40.0),
      sin(uTime * 2.3 + aSeed * 20.0) * 0.6,
      cos(uTime * 1.3 + aSeed * 60.0)) * 0.25;

    /* gentle float after settling into the quote */
    if (aMode < 1.5 && p >= 1.0) {
      pos += vec3(sin(uTime * 0.8 + aSeed * 12.0), cos(uTime * 0.6 + aSeed * 7.0), 0.0) * 0.02;
    }
    /* the ambient sea keeps breathing after its journey ends – letters never
       freeze mid-air (review note: the sea of alphabets felt too sparse/dead) */
    if (aMode > 1.5 && p >= 1.0) {
      pos += vec3(sin(uTime * 0.22 + aSeed * 40.0) * 0.7,
                  sin(uTime * 0.16 + aSeed * 9.0) * 0.5,
                  cos(uTime * 0.19 + aSeed * 23.0) * 0.5);
    }

    /* ---- orientation: slerp page -> destination, plus whole tumbles ----
       Tumble counts are integers so the letter lands exactly flat. */
    vec4 q = qslerp(normalize(aSourceQuat), normalize(aTargetQuat), pe);
    float nx = floor(h1 * 2.0) + 1.0, ny = floor(h2 * 2.0) + 1.0, nz = floor(h3 * 1.5);
    float sgn = h2 > 0.5 ? 1.0 : -1.0;
    vec4 tumble = qmul(qaxis(vec3(1,0,0), pe * 6.28318 * nx * sgn),
                  qmul(qaxis(vec3(0,1,0), pe * 6.28318 * ny),
                       qaxis(vec3(0,0,1), pe * 6.28318 * nz * sgn)));
    // chaff keeps tumbling slowly even while suspended in the sea
    if (aMode > 1.5) tumble = qmul(tumble, qaxis(vec3(1,0,0), p * 9.0 * h1 + uTime * 0.25 * (h2 - 0.5)));
    q = qmul(q, tumble);

    /* ---- size ---- */
    float size = mix(aSizes.x, aSizes.y, aMode > 1.5 ? pe : easeOutBack(pe));

    vec3 local = qrot(q, vec3(position.xy * size, 0.0));
    vec4 mv = modelViewMatrix * vec4(pos + local, 1.0);
    gl_Position = projectionMatrix * mv;
  }
`;

export const glyphFragmentShader = /* glsl */ `

  uniform sampler2D uAtlas;
  uniform vec3 uInkColor;
  uniform vec3 uGlowColor;
  uniform float uTime;

  varying vec2  vUv;
  varying float vP;
  varying float vMode;
  varying float vSeed;

  void main() {
    vec2 s = texture2D(uAtlas, vUv).rg;   // r = sharp ink, g = soft halo
    float ink  = s.r;
    float halo = s.g;

    /* how "luminous" the letter is: ink on paper -> glowing type in the sky */
    float lum = smoothstep(0.0, 0.35, vP);
    if (vMode < 0.5) lum = 0.0;

    vec3 col = mix(uInkColor, uGlowColor, lum);
    float a = ink;
    /* halo only appears once airborne */
    a = max(a, halo * 0.55 * lum);
    col += uGlowColor * halo * 0.6 * lum;

    /* ink on the page isn't fully opaque – ribbon texture */
    if (lum < 0.01) a *= 0.92;

    /* scattered chaff dims but never fully vanishes – a persistent, dense
       sea of characters hangs behind the quote for the rest of the shot */
    if (vMode > 1.5) a *= 1.0 - 0.65 * smoothstep(0.55, 1.0, vP);

    /* subtle shimmer once settled */
    if (vMode > 0.5 && vMode < 1.5 && vP >= 1.0) {
      col *= 0.9 + 0.1 * sin(uTime * 2.0 + vSeed * 30.0);
    }

    if (a < 0.02) discard;
    gl_FragColor = vec4(col, a);
  }
`;

/** Full-screen finishing pass: vignette, warm/cool grade and film grain */
export const gradeShader = {
  uniforms: {
    tDiffuse: { value: null },
    uTime: { value: 0 },
    uCool: { value: 0 }, // 0 warm desk lamp -> 1 cool night sky
  },
  vertexShader: /* glsl */ `
    varying vec2 vUv;
    void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
  `,
  fragmentShader: /* glsl */ `
    uniform sampler2D tDiffuse;
    uniform float uTime;
    uniform float uCool;
    varying vec2 vUv;
    float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
    void main() {
      vec4 c = texture2D(tDiffuse, vUv);
      vec3 warm = c.rgb * vec3(1.06, 0.98, 0.88);
      vec3 cool = c.rgb * vec3(0.90, 0.98, 1.12);
      vec3 col = mix(warm, cool, uCool);
      vec2 d = vUv - 0.5;
      float vig = 1.0 - smoothstep(0.35, 0.95, dot(d, d) * 2.2);
      col *= mix(0.55, 1.0, vig);
      col += (hash(vUv * 1000.0 + fract(uTime)) - 0.5) * 0.035;
      gl_FragColor = vec4(col, 1.0);
    }
  `,
};
