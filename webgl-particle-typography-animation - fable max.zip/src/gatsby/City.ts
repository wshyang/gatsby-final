import * as THREE from "three";
import { PALETTE, WORLD } from "./config";
import { mulberry32 } from "./GlyphAtlas";

/**
 * City
 * ----
 * A procedural 1920s Manhattan seen from the air at night: thousands of
 * instanced building blocks with hash-generated lit windows, a gradient sky
 * dome, sweeping searchlights and snow that wraps around the camera.
 * Fog does the reveal – while the desk is in focus the city is completely
 * swallowed by the dense warm fog; as the fog thins the skyline emerges.
 */

const buildingVert = /* glsl */ `
  attribute float aRand;
  varying vec3 vWorld;
  varying vec3 vNormal;
  varying float vRand;
  varying float vH;
  void main() {
    vec4 w = modelMatrix * instanceMatrix * vec4(position, 1.0);
    vWorld = w.xyz;
    vNormal = normalize(mat3(modelMatrix * instanceMatrix) * normal);
    vRand = aRand;
    vH = position.y;
    gl_Position = projectionMatrix * viewMatrix * w;
  }
`;
const buildingFrag = /* glsl */ `
  uniform vec3 uFogColor;
  uniform float uFogDensity;
  uniform vec3 uCameraPos;
  uniform float uTime;
  uniform vec3 uWindow;
  varying vec3 vWorld;
  varying vec3 vNormal;
  varying float vRand;
  varying float vH;
  float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
  void main() {
    vec3 n = abs(vNormal);
    vec3 facade = vec3(0.035, 0.05, 0.075) * (0.55 + 0.6 * vRand);
    vec3 col = facade;
    if (n.y < 0.5) {
      // Window grid: 2.6 m bays, 3.3 m floors, measured in world space.
      vec2 uvw = (n.x > n.z) ? vec2(vWorld.z / 2.6, vWorld.y / 3.3) : vec2(vWorld.x / 2.6, vWorld.y / 3.3);
      vec2 cell = floor(uvw);
      vec2 f = fract(uvw);
      float pane = step(0.28, f.x) * step(f.x, 0.72) * step(0.22, f.y) * step(f.y, 0.72);
      float h = hash(cell + vRand * 97.0);
      float occupancy = 0.52 + 0.3 * sin(vRand * 23.0);
      float lit = step(occupancy, h);
      float flick = 0.86 + 0.14 * sin(uTime * (0.4 + h * 1.2) + h * 60.0);
      float tone = mix(0.55, 1.5, hash(cell.yx + vRand * 13.0));
      col += pane * lit * uWindow * tone * flick * 1.7;
      // soft façade glow near lit windows
      col += lit * uWindow * 0.05 * tone;
    } else {
      col = facade * 1.25;
    }
    // Ground haze darkens the lower floors.
    col *= 0.45 + 0.55 * smoothstep(0.0, 0.9, vH);
    float d = distance(vWorld, uCameraPos);
    float fog = 1.0 - exp(-pow(d * uFogDensity, 2.0));
    col = mix(col, uFogColor, fog);
    gl_FragColor = vec4(col, 1.0);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

const groundVert = /* glsl */ `
  varying vec3 vWorld;
  void main() {
    vec4 w = modelMatrix * vec4(position, 1.0);
    vWorld = w.xyz;
    gl_Position = projectionMatrix * viewMatrix * w;
  }
`;
const groundFrag = /* glsl */ `
  uniform vec3 uFogColor;
  uniform float uFogDensity;
  uniform vec3 uCameraPos;
  uniform vec3 uWindow;
  varying vec3 vWorld;
  float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
  void main() {
    vec3 col = vec3(0.012, 0.018, 0.03);
    // Street lamps along an avenue/street grid.
    vec2 g = vec2(vWorld.x / 62.0, vWorld.z / 108.0);
    vec2 f = abs(fract(g) - 0.5);
    float street = step(0.46, max(f.x, f.y));
    float dots = step(0.7, hash(floor(vec2(vWorld.x / 9.0, vWorld.z / 9.0))));
    col += street * dots * uWindow * 0.9;
    float d = distance(vWorld, uCameraPos);
    float fog = 1.0 - exp(-pow(d * uFogDensity, 2.0));
    col = mix(col, uFogColor, fog);
    gl_FragColor = vec4(col, 1.0);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

const skyVert = /* glsl */ `
  varying vec3 vDir;
  void main() {
    vDir = normalize(position);
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    gl_Position = projectionMatrix * mv;
    gl_Position.z = gl_Position.w; // always on the far plane
  }
`;
const skyFrag = /* glsl */ `
  uniform vec3 uTop;
  uniform vec3 uHorizon;
  uniform vec3 uGlow;
  uniform vec3 uFogColor;
  uniform float uReveal;
  varying vec3 vDir;
  float hash(vec3 p) { return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453); }
  void main() {
    float e = vDir.y;
    vec3 col = mix(uHorizon, uTop, smoothstep(-0.02, 0.5, e));
    col += uGlow * pow(1.0 - clamp(abs(e), 0.0, 1.0), 7.0) * 0.9;
    // Sparse stars high in the sky.
    vec3 cellp = floor(vDir * 420.0);
    float star = step(0.9992, hash(cellp)) * smoothstep(0.1, 0.5, e);
    col += vec3(0.8, 0.85, 1.0) * star * 0.6;
    col = mix(uFogColor, col, uReveal);
    gl_FragColor = vec4(col, 1.0);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

const beamVert = /* glsl */ `
  varying float vT;
  varying vec3 vWorld;
  void main() {
    vT = position.y / 380.0;
    vec4 w = modelMatrix * vec4(position, 1.0);
    vWorld = w.xyz;
    gl_Position = projectionMatrix * viewMatrix * w;
  }
`;
const beamFrag = /* glsl */ `
  uniform float uFogDensity;
  uniform vec3 uCameraPos;
  uniform float uReveal;
  varying float vT;
  varying vec3 vWorld;
  void main() {
    float d = distance(vWorld, uCameraPos);
    float fog = exp(-pow(d * uFogDensity, 2.0));
    float a = pow(1.0 - clamp(vT, 0.0, 1.0), 2.2) * 0.16 * fog * uReveal;
    gl_FragColor = vec4(vec3(1.0, 0.93, 0.78) * a, a);
  }
`;

const snowVert = /* glsl */ `
  attribute float aSize;
  uniform float uTime;
  uniform vec3 uCameraPos;
  uniform vec3 uBox;
  varying float vAlpha;
  void main() {
    vec3 p = position * uBox;
    p.y -= uTime * (2.2 + aSize * 1.6);
    p.x += uTime * 0.9 + sin(uTime * 0.6 + position.z * 25.0) * 1.5;
    p.z += cos(uTime * 0.45 + position.x * 19.0) * 1.2;
    vec3 rel = mod(p - uCameraPos + uBox * 0.5, uBox) - uBox * 0.5;
    vec3 world = uCameraPos + rel;
    vec4 mv = modelViewMatrix * vec4(world, 1.0);
    float d = max(-mv.z, 0.5);
    gl_PointSize = clamp(aSize * 170.0 / d, 1.0, 14.0);
    vec3 q = abs(rel) / (uBox * 0.5);
    vAlpha = (1.0 - smoothstep(0.6, 1.0, max(q.x, max(q.y, q.z)))) * smoothstep(0.5, 3.0, d);
    gl_Position = projectionMatrix * mv;
  }
`;
const snowFrag = /* glsl */ `
  uniform float uReveal;
  varying float vAlpha;
  void main() {
    vec2 c = gl_PointCoord - 0.5;
    float r = length(c);
    float a = smoothstep(0.5, 0.1, r) * vAlpha * uReveal * 0.7;
    if (a < 0.01) discard;
    gl_FragColor = vec4(vec3(0.95, 0.96, 1.0) * a, a);
  }
`;

export interface CityUniformState {
  time: number;
  cameraPos: THREE.Vector3;
  fogColor: THREE.Color;
  fogDensity: number;
  reveal: number;
}

export class City {
  readonly group = new THREE.Group();
  private readonly buildings: THREE.InstancedMesh;
  private readonly ground: THREE.Mesh;
  private readonly sky: THREE.Mesh;
  private readonly beams: THREE.Mesh[] = [];
  private readonly beamMat: THREE.ShaderMaterial;
  private readonly snow: THREE.Points;
  private readonly shared: { [k: string]: THREE.IUniform };

  constructor() {
    this.shared = {
      uFogColor: { value: new THREE.Color(PALETTE.deskFog) },
      uFogDensity: { value: 0.7 },
      uCameraPos: { value: new THREE.Vector3() },
      uTime: { value: 0 },
      uReveal: { value: 0 },
      uWindow: { value: new THREE.Color(PALETTE.window) },
    };
    const rnd = mulberry32(2024);
    const groundY = WORLD.cityGround;

    /* ---- buildings ----------------------------------------------------- */
    const specs: { x: number; z: number; w: number; d: number; h: number }[] = [];
    const spacing = 15;
    for (let gx = -52; gx <= 52; gx++) {
      for (let gz = -100; gz <= 42; gz++) {
        const x = gx * spacing + (rnd() - 0.5) * 5;
        const z = gz * spacing + (rnd() - 0.5) * 5;
        // Manhattan-like island, tapering towards the far end, rivers either side.
        const halfWidth = 300 + 90 * Math.sin(z * 0.0035 + 1.2) - Math.max(0, (-z - 1100) * 0.6);
        const onIsland = Math.abs(x) < halfWidth;
        const outer = Math.abs(x) > halfWidth + 140 && Math.abs(x) < 800;
        if (!onIsland && !outer) continue;
        if (rnd() > (onIsland ? 0.78 : 0.32)) continue;
        const down = Math.exp(-((z + 430) ** 2) / (2 * 150 ** 2) - (x ** 2) / (2 * 180 ** 2));
        const mid = Math.exp(-((z + 110) ** 2) / (2 * 220 ** 2) - (x ** 2) / (2 * 230 ** 2));
        let h = onIsland ? 12 + 28 * rnd() * rnd() + 120 * down * rnd() + 95 * mid * rnd() : 6 + 14 * rnd();
        if (onIsland && rnd() < 0.012) h *= 1.65; // the odd landmark tower
        const w = (onIsland ? 7 : 6) + rnd() * (onIsland ? 7 : 5);
        const d = (onIsland ? 7 : 6) + rnd() * (onIsland ? 7 : 5);
        specs.push({ x, z, w, d, h });
      }
    }
    const box = new THREE.BoxGeometry(1, 1, 1);
    box.translate(0, 0.5, 0);
    const rands = new Float32Array(specs.length);
    const mat = new THREE.ShaderMaterial({ vertexShader: buildingVert, fragmentShader: buildingFrag, uniforms: this.shared });
    this.buildings = new THREE.InstancedMesh(box, mat, specs.length);
    const m = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    specs.forEach((s, i) => {
      m.compose(new THREE.Vector3(s.x, groundY, s.z), q, new THREE.Vector3(s.w, s.h, s.d));
      this.buildings.setMatrixAt(i, m);
      rands[i] = rnd();
    });
    box.setAttribute("aRand", new THREE.InstancedBufferAttribute(rands, 1));
    this.buildings.instanceMatrix.needsUpdate = true;
    this.buildings.frustumCulled = false;
    this.group.add(this.buildings);

    /* ---- ground --------------------------------------------------------- */
    this.ground = new THREE.Mesh(
      new THREE.PlaneGeometry(6000, 6000),
      new THREE.ShaderMaterial({ vertexShader: groundVert, fragmentShader: groundFrag, uniforms: this.shared }),
    );
    this.ground.rotation.x = -Math.PI / 2;
    this.ground.position.y = groundY - 0.1;
    this.group.add(this.ground);

    /* ---- sky dome -------------------------------------------------------- */
    this.sky = new THREE.Mesh(
      new THREE.SphereGeometry(1, 32, 16),
      new THREE.ShaderMaterial({
        vertexShader: skyVert,
        fragmentShader: skyFrag,
        uniforms: {
          uTop: { value: new THREE.Color(PALETTE.skyTop) },
          uHorizon: { value: new THREE.Color(PALETTE.skyHorizon) },
          uGlow: { value: new THREE.Color(PALETTE.skyGlow) },
          uFogColor: this.shared.uFogColor,
          uReveal: this.shared.uReveal,
        },
        side: THREE.BackSide,
        depthWrite: false,
        depthTest: false,
      }),
    );
    this.sky.scale.setScalar(3000);
    this.sky.renderOrder = -10;
    this.sky.frustumCulled = false;
    this.group.add(this.sky);

    /* ---- searchlights ------------------------------------------------------ */
    this.beamMat = new THREE.ShaderMaterial({
      vertexShader: beamVert,
      fragmentShader: beamFrag,
      uniforms: this.shared,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    const beamGeo = new THREE.CylinderGeometry(34, 0.5, 380, 18, 1, true);
    beamGeo.translate(0, 190, 0);
    const beamSpots: [number, number, number][] = [
      [-130, groundY + 150, -420],
      [170, groundY + 120, -300],
      [-30, groundY + 95, -760],
    ];
    for (const [x, y, z] of beamSpots) {
      const pivot = new THREE.Group();
      pivot.position.set(x, y, z);
      const beam = new THREE.Mesh(beamGeo, this.beamMat);
      beam.rotation.x = THREE.MathUtils.degToRad(28);
      pivot.add(beam);
      this.group.add(pivot);
      this.beams.push(beam);
    }

    /* ---- snow ---------------------------------------------------------------- */
    const n = 2600;
    const pos = new Float32Array(n * 3);
    const size = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      pos[i * 3] = rnd();
      pos[i * 3 + 1] = rnd();
      pos[i * 3 + 2] = rnd();
      size[i] = 0.5 + rnd() * rnd() * 1.6;
    }
    const sg = new THREE.BufferGeometry();
    sg.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    sg.setAttribute("aSize", new THREE.BufferAttribute(size, 1));
    sg.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e6);
    this.snow = new THREE.Points(
      sg,
      new THREE.ShaderMaterial({
        vertexShader: snowVert,
        fragmentShader: snowFrag,
        uniforms: { uTime: this.shared.uTime, uCameraPos: this.shared.uCameraPos, uReveal: this.shared.uReveal, uBox: { value: new THREE.Vector3(90, 60, 90) } },
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      }),
    );
    this.snow.frustumCulled = false;
    this.snow.renderOrder = 15;
    this.group.add(this.snow);
  }

  update(s: CityUniformState) {
    this.shared.uTime.value = s.time;
    (this.shared.uCameraPos.value as THREE.Vector3).copy(s.cameraPos);
    (this.shared.uFogColor.value as THREE.Color).copy(s.fogColor);
    this.shared.uFogDensity.value = s.fogDensity;
    this.shared.uReveal.value = s.reveal;
    this.sky.position.copy(s.cameraPos);
    // Searchlights sweep slowly.
    this.beams.forEach((b, i) => {
      const parent = b.parent!;
      parent.rotation.y = Math.sin(s.time * (0.13 + i * 0.04) + i * 2.1) * 1.2 + i;
    });
    const far = s.reveal > 0.001;
    this.buildings.visible = far;
    this.ground.visible = far;
    this.snow.visible = far;
    this.beamMat.visible = far;
  }
}
