import * as THREE from "three";
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js";
import { WORLD } from "./config";
import { GlyphAtlas } from "./GlyphAtlas";
import { makeEnamelRoughness } from "./textures";

/**
 * Typewriter
 * ----------
 * A stylised 1920s desktop typewriter assembled from primitives:
 * enamel body, four stepped rows of glass keys with serif legends, a
 * semicircular type-bar basket, ribbon spools and a sliding carriage that
 * carries the platen and the manuscript sheet.
 *
 * `strike(char, phase)` animates the key + type bar for a keystroke;
 * `setCarriageX(x)` slides the carriage as the line is typed.
 */

const KEY_ROWS = ["ZXCVBNM,.?", "ASDFGHJKL;", "QWERTYUIOP", "1234567890"];
const KEY_PITCH = 0.019;
const KEY_ROW_Z = [0.118, 0.092, 0.066, 0.04];
const KEY_ROW_Y = [0.075, 0.083, 0.091, 0.099];
const KEY_ROW_SHIFT = [0.0, -0.007, 0.004, 0.012];
const PRESS_DEPTH = 0.0045;
const BAR_COUNT = 42;
const BAR_LENGTH = 0.07;
const BAR_RING_R = 0.06;
/** Offset of the segment ring centre from the printing point (below and in front). */
const BAR_RING_OFFSET = new THREE.Vector3(0, -0.032, 0.03);

const legendVert = /* glsl */ `
  attribute vec3 aPos;
  attribute vec2 aGlyph;
  attribute float aIndex;
  uniform float uSize;
  uniform vec2 uCellSize;
  uniform float uPressed;
  uniform float uPressDepth;
  varying vec2 vUv;
  void main() {
    vUv = aGlyph + uv * uCellSize;
    float dip = (abs(aIndex - uPressed) < 0.5) ? uPressDepth : 0.0;
    // quad lies flat (XZ plane) on the key top; +Z of the plane maps to -Z world (towards the back)
    vec3 p = aPos + vec3(position.x * uSize, -dip, -position.y * uSize);
    gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
  }
`;
const legendFrag = /* glsl */ `
  uniform sampler2D uAtlas;
  uniform float uOpacity;
  varying vec2 vUv;
  void main() {
    float a = texture2D(uAtlas, vUv).a;
    if (a < 0.02) discard;
    gl_FragColor = vec4(vec3(0.92, 0.88, 0.78), a * uOpacity);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

export class Typewriter {
  readonly group = new THREE.Group();
  readonly carriage = new THREE.Group();
  readonly materials: THREE.Material[] = [];
  /** World position of the printing point (where the type bars strike). */
  readonly printingPoint: THREE.Vector3;

  private keyCaps!: THREE.InstancedMesh;
  private keyRings!: THREE.InstancedMesh;
  private keyBase: THREE.Matrix4[] = [];
  private keyRingBase: THREE.Matrix4[] = [];
  private keyOfChar = new Map<string, number>();
  private legendMat!: THREE.ShaderMaterial;
  private spaceBar!: THREE.Mesh;
  private spaceBarY = 0;
  private bars!: THREE.InstancedMesh;
  private barPivot: THREE.Vector3[] = [];
  private barRadial: THREE.Vector3[] = [];
  private barOfChar = new Map<string, number>();
  private barNormal = new THREE.Vector3();
  private lastKey = -1;
  private lastBar = -1;

  constructor(legendAtlas: GlyphAtlas, envMap: THREE.Texture | null) {
    const [px, py, pz] = WORLD.platenCenter;
    this.printingPoint = new THREE.Vector3(px, py, pz + WORLD.platenRadius);

    const rough = makeEnamelRoughness();
    const enamel = new THREE.MeshStandardMaterial({ color: 0x0c0c0f, roughness: 0.95, metalness: 0.25, roughnessMap: rough, envMap, envMapIntensity: 0.9 });
    const chrome = new THREE.MeshStandardMaterial({ color: 0xd6d6da, roughness: 0.24, metalness: 1.0, envMap, envMapIntensity: 1.2 });
    const rubber = new THREE.MeshStandardMaterial({ color: 0x141313, roughness: 0.78, metalness: 0.0 });
    const steel = new THREE.MeshStandardMaterial({ color: 0x8e9196, roughness: 0.42, metalness: 0.95, envMap, envMapIntensity: 1.0 });
    const keyGlass = new THREE.MeshStandardMaterial({ color: 0x101114, roughness: 0.16, metalness: 0.15, envMap, envMapIntensity: 1.0 });
    const brass = new THREE.MeshStandardMaterial({ color: 0xb48f4c, roughness: 0.38, metalness: 0.95, envMap, envMapIntensity: 1.0 });
    const ribbon = new THREE.MeshStandardMaterial({ color: 0x2a0d10, roughness: 0.9, metalness: 0 });
    this.materials.push(enamel, chrome, rubber, steel, keyGlass, brass, ribbon);

    const add = (geo: THREE.BufferGeometry, mat: THREE.Material, pos: [number, number, number], parent: THREE.Object3D = this.group, rot?: THREE.Euler) => {
      const m = new THREE.Mesh(geo, mat);
      m.position.set(...pos);
      if (rot) m.rotation.copy(rot);
      m.castShadow = true;
      m.receiveShadow = true;
      parent.add(m);
      return m;
    };

    /* ---- body -------------------------------------------------------- */
    add(new RoundedBoxGeometry(0.37, 0.062, 0.31, 3, 0.012), enamel, [0, 0.031, 0.0]);
    add(new RoundedBoxGeometry(0.33, 0.085, 0.17, 3, 0.014), enamel, [0, 0.1, -0.08]);
    // side frames carrying the rails
    add(new RoundedBoxGeometry(0.03, 0.07, 0.11, 2, 0.006), enamel, [-0.165, 0.125, -0.13]);
    add(new RoundedBoxGeometry(0.03, 0.07, 0.11, 2, 0.006), enamel, [0.165, 0.125, -0.13]);
    // brass trim line on the front of the housing
    add(new THREE.BoxGeometry(0.26, 0.0025, 0.002), brass, [0, 0.128, 0.006]);
    // carriage rail
    add(new THREE.CylinderGeometry(0.0035, 0.0035, 0.42, 12), chrome, [0, 0.157, -0.1], this.group, new THREE.Euler(0, 0, Math.PI / 2));

    /* ---- ribbon spools ---------------------------------------------- */
    for (const sx of [-1, 1]) {
      add(new THREE.CylinderGeometry(0.026, 0.026, 0.011, 32), enamel, [sx * 0.105, 0.108, -0.03]);
      add(new THREE.CylinderGeometry(0.024, 0.024, 0.012, 32), ribbon, [sx * 0.105, 0.108, -0.03]);
      add(new THREE.CylinderGeometry(0.006, 0.006, 0.02, 16), chrome, [sx * 0.105, 0.115, -0.03]);
    }
    add(new THREE.BoxGeometry(0.21, 0.012, 0.0008), ribbon, [0, 0.112, -0.055]);
    // ribbon vibrator / type guide, just below the printing line
    add(new THREE.BoxGeometry(0.018, 0.012, 0.004), steel, [0, py - 0.011, pz + WORLD.platenRadius + 0.003]);

    /* ---- keys -------------------------------------------------------- */
    const keyCount = KEY_ROWS.reduce((n, r) => n + r.length, 0);
    const capGeo = new THREE.CylinderGeometry(0.0085, 0.0082, 0.004, 24);
    const ringGeo = new THREE.TorusGeometry(0.0085, 0.0011, 8, 32);
    ringGeo.rotateX(Math.PI / 2);
    const stemGeo = new THREE.CylinderGeometry(0.0018, 0.0018, 1, 8);
    this.keyCaps = new THREE.InstancedMesh(capGeo, keyGlass, keyCount);
    this.keyRings = new THREE.InstancedMesh(ringGeo, chrome, keyCount);
    const stems = new THREE.InstancedMesh(stemGeo, chrome, keyCount);
    this.keyCaps.castShadow = true;
    const legendPos: number[] = [];
    const legendGlyph: number[] = [];
    const legendIdx: number[] = [];
    const m = new THREE.Matrix4();
    let k = 0;
    KEY_ROWS.forEach((row, r) => {
      const x0 = -((row.length - 1) * KEY_PITCH) / 2 + KEY_ROW_SHIFT[r];
      for (let i = 0; i < row.length; i++) {
        const x = x0 + i * KEY_PITCH;
        const y = KEY_ROW_Y[r];
        const z = KEY_ROW_Z[r];
        m.makeTranslation(x, y, z);
        this.keyCaps.setMatrixAt(k, m);
        this.keyBase.push(m.clone());
        m.makeTranslation(x, y + 0.002, z);
        this.keyRings.setMatrixAt(k, m);
        this.keyRingBase.push(m.clone());
        const stemH = y - 0.06;
        m.compose(new THREE.Vector3(x, 0.06 + stemH / 2, z), new THREE.Quaternion(), new THREE.Vector3(1, stemH, 1));
        stems.setMatrixAt(k, m);
        legendPos.push(x, y + 0.0025, z);
        legendGlyph.push(...legendAtlas.cellOf(row[i]));
        legendIdx.push(k);
        this.keyOfChar.set(row[i].toLowerCase(), k);
        k++;
      }
    });
    this.group.add(this.keyCaps, this.keyRings, stems);

    // Legends: one instanced quad per key sampling the serif atlas.
    const lg = new THREE.InstancedBufferGeometry();
    const plane = new THREE.PlaneGeometry(1, 1);
    lg.index = plane.index;
    lg.setAttribute("position", plane.getAttribute("position"));
    lg.setAttribute("uv", plane.getAttribute("uv"));
    lg.setAttribute("aPos", new THREE.InstancedBufferAttribute(new Float32Array(legendPos), 3));
    lg.setAttribute("aGlyph", new THREE.InstancedBufferAttribute(new Float32Array(legendGlyph), 2));
    lg.setAttribute("aIndex", new THREE.InstancedBufferAttribute(new Float32Array(legendIdx), 1));
    lg.instanceCount = keyCount;
    this.legendMat = new THREE.ShaderMaterial({
      vertexShader: legendVert,
      fragmentShader: legendFrag,
      uniforms: {
        uAtlas: { value: legendAtlas.texture },
        uCellSize: { value: legendAtlas.cellSize },
        uSize: { value: 0.014 },
        uPressed: { value: -1 },
        uPressDepth: { value: PRESS_DEPTH },
        uOpacity: { value: 1 },
      },
      transparent: true,
      depthWrite: false,
    });
    const legends = new THREE.Mesh(lg, this.legendMat);
    legends.frustumCulled = false;
    legends.renderOrder = 5;
    this.group.add(legends);

    // Space bar
    this.spaceBar = add(new RoundedBoxGeometry(0.15, 0.006, 0.015, 2, 0.0025), keyGlass, [0, 0.07, 0.145]);
    this.spaceBarY = 0.07;
    this.keyOfChar.set(" ", -2);
    // Characters without a dedicated key fall back to a plausible neighbour.
    this.keyOfChar.set("'", this.keyOfChar.get("8")!);
    this.keyOfChar.set('"', this.keyOfChar.get("2")!);
    this.keyOfChar.set("-", this.keyOfChar.get("0")!);
    this.keyOfChar.set(":", this.keyOfChar.get(";")!);
    this.keyOfChar.set("!", this.keyOfChar.get("1")!);

    /* ---- type-bar basket ---------------------------------------------- */
    const X = new THREE.Vector3(1, 0, 0);
    const W = new THREE.Vector3(0, -0.6, 0.8).normalize(); // down-front: the segment ring lies in span(X, W)
    this.barNormal.crossVectors(X, W).normalize(); // down-back
    const barGeo = new THREE.BoxGeometry(0.0022, BAR_LENGTH, 0.0012);
    barGeo.translate(0, -BAR_LENGTH / 2, 0); // pivot at local origin, bar extends along -Y
    this.bars = new THREE.InstancedMesh(barGeo, steel, BAR_COUNT);
    this.bars.castShadow = true;
    const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890,.;?'-";
    const ringCentre = this.printingPoint.clone().add(BAR_RING_OFFSET);
    for (let i = 0; i < BAR_COUNT; i++) {
      const phi = THREE.MathUtils.degToRad(-80 + (160 * i) / (BAR_COUNT - 1));
      const radial = new THREE.Vector3().addScaledVector(W, Math.cos(phi)).addScaledVector(X, Math.sin(phi));
      const pivot = ringCentre.clone().addScaledVector(radial, BAR_RING_R);
      this.barPivot.push(pivot);
      this.barRadial.push(radial);
      // Interleave letters across the basket like a real segment.
      const ch = letters[(i * 17) % letters.length];
      if (!this.barOfChar.has(ch.toLowerCase())) this.barOfChar.set(ch.toLowerCase(), i);
      this.setBarPose(i, 0);
    }
    this.bars.instanceMatrix.needsUpdate = true;
    this.group.add(this.bars);
    // The segment (half ring the bars pivot on)
    const darkSteel = new THREE.MeshStandardMaterial({ color: 0x3c3e44, roughness: 0.55, metalness: 0.85 });
    this.materials.push(darkSteel);
    const seg = new THREE.Mesh(new THREE.TorusGeometry(BAR_RING_R, 0.0028, 8, 48, Math.PI), darkSteel);
    seg.position.copy(ringCentre);
    seg.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(X, W, this.barNormal));
    seg.castShadow = true;
    this.group.add(seg);

    /* ---- carriage ------------------------------------------------------ */
    this.group.add(this.carriage);
    // The rubber sits a paper-thickness inside the sheet's wrap radius.
    const pr = WORLD.platenRadius - 0.0006;
    const platen = add(new THREE.CylinderGeometry(pr, pr, 0.34, 64), rubber, [px, py, pz], this.carriage, new THREE.Euler(0, 0, Math.PI / 2));
    platen.castShadow = true;
    for (const sx of [-1, 1]) {
      add(new THREE.CylinderGeometry(0.0165, 0.0165, 0.024, 32), enamel, [sx * 0.185, py, pz], this.carriage, new THREE.Euler(0, 0, Math.PI / 2));
      add(new THREE.CylinderGeometry(0.0175, 0.0175, 0.004, 32), chrome, [sx * 0.174, py, pz], this.carriage, new THREE.Euler(0, 0, Math.PI / 2));
    }
    // carriage bed under the platen
    add(new RoundedBoxGeometry(0.38, 0.022, 0.07, 2, 0.005), enamel, [0, py - 0.028, pz + 0.01], this.carriage);
    // paper bail (thin chrome rod resting on the sheet)
    const bailA = THREE.MathUtils.degToRad(42);
    const bailPos: [number, number, number] = [0, py + Math.sin(bailA) * (WORLD.platenRadius + 0.0025), pz + Math.cos(bailA) * (WORLD.platenRadius + 0.0025)];
    add(new THREE.CylinderGeometry(0.0014, 0.0014, 0.3, 10), chrome, bailPos, this.carriage, new THREE.Euler(0, 0, Math.PI / 2));
    for (const sx of [-1, 1]) {
      add(new THREE.CylinderGeometry(0.004, 0.004, 0.012, 12), rubber, [sx * 0.07, bailPos[1], bailPos[2]], this.carriage, new THREE.Euler(0, 0, Math.PI / 2));
    }
    // paper table behind the sheet
    add(new THREE.BoxGeometry(0.3, 0.07, 0.0015), enamel, [0, py + 0.045, pz - 0.03], this.carriage, new THREE.Euler(THREE.MathUtils.degToRad(20), 0, 0));
    // carriage-return lever (left)
    add(new THREE.CylinderGeometry(0.0025, 0.0025, 0.075, 10), chrome, [-0.205, py + 0.01, pz + 0.02], this.carriage, new THREE.Euler(0, 0, THREE.MathUtils.degToRad(70)));
    add(new THREE.SphereGeometry(0.005, 12, 8), chrome, [-0.24, py + 0.022, pz + 0.02], this.carriage);

    this.group.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) {
        o.castShadow = true;
        o.receiveShadow = true;
      }
    });
  }

  /** The manuscript sheet mesh rides on the carriage. */
  attachSheet(mesh: THREE.Mesh) {
    this.carriage.add(mesh);
    const mat = mesh.material as THREE.Material;
    if (!this.materials.includes(mat)) this.materials.push(mat);
  }

  setCarriageX(x: number) {
    this.carriage.position.x = x;
  }

  /**
   * Animate a keystroke.
   * @param char  character being struck (null = release everything)
   * @param phase 0‥1 progress through the stroke
   */
  strike(char: string | null, phase: number) {
    const keyIdx = char === null ? -1 : (this.keyOfChar.get(char.toLowerCase()) ?? -1);
    const amount = Math.sin(Math.min(1, Math.max(0, phase)) * Math.PI);

    // restore previously pressed key
    if (this.lastKey >= 0 && this.lastKey !== keyIdx) this.setKeyDip(this.lastKey, 0);
    if (this.lastKey === -2 && keyIdx !== -2) this.spaceBar.position.y = this.spaceBarY;
    if (keyIdx === -2) this.spaceBar.position.y = this.spaceBarY - amount * PRESS_DEPTH * 0.7;
    else if (keyIdx >= 0) this.setKeyDip(keyIdx, amount);
    this.legendMat.uniforms.uPressed.value = keyIdx >= 0 ? keyIdx : -1;
    this.legendMat.uniforms.uPressDepth.value = amount * PRESS_DEPTH;
    this.lastKey = keyIdx;

    const barIdx = char === null || char === " " ? -1 : (this.barOfChar.get(char.toLowerCase()) ?? this.barOfChar.get("'")!);
    if (this.lastBar >= 0 && this.lastBar !== barIdx) this.setBarPose(this.lastBar, 0);
    if (barIdx >= 0) this.setBarPose(barIdx, amount);
    if (this.lastBar !== barIdx || barIdx >= 0) this.bars.instanceMatrix.needsUpdate = true;
    this.lastBar = barIdx;
  }

  private setKeyDip(i: number, amount: number) {
    const m = new THREE.Matrix4().copy(this.keyBase[i]);
    m.elements[13] -= amount * PRESS_DEPTH;
    this.keyCaps.setMatrixAt(i, m);
    m.copy(this.keyRingBase[i]);
    m.elements[13] -= amount * PRESS_DEPTH;
    this.keyRings.setMatrixAt(i, m);
    this.keyCaps.instanceMatrix.needsUpdate = true;
    this.keyRings.instanceMatrix.needsUpdate = true;
  }

  /** Bars rest folded down into the basket and swing up to the printing point when struck. */
  private setBarPose(i: number, strike: number) {
    const radial = this.barRadial[i];
    const toCentre = radial.clone().negate();
    const restAngle = THREE.MathUtils.degToRad(72);
    const angle = restAngle * (1 - strike) + THREE.MathUtils.degToRad(4) * strike;
    // direction from pivot to tip: rotate "toCentre" towards the basket normal
    const dir = new THREE.Vector3().addScaledVector(toCentre, Math.cos(angle)).addScaledVector(this.barNormal, Math.sin(angle)).normalize();
    const yAxis = dir.clone().negate(); // geometry extends along -Y
    const xAxis = new THREE.Vector3().crossVectors(yAxis, this.barNormal).normalize();
    if (xAxis.lengthSq() < 1e-6) xAxis.set(1, 0, 0);
    const zAxis = new THREE.Vector3().crossVectors(xAxis, yAxis).normalize();
    const m = new THREE.Matrix4().makeBasis(xAxis, yAxis, zAxis);
    m.setPosition(this.barPivot[i]);
    this.bars.setMatrixAt(i, m);
  }

  /** Fade the whole machine (used while the desk dissolves into the sky). */
  setOpacity(o: number) {
    const transparent = o < 0.999;
    for (const m of this.materials) {
      if (m.transparent !== transparent) {
        m.transparent = transparent;
        m.needsUpdate = true;
      }
      m.opacity = o;
    }
    this.legendMat.uniforms.uOpacity.value = o;
    this.group.visible = o > 0.002;
  }
}
