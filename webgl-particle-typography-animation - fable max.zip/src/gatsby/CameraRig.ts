import * as THREE from "three";
import { CameraFrame } from "./TextLayout";

/**
 * CameraRig
 * ---------
 * A tiny keyframe system. Each key stores the camera position, the point it
 * looks at, the field of view and (optionally) an explicit focus distance for
 * the glyph depth-of-field. Segments are interpolated linearly in space with
 * a per-segment easing curve, which keeps the motion predictable even though
 * the keys span five orders of magnitude (millimetres at the platen, tens of
 * metres above the city).
 */
export type Ease = "linear" | "in" | "out" | "inout";

export interface CameraKey {
  t: number;
  pos: [number, number, number];
  look: [number, number, number];
  fov: number;
  /** Explicit focus distance (defaults to |look - pos|). */
  focus?: number;
  /** Relative depth-of-field width (fraction of focus distance). */
  dof?: number;
  /** Easing used while travelling *towards* this key. */
  ease?: Ease;
}

export interface CameraSample extends CameraFrame {
  fov: number;
  focusDist: number;
  focusRange: number;
  look: THREE.Vector3;
}

function applyEase(s: number, ease: Ease): number {
  switch (ease) {
    case "linear":
      return s;
    case "in":
      return s * s * s;
    case "out":
      return 1 - Math.pow(1 - s, 3);
    default:
      return s * s * (3 - 2 * s);
  }
}

/** Printing point of the typewriter in world space (typewriter sits at z = -0.22). */
const PP: [number, number, number] = [0, 0.185, -0.338];

/** The shot list. */
export const CAMERA_KEYS: CameraKey[] = [
  // 1. Close on the platen: we watch the final line being struck onto the sheet.
  { t: 0.0, pos: [0.115, 0.265, -0.15], look: [-0.01, 0.19, PP[2]], fov: 38, dof: 0.5 },
  { t: 5.8, pos: [0.075, 0.275, -0.1], look: [-0.005, 0.185, PP[2]], fov: 38, dof: 0.5, ease: "inout" },
  // 2. Tilt down over the scattered manuscript pages – the lift-off begins.
  { t: 8.6, pos: [0.06, 0.74, 0.66], look: [0.0, 0.02, -0.04], fov: 44, dof: 0.6, ease: "inout" },
  // 3. The desk dissolves; we climb into the night above the city.
  { t: 14.2, pos: [0.0, 30.0, 20.0], look: [0.0, 27.5, -20.0], fov: 46, focus: 18, dof: 0.35, ease: "inout" },
  // 4. Hold with a slow lateral drift for parallax while the quote is read.
  { t: 26.0, pos: [3.2, 29.4, 20.8], look: [0.6, 27.6, -20.0], fov: 46, focus: 18, dof: 0.35, ease: "linear" },
];

export class CameraRig {
  private readonly keys: CameraKey[];
  private readonly a = new THREE.Vector3();
  private readonly b = new THREE.Vector3();
  private readonly m = new THREE.Matrix4();

  constructor(keys: CameraKey[] = CAMERA_KEYS) {
    this.keys = keys;
  }

  /** Sample the rig at time `t` (seconds). */
  sample(t: number, out: CameraSample = CameraRig.newSample()): CameraSample {
    const keys = this.keys;
    let i = 0;
    while (i < keys.length - 2 && t >= keys[i + 1].t) i++;
    const k0 = keys[i];
    const k1 = keys[i + 1];
    const raw = THREE.MathUtils.clamp((t - k0.t) / Math.max(1e-6, k1.t - k0.t), 0, 1);
    const s = applyEase(raw, k1.ease ?? "inout");

    out.position.set(...k0.pos).lerp(this.b.set(...k1.pos), s);
    out.look.set(...k0.look).lerp(this.b.set(...k1.look), s);
    out.fov = THREE.MathUtils.lerp(k0.fov, k1.fov, s);
    const f0 = k0.focus ?? this.a.set(...k0.pos).distanceTo(this.b.set(...k0.look));
    const f1 = k1.focus ?? this.a.set(...k1.pos).distanceTo(this.b.set(...k1.look));
    out.focusDist = THREE.MathUtils.lerp(f0, f1, s);
    out.focusRange = out.focusDist * THREE.MathUtils.lerp(k0.dof ?? 0.4, k1.dof ?? 0.4, s) + 0.02;

    this.m.lookAt(out.position, out.look, THREE.Object3D.DEFAULT_UP);
    out.quaternion.setFromRotationMatrix(this.m);
    return out;
  }

  /** CameraSampler-compatible helper used while baking chaff targets. */
  frameAt(t: number, out: CameraFrame): CameraFrame {
    const s = this.sample(t);
    out.position.copy(s.position);
    out.quaternion.copy(s.quaternion);
    return out;
  }

  static newSample(): CameraSample {
    return {
      position: new THREE.Vector3(),
      quaternion: new THREE.Quaternion(),
      look: new THREE.Vector3(),
      fov: 40,
      focusDist: 1,
      focusRange: 0.5,
    };
  }
}
