import * as THREE from "three";
import { FormationLine, TYPE } from "./config";
import { normalizeChar, mulberry32 } from "./GlyphAtlas";
import { PaperSurface, newPose } from "./PaperSurface";

/* ------------------------------------------------------------------ */
/*  Data model                                                         */
/* ------------------------------------------------------------------ */

/**
 * A glyph as it physically exists on a sheet of paper.
 * `position`/`quaternion` are derived from `surface.poseAt(u, v)` – i.e.
 * every glyph is pinned to a real coordinate on a rendered paper mesh.
 */
export interface SourceGlyph {
  id: number;
  char: string;
  surfaceId: number;
  line: number;
  col: number;
  /** Paper coordinates (0‥1). */
  u: number;
  v: number;
  position: THREE.Vector3;
  quaternion: THREE.Quaternion;
  /** Quad side length in world units. */
  size: number;
  /** Second at which the typewriter strikes this glyph (-1 = already on the page). */
  typedAt: number;
  /** Rides on the carriage (needs the live carriage offset). */
  onCarriage: boolean;
}

/** One character cell in the floating quote formation. */
export interface TargetSlot {
  id: number;
  char: string;
  line: number;
  word: number;
  /** Index of this character within its word. */
  charInWord: number;
  position: THREE.Vector3;
  quaternion: THREE.Quaternion;
  size: number;
  /** Second at which the glyph must be locked in place. */
  arrival: number;
  source: FormationLine["source"];
}

/* ------------------------------------------------------------------ */
/*  Manuscript wrapping                                                */
/* ------------------------------------------------------------------ */

/** Greedy word wrap with a 5-space paragraph indent and a blank line between paragraphs. */
export function wrapParagraphs(paragraphs: string[], columns = TYPE.columns): string[] {
  const lines: string[] = [];
  for (const para of paragraphs) {
    let line = "     ";
    for (const word of para.split(/\s+/)) {
      if (line.trim().length === 0) {
        line += word;
      } else if (line.length + 1 + word.length <= columns) {
        line += " " + word;
      } else {
        lines.push(line);
        line = word;
      }
    }
    if (line.trim().length) lines.push(line);
    lines.push("");
  }
  if (lines[lines.length - 1] === "") lines.pop();
  return lines;
}

/* ------------------------------------------------------------------ */
/*  Layout onto a paper surface                                        */
/* ------------------------------------------------------------------ */

export interface LayoutOptions {
  /** Time of the first strike for lines in `typedLines` (others get typedAt = -1). */
  typingStart?: number;
  typingInterval?: number;
  /** Line indices that are typed live. */
  typedLines?: Set<number>;
  seed?: number;
}

const _q = new THREE.Quaternion();
const _axisZ = new THREE.Vector3(0, 0, 1);
const _up = new THREE.Vector3();

/**
 * Place monospace lines on a paper surface at 10 cpi / 6 lpi.
 * Returns one SourceGlyph per non-space character.
 */
export function layoutOnSurface(
  surface: PaperSurface,
  lines: string[],
  nextId: () => number,
  opts: LayoutOptions = {},
): SourceGlyph[] {
  const out: SourceGlyph[] = [];
  const rnd = mulberry32(opts.seed ?? surface.id * 7919 + 13);
  const pose = newPose();
  const size = TYPE.lineHeight * TYPE.quadScale;
  let strike = 0;

  lines.forEach((text, line) => {
    const typed = opts.typedLines?.has(line) ?? false;
    for (let col = 0; col < text.length && col < TYPE.columns; col++) {
      const raw = text[col];
      if (raw === " ") {
        if (typed) strike++;
        continue;
      }
      const char = normalizeChar(raw);
      const u = (TYPE.marginLeft + (col + 0.5) * TYPE.cellWidth) / surface.width;
      const v = (TYPE.marginTop + (line + 0.5) * TYPE.lineHeight) / surface.height;
      surface.poseAt(u, v, pose);

      // Typewriter imperfections: baseline wobble and a hair of rotation.
      const wobble = (rnd() - 0.5) * 0.12 * TYPE.lineHeight;
      _up.set(0, 1, 0).applyQuaternion(pose.quaternion);
      const position = pose.position.clone().addScaledVector(_up, wobble);
      const quaternion = pose.quaternion.clone().multiply(_q.setFromAxisAngle(_axisZ, (rnd() - 0.5) * 0.04));

      const typedAt = typed ? (opts.typingStart ?? 0) + strike * (opts.typingInterval ?? 0.1) : -1;
      if (typed) strike++;

      out.push({
        id: nextId(),
        char,
        surfaceId: surface.id,
        line,
        col,
        u,
        v,
        position,
        quaternion,
        size,
        typedAt,
        onCarriage: surface.onCarriage,
      });
    }
  });
  return out;
}

/* ------------------------------------------------------------------ */
/*  Floating quote formation                                           */
/* ------------------------------------------------------------------ */

export interface CameraFrame {
  position: THREE.Vector3;
  quaternion: THREE.Quaternion;
}

/**
 * Lay the quote out in the frame of the (settled) camera so the words face
 * the viewer. Each line has its own offset/depth; words get a little extra
 * depth jitter for parallax while the camera drifts.
 *
 * @param distance distance from the camera to the formation centre
 */
export function layoutFormation(lines: FormationLine[], camera: CameraFrame, distance: number, nextId: () => number): TargetSlot[] {
  const right = new THREE.Vector3(1, 0, 0).applyQuaternion(camera.quaternion);
  const up = new THREE.Vector3(0, 1, 0).applyQuaternion(camera.quaternion);
  const forward = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion);
  const centre = camera.position.clone().addScaledVector(forward, distance);
  // Glyph quads face the camera: local +Z = towards the viewer.
  const facing = new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(right, up, forward.clone().negate()));
  const rnd = mulberry32(4242);
  const slots: TargetSlot[] = [];

  lines.forEach((line, li) => {
    // Same proportions as the page: advance = 0.6 em, quad side = 1.25 em.
    const advance = (0.6 / TYPE.quadScale) * line.size;
    const width = line.text.length * advance;
    let word = 0;
    let charInWord = 0;
    let wordDepth = (rnd() - 0.5) * 0.9;
    let wordLift = (rnd() - 0.5) * 0.08 * line.size;

    for (let col = 0; col < line.text.length; col++) {
      const ch = line.text[col];
      if (ch === " ") {
        word++;
        charInWord = 0;
        wordDepth = (rnd() - 0.5) * 0.9;
        wordLift = (rnd() - 0.5) * 0.08 * line.size;
        continue;
      }
      const x = -width / 2 + (col + 0.5) * advance + line.offset[0];
      const y = line.offset[1] + wordLift;
      const z = line.offset[2] + wordDepth;
      const position = centre
        .clone()
        .addScaledVector(right, x)
        .addScaledVector(up, y)
        .addScaledVector(forward, -z);
      const quaternion = facing.clone().multiply(_q.setFromAxisAngle(_axisZ, (rnd() - 0.5) * 0.03));
      slots.push({
        id: nextId(),
        char: normalizeChar(ch),
        line: li,
        word,
        charInWord,
        position,
        quaternion,
        size: line.size,
        arrival: line.arrival + word * line.wordStagger + charInWord * 0.045,
        source: line.source,
      });
      charInWord++;
    }
  });
  return slots;
}
