import * as THREE from "three";
import { makePaperTexture, makeWoodTexture } from "./textures";

/**
 * Desk
 * ----
 * The physical setting the manuscript lives in: a walnut desk lit by a warm
 * lamp from the upper left, a cool moonlit fill from the window side, and a
 * few props. Everything here dissolves when the camera climbs into the sky.
 */
export class Desk {
  readonly group = new THREE.Group();
  readonly materials: THREE.Material[] = [];
  readonly lamp: THREE.SpotLight;
  readonly fill: THREE.PointLight;
  readonly hemi: THREE.HemisphereLight;

  constructor() {
    const wood = makeWoodTexture();
    wood.repeat.set(1.4, 1);
    const deskMat = new THREE.MeshStandardMaterial({ map: wood, roughness: 0.52, metalness: 0.05, color: 0xb9a48a });
    const desk = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.05, 1.7), deskMat);
    desk.position.set(0, -0.025, -0.1);
    desk.receiveShadow = true;
    desk.castShadow = false;
    this.group.add(desk);
    this.materials.push(deskMat);

    // Stack of fresh sheets on the right
    const stackTex = makePaperTexture({ seed: 77, age: 0.25 });
    const stackMat = new THREE.MeshStandardMaterial({ map: stackTex, roughness: 0.9 });
    const stackSide = new THREE.MeshStandardMaterial({ color: 0xcdbf9f, roughness: 0.95 });
    const stack = new THREE.Mesh(new THREE.BoxGeometry(0.216, 0.014, 0.279), [stackSide, stackSide, stackMat, stackSide, stackSide, stackSide]);
    stack.position.set(0.47, 0.007, -0.3);
    stack.rotation.y = 0.12;
    stack.castShadow = true;
    stack.receiveShadow = true;
    this.group.add(stack);
    this.materials.push(stackMat, stackSide);

    // Fountain pen lying across a page
    const penBody = new THREE.MeshStandardMaterial({ color: 0x0b0a0c, roughness: 0.25, metalness: 0.2 });
    const brass = new THREE.MeshStandardMaterial({ color: 0xb58d47, roughness: 0.35, metalness: 0.95 });
    const pen = new THREE.Group();
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.0055, 0.0055, 0.125, 16), penBody);
    const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.05, 16), penBody);
    cap.position.y = 0.06;
    const band = new THREE.Mesh(new THREE.CylinderGeometry(0.0063, 0.0063, 0.004, 16), brass);
    band.position.y = 0.034;
    const clip = new THREE.Mesh(new THREE.BoxGeometry(0.002, 0.03, 0.0015), brass);
    clip.position.set(0, 0.065, 0.0062);
    const nib = new THREE.Mesh(new THREE.ConeGeometry(0.0045, 0.018, 12), brass);
    nib.position.y = -0.07;
    nib.rotation.x = Math.PI;
    pen.add(body, cap, band, clip, nib);
    pen.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) {
        o.castShadow = true;
        o.receiveShadow = true;
      }
    });
    pen.position.set(0.05, 0.0075, 0.3);
    pen.rotation.set(0, 0.45, Math.PI / 2);
    this.group.add(pen);
    this.materials.push(penBody, brass);

    /* ---- lighting ---------------------------------------------------- */
    this.lamp = new THREE.SpotLight(0xffc38a, 3.4, 0, 0.62, 0.75, 2);
    this.lamp.position.set(-0.6, 1.0, 0.35);
    this.lamp.target.position.set(0.05, 0, -0.05);
    this.lamp.castShadow = true;
    this.lamp.shadow.mapSize.set(2048, 2048);
    this.lamp.shadow.camera.near = 0.3;
    this.lamp.shadow.camera.far = 3.5;
    this.lamp.shadow.bias = -0.00015;
    this.lamp.shadow.normalBias = 0.002;
    this.lamp.shadow.radius = 3;
    this.group.add(this.lamp, this.lamp.target);

    this.fill = new THREE.PointLight(0x5f7fb0, 0.45, 0, 2);
    this.fill.position.set(0.9, 0.55, -0.7);
    this.group.add(this.fill);

    this.hemi = new THREE.HemisphereLight(0x3a2c22, 0x070605, 0.25);
    this.group.add(this.hemi);
  }

  /** Dissolve the desk while the camera climbs. */
  setOpacity(o: number) {
    const transparent = o < 0.999;
    for (const m of this.materials) {
      if (m.transparent !== transparent) {
        m.transparent = transparent;
        m.needsUpdate = true;
      }
      m.opacity = o;
    }
    this.lamp.intensity = 3.4 * o;
    this.fill.intensity = 0.45 * o;
    this.group.visible = o > 0.002;
  }
}
