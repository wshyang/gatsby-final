import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { CameraRig } from "./CameraRig";
import { City } from "./City";
import { FORMATION, PAGE_TEXTS, PALETTE, SHEET_TEXT, TIMELINE, TYPE, TYPED_LINE } from "./config";
import { Desk } from "./Desk";
import { ASCII_PRINTABLE, GlyphAtlas, waitForFont } from "./GlyphAtlas";
import { GlyphParticles } from "./GlyphParticles";
import { assignSlots, buildParticleBuffers, emptyStats, MappingStats } from "./Mapping";
import { createFlatPages, PaperSurface, PlatenSheet } from "./PaperSurface";
import { PostFX } from "./PostFX";
import { layoutFormation, layoutOnSurface, SourceGlyph, TargetSlot, wrapParagraphs } from "./TextLayout";
import { makePaperTexture } from "./textures";
import { Typewriter } from "./Typewriter";

/**
 * GatsbyScene
 * -----------
 * Builds the world and drives it from a single clock.
 *
 *   build:  paper surfaces → text layout (SourceGlyph) → quote layout (TargetSlot)
 *           → assignment → instance buffers → one instanced draw call
 *   frame:  t → camera rig, fog/reveal ramps, typing state, shader uniforms
 */

export interface SceneStats extends MappingStats {
  slots: number;
  pages: number;
  fontUsed: string;
}

export interface SceneCallbacks {
  onTime?: (t: number) => void;
  onReady?: (stats: SceneStats) => void;
}

export const PHASES: { from: number; name: string; blurb: string }[] = [
  { from: 0, name: "The source", blurb: "The last line of the manuscript is struck onto the sheet." },
  { from: TIMELINE.memberLiftStart, name: "Lift-off", blurb: "Characters peel away from the paper along its surface normal." },
  { from: TIMELINE.deskFade[0], name: "Ascent", blurb: "The desk dissolves; the swarm streams past the camera above the city." },
  { from: TIMELINE.firstArrival, name: "Assembly", blurb: "Letters tumble a whole number of turns and lock into the quote." },
  { from: FORMATION[FORMATION.length - 1].arrival + 1.5, name: "Hold", blurb: "The words float in depth; the camera drifts for parallax." },
  { from: TIMELINE.dissolve[0], name: "Dissolve", blurb: "The quote drifts away into the snow." },
];

export function phaseAt(t: number) {
  let p = PHASES[0];
  for (const ph of PHASES) if (t >= ph.from) p = ph;
  return p;
}

const smooth = (a: number, b: number, x: number) => {
  const s = THREE.MathUtils.clamp((x - a) / (b - a), 0, 1);
  return s * s * (3 - 2 * s);
};

export class GatsbyScene {
  readonly renderer: THREE.WebGLRenderer;
  readonly scene = new THREE.Scene();
  readonly camera: THREE.PerspectiveCamera;
  readonly rig = new CameraRig();

  time = 0;
  playing = true;
  speed = 1;
  loop = true;

  private desk!: Desk;
  private typewriter!: Typewriter;
  private surfaces: PaperSurface[] = [];
  private particles!: GlyphParticles;
  private city!: City;
  private post!: PostFX;
  private typingEvents: { time: number; char: string }[] = [];
  private raf = 0;
  private lastStamp = 0;
  private lastReported = -1;
  private ready = false;
  private disposed = false;
  private readonly sample = CameraRig.newSample();
  private readonly fogColor = new THREE.Color();
  private readonly deskFog = new THREE.Color(PALETTE.deskFog);
  private readonly cityFog = new THREE.Color(PALETTE.cityFog);
  private readonly callbacks: SceneCallbacks;
  private readonly canvas: HTMLCanvasElement;

  constructor(canvas: HTMLCanvasElement, callbacks: SceneCallbacks = {}) {
    this.canvas = canvas;
    this.callbacks = callbacks;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.0;
    this.camera = new THREE.PerspectiveCamera(38, 1, 0.02, 6000);
  }

  /* ------------------------------------------------------------------ */
  /*  Build                                                             */
  /* ------------------------------------------------------------------ */
  async init() {
    const fontOk = await waitForFont("Special Elite");
    if (this.disposed) return;

    // Atlases ---------------------------------------------------------
    const typeAtlas = new GlyphAtlas({
      chars: ASCII_PRINTABLE,
      cell: 128,
      cols: 16,
      family: `"Special Elite", "Courier Prime", "Courier New", Courier, monospace`,
      emScale: 1 / TYPE.quadScale,
      baselineShift: 0.22,
      distress: true,
      seed: 7,
    });
    const legendAtlas = new GlyphAtlas({
      chars: "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890,.?;:'\"-!",
      cell: 64,
      cols: 8,
      family: `Georgia, "Times New Roman", serif`,
      emScale: 0.62,
      baselineShift: 0.34,
      distress: false,
    });

    // Environment ----------------------------------------------------------
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    this.scene.environmentIntensity = 0.12;
    pmrem.dispose();

    // Desk + typewriter -------------------------------------------------------
    this.desk = new Desk();
    this.scene.add(this.desk.group);
    this.typewriter = new Typewriter(legendAtlas, null);
    this.typewriter.group.position.set(0, 0, -0.22);
    this.typewriter.group.updateMatrixWorld(true);
    this.desk.group.add(this.typewriter.group);

    // Paper surfaces ---------------------------------------------------------
    let surfaceId = 0;
    const pages = createFlatPages(surfaceId);
    surfaceId += pages.length;
    for (const p of pages) this.desk.group.add(p.mesh);

    const sheetLines = [...wrapParagraphs(SHEET_TEXT), "", TYPED_LINE];
    const typedLineIndex = sheetLines.length - 1;
    const sheet = new PlatenSheet(surfaceId++, this.typewriter.group.matrixWorld, sheetLines.length, pageTexture());
    this.typewriter.attachSheet(sheet.mesh);
    this.surfaces = [...pages, sheet];

    // Text layout: glyphs pinned to paper coordinates ---------------------------
    let glyphId = 0;
    const nextId = () => glyphId++;
    const sources: SourceGlyph[] = [];
    pages.forEach((page, i) => {
      sources.push(...layoutOnSurface(page, wrapParagraphs(PAGE_TEXTS[i % PAGE_TEXTS.length]), nextId, { seed: 31 + i }));
    });
    const sheetGlyphs = layoutOnSurface(sheet, sheetLines, nextId, {
      typedLines: new Set([typedLineIndex]),
      typingStart: TIMELINE.typingStart,
      typingInterval: TIMELINE.typingInterval,
      seed: 99,
    });
    sources.push(...sheetGlyphs);
    const typedGlyphs = sheetGlyphs.filter((g) => g.line === typedLineIndex);
    this.typingEvents = Array.from(TYPED_LINE).map((char, i) => ({ char, time: TIMELINE.typingStart + i * TIMELINE.typingInterval }));

    // Quote layout in the settled camera's frame -------------------------------
    const holdFrame = this.rig.sample(TIMELINE.firstArrival + 2);
    let slotId = 0;
    const slots: TargetSlot[] = layoutFormation(FORMATION, holdFrame, 18, () => slotId++);

    // Mapping + GPU buffers -------------------------------------------------------
    const stats = emptyStats();
    const assignments = assignSlots(sources, slots, typedGlyphs, stats);
    const buffers = buildParticleBuffers(sources, assignments, typeAtlas, (t, out) => this.rig.frameAt(t, out), stats);
    this.particles = new GlyphParticles(buffers, typeAtlas);
    this.scene.add(this.particles.mesh, this.particles.links);

    // City + post ---------------------------------------------------------------------
    this.city = new City();
    this.scene.add(this.city.group);
    const { width, height } = this.size();
    this.post = new PostFX(this.renderer, this.scene, this.camera, width, height);

    this.ready = true;
    this.resize();
    this.callbacks.onReady?.({
      ...stats,
      slots: slots.length,
      pages: this.surfaces.length,
      fontUsed: fontOk ? "Special Elite" : "Courier (fallback)",
    });
    this.start();
  }

  /* ------------------------------------------------------------------ */
  /*  Per-frame state                                                   */
  /* ------------------------------------------------------------------ */
  setTime(t: number) {
    this.time = THREE.MathUtils.clamp(t, 0, TIMELINE.duration);
    this.apply(this.time);
  }

  private apply(t: number) {
    if (!this.ready) return;

    // Camera ------------------------------------------------------------
    const cam = this.rig.sample(t, this.sample);
    this.camera.position.copy(cam.position);
    this.camera.quaternion.copy(cam.quaternion);
    if (Math.abs(this.camera.fov - cam.fov) > 1e-3) {
      this.camera.fov = cam.fov;
      this.camera.updateProjectionMatrix();
    }

    // Atmosphere ramps ----------------------------------------------------
    const reveal = smooth(TIMELINE.cityReveal[0], TIMELINE.cityReveal[1], t);
    const fogDensity = Math.exp(THREE.MathUtils.lerp(Math.log(0.8), Math.log(0.0031), reveal));
    this.fogColor.copy(this.deskFog).lerp(this.cityFog, reveal);
    const deskFade = 1 - smooth(TIMELINE.deskFade[0], TIMELINE.deskFade[1], t);
    const dissolve = smooth(TIMELINE.dissolve[0], TIMELINE.dissolve[1], t);
    const fade = smooth(TIMELINE.fadeIn[0], TIMELINE.fadeIn[1], t) * (1 - smooth(TIMELINE.fadeOut[0], TIMELINE.fadeOut[1], t));

    // Typing -------------------------------------------------------------------
    const carriageX = this.carriageXAt(t);
    this.typewriter.setCarriageX(carriageX);
    let active: { time: number; char: string } | null = null;
    for (const ev of this.typingEvents) {
      if (t >= ev.time && t - ev.time < 0.09) active = ev;
    }
    this.typewriter.strike(active ? active.char : null, active ? (t - active.time) / 0.09 : 0);

    // Desk dissolve ----------------------------------------------------------------
    this.desk.setOpacity(deskFade);
    this.typewriter.setOpacity(deskFade);
    for (const s of this.surfaces) {
      const m = s.mesh.material as THREE.MeshStandardMaterial;
      const transparent = deskFade < 0.999;
      if (m.transparent !== transparent) {
        m.transparent = transparent;
        m.needsUpdate = true;
      }
      m.opacity = deskFade;
    }

    // Shaders ---------------------------------------------------------------------------
    this.particles.update({
      time: t,
      carriageX,
      focusDist: cam.focusDist,
      focusRange: cam.focusRange,
      deskFade,
      dissolve,
      fogDensity,
      fogColor: this.fogColor,
      opacity: 1,
    });
    this.city.update({ time: t, cameraPos: this.camera.position, fogColor: this.fogColor, fogDensity, reveal });
    this.renderer.setClearColor(this.fogColor, 1);
    this.post.update(t, fade);
  }

  /** Carriage offset so the next column to be typed sits under the type guide. */
  private carriageXAt(t: number): number {
    const xOf = (col: number) => -(TYPE.marginLeft + (col + 0.5) * TYPE.cellWidth - TYPE.pageWidth / 2);
    let k = -1;
    for (let i = 0; i < this.typingEvents.length; i++) if (this.typingEvents[i].time <= t) k = i;
    if (k < 0) return xOf(0);
    const since = t - this.typingEvents[k].time;
    const step = smooth(0.012, 0.06, since);
    return THREE.MathUtils.lerp(xOf(k), xOf(k + 1), step);
  }

  /* ------------------------------------------------------------------ */
  /*  Loop / lifecycle                                                  */
  /* ------------------------------------------------------------------ */
  start() {
    cancelAnimationFrame(this.raf);
    this.lastStamp = performance.now();
    const tick = (now: number) => {
      if (this.disposed) return;
      this.raf = requestAnimationFrame(tick);
      const dt = Math.min(0.1, (now - this.lastStamp) / 1000);
      this.lastStamp = now;
      if (this.playing) {
        this.time += dt * this.speed;
        if (this.time >= TIMELINE.duration) this.time = this.loop ? 0 : TIMELINE.duration;
      }
      this.apply(this.time);
      this.post.render();
      if (Math.abs(this.time - this.lastReported) > 0.08) {
        this.lastReported = this.time;
        this.callbacks.onTime?.(this.time);
      }
    };
    this.raf = requestAnimationFrame(tick);
  }

  setShowMapping(show: boolean) {
    if (this.particles) this.particles.links.visible = show;
  }

  private size() {
    const parent = this.canvas.parentElement;
    return { width: parent?.clientWidth || window.innerWidth, height: parent?.clientHeight || window.innerHeight };
  }

  resize() {
    const { width, height } = this.size();
    this.renderer.setSize(width, height, false);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.post?.setSize(width, height, this.renderer.getPixelRatio());
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.particles?.dispose();
    this.post?.dispose();
    this.scene.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (mesh.geometry) mesh.geometry.dispose();
      const mat = mesh.material as THREE.Material | THREE.Material[] | undefined;
      if (Array.isArray(mat)) mat.forEach((m) => m.dispose());
      else mat?.dispose();
    });
    this.renderer.dispose();
  }
}

/** Fresh sheet currently in the machine. */
function pageTexture() {
  return makePaperTexture({ seed: 500, age: 0.3 });
}
