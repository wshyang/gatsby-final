import * as THREE from "three";
import { TIMELINE } from "./config";
import { GlyphAtlas, mulberry32 } from "./GlyphAtlas";
import { CameraFrame, SourceGlyph, TargetSlot } from "./TextLayout";

/**
 * Mapping
 * -------
 * Connects glyphs that physically exist on paper (SourceGlyph) with cells of
 * the floating quote (TargetSlot) and bakes the result into per-instance GPU
 * attributes.
 *
 *   paper surface ──poseAt(u,v)──▶ SourceGlyph ──assignment──▶ TargetSlot
 *                                      │                           │
 *                                  aOrigin/aOriginQuat        aTarget/aTargetQuat
 *
 * Every particle therefore has a provable origin on a paper mesh; nothing is
 * ever emitted from empty space.
 *
 * Particle "kinds" (aTiming.w):
 *   1  member : flies from its paper origin to a quote slot and locks in
 *   0  chaff  : lifts off, swirls past the camera and fades out
 *  -1  stays  : remains printed on the page and dissolves with the desk
 */

export const KIND_STAY = -1;
export const KIND_CHAFF = 0;
export const KIND_MEMBER = 1;

export interface Assignment {
  slot: TargetSlot;
  source: SourceGlyph;
  liftTime: number;
}

export interface MappingStats {
  sources: number;
  members: number;
  chaff: number;
  stays: number;
  identityMapped: number;
  searchMapped: number;
  fallbackClones: number;
}

export type CameraSampler = (t: number, out: CameraFrame) => CameraFrame;

/* ------------------------------------------------------------------ */
/*  1. Assignment                                                      */
/* ------------------------------------------------------------------ */

/**
 * Decide which paper glyph travels to which quote slot.
 *
 * - "typed"  slots consume the live-typed line in column order (identity).
 * - "pages"  slots harvest glyphs from the scattered pages. For each word a
 *            random "harvest seed" is chosen on the pages and every letter of
 *            the word is taken from the nearest unused glyph with the same
 *            character, so the letters of one word lift off from the same
 *            neighbourhood and travel together as a readable swarm.
 */
export function assignSlots(
  sources: SourceGlyph[],
  slots: TargetSlot[],
  typedGlyphs: SourceGlyph[],
  stats: MappingStats,
  seed = 99,
): Assignment[] {
  const rnd = mulberry32(seed);
  const used = new Set<number>();
  const assignments: Assignment[] = [];

  // Index pages glyphs by character for fast matching (sheet glyphs excluded:
  // the sheet is the typed page, we harvest only from the scattered pages).
  const typedIds = new Set(typedGlyphs.map((g) => g.id));
  const byChar = new Map<string, SourceGlyph[]>();
  for (const g of sources) {
    if (g.onCarriage || typedIds.has(g.id)) continue;
    let arr = byChar.get(g.char);
    if (!arr) byChar.set(g.char, (arr = []));
    arr.push(g);
  }

  // --- identity mapping of the typed line ------------------------------
  let typedCursor = 0;
  const typedSlots = slots.filter((s) => s.source === "typed");
  for (const slot of typedSlots) {
    const g = typedGlyphs[typedCursor];
    if (g && g.char === slot.char) {
      used.add(g.id);
      assignments.push({ slot, source: g, liftTime: TIMELINE.memberLiftStart + typedCursor * 0.05 + rnd() * 0.04 });
      stats.identityMapped++;
      typedCursor++;
    } else {
      // Typed line and quote diverged – harvest from the pages instead.
      const alt = harvest(slot, byChar, used, null, sources, stats);
      assignments.push({ slot, source: alt, liftTime: TIMELINE.memberLiftStart + 0.6 + rnd() * 0.5 });
    }
  }

  // --- nearest-neighbour harvesting for the remaining lines ----------------
  const pageGlyphs = sources.filter((g) => !g.onCarriage);
  const pageSlots = slots.filter((s) => s.source === "pages");
  let currentWord = -1;
  let currentLine = -1;
  let seedPoint: THREE.Vector3 | null = null;
  let wordLift = 0;
  for (const slot of pageSlots) {
    if (slot.word !== currentWord || slot.line !== currentLine) {
      currentWord = slot.word;
      currentLine = slot.line;
      seedPoint = pageGlyphs[Math.floor(rnd() * pageGlyphs.length)].position;
      // Words lift as groups, in reading order, well before they are due.
      wordLift = TIMELINE.chaffLiftStart + 0.1 + (slot.line * 6 + slot.word) * 0.22 + rnd() * 0.25;
    }
    const g = harvest(slot, byChar, used, seedPoint, sources, stats);
    assignments.push({ slot, source: g, liftTime: wordLift + slot.charInWord * 0.06 });
  }

  return assignments;
}

/** Pick the closest unused glyph with the right character (case-insensitive fallback, clone as last resort). */
function harvest(
  slot: TargetSlot,
  byChar: Map<string, SourceGlyph[]>,
  used: Set<number>,
  seedPoint: THREE.Vector3 | null,
  sources: SourceGlyph[],
  stats: MappingStats,
): SourceGlyph {
  const tryChars = [slot.char, slot.char.toLowerCase(), slot.char.toUpperCase()];
  for (const ch of tryChars) {
    const pool = byChar.get(ch);
    if (!pool) continue;
    let best: SourceGlyph | null = null;
    let bestD = Infinity;
    for (const g of pool) {
      if (used.has(g.id)) continue;
      const d = seedPoint ? g.position.distanceToSquared(seedPoint) : 0;
      if (d < bestD) {
        bestD = d;
        best = g;
        if (!seedPoint) break;
      }
    }
    if (best) {
      used.add(best.id);
      stats.searchMapped++;
      return best;
    }
  }
  // Last resort: a duplicate strike at the nearest glyph's location. It still
  // originates from the paper – it is simply printed on top of its neighbour.
  let nearest = sources[0];
  if (seedPoint) {
    let bestD = Infinity;
    for (const g of sources) {
      if (g.onCarriage) continue;
      const d = g.position.distanceToSquared(seedPoint);
      if (d < bestD) {
        bestD = d;
        nearest = g;
      }
    }
  }
  const clone: SourceGlyph = { ...nearest, id: sources.length, char: slot.char, position: nearest.position.clone(), quaternion: nearest.quaternion.clone() };
  sources.push(clone);
  used.add(clone.id);
  stats.fallbackClones++;
  return clone;
}

/* ------------------------------------------------------------------ */
/*  2. GPU buffers                                                     */
/* ------------------------------------------------------------------ */

export interface ParticleBuffers {
  count: number;
  origin: Float32Array; // vec3  rest position on the paper
  originQuat: Float32Array; // vec4  rest orientation (paper frame)
  target: Float32Array; // vec3  destination (quote slot or drift point)
  targetQuat: Float32Array; // vec4  destination orientation
  glyph: Float32Array; // vec2  atlas cell origin
  timing: Float32Array; // vec4  (appear, lift, duration, kind)
  seed: Float32Array; // vec4  per-particle random numbers
  scale: Float32Array; // vec2  (origin size, target size)
  carriage: Float32Array; // float 1 = follows the typewriter carriage
  /** Pairs of points (origin → target) for the mapping visualiser. */
  memberLinks: Float32Array;
}

/**
 * Convert the mapping into flat typed arrays ready for InstancedBufferGeometry.
 *
 * @param cameraAt samples the (deterministic) camera path – chaff targets are
 *                 placed in front of the camera at their arrival time so the
 *                 swarm streams past the viewer during the ascent.
 */
export function buildParticleBuffers(
  sources: SourceGlyph[],
  assignments: Assignment[],
  atlas: GlyphAtlas,
  cameraAt: CameraSampler,
  stats: MappingStats,
  seed = 1234,
): ParticleBuffers {
  const rnd = mulberry32(seed);
  const n = sources.length;
  const b: ParticleBuffers = {
    count: n,
    origin: new Float32Array(n * 3),
    originQuat: new Float32Array(n * 4),
    target: new Float32Array(n * 3),
    targetQuat: new Float32Array(n * 4),
    glyph: new Float32Array(n * 2),
    timing: new Float32Array(n * 4),
    seed: new Float32Array(n * 4),
    scale: new Float32Array(n * 2),
    carriage: new Float32Array(n),
    memberLinks: new Float32Array(assignments.length * 6),
  };

  const bySource = new Map<number, Assignment>();
  for (const a of assignments) bySource.set(a.source.id, a);

  const frame: CameraFrame = { position: new THREE.Vector3(), quaternion: new THREE.Quaternion() };
  const right = new THREE.Vector3();
  const up = new THREE.Vector3();
  const fwd = new THREE.Vector3();
  const tgt = new THREE.Vector3();
  const q = new THREE.Quaternion();
  const e = new THREE.Euler();
  // Lift-off wave origin: the front of the typewriter, sweeping outward over the pages.
  const waveOrigin = new THREE.Vector3(0, 0.1, -0.02);
  let linkIdx = 0;

  for (let i = 0; i < n; i++) {
    const g = sources[i];
    const a = bySource.get(g.id);

    b.origin.set([g.position.x, g.position.y, g.position.z], i * 3);
    b.originQuat.set([g.quaternion.x, g.quaternion.y, g.quaternion.z, g.quaternion.w], i * 4);
    b.glyph.set(atlas.cellOf(g.char), i * 2);
    b.seed.set([rnd(), rnd(), rnd(), rnd()], i * 4);
    b.carriage[i] = g.onCarriage ? 1 : 0;
    const appear = g.typedAt >= 0 ? g.typedAt : -1;

    if (a) {
      // ---- member: paper → quote slot --------------------------------
      const s = a.slot;
      const duration = Math.max(2.5, s.arrival - a.liftTime);
      b.target.set([s.position.x, s.position.y, s.position.z], i * 3);
      b.targetQuat.set([s.quaternion.x, s.quaternion.y, s.quaternion.z, s.quaternion.w], i * 4);
      b.timing.set([appear, a.liftTime, duration, KIND_MEMBER], i * 4);
      b.scale.set([g.size, s.size], i * 2);
      b.memberLinks.set([g.position.x, g.position.y, g.position.z, s.position.x, s.position.y, s.position.z], linkIdx * 6);
      linkIdx++;
      stats.members++;
      continue;
    }

    // ---- chaff or stay ----------------------------------------------------
    const liftChance = g.onCarriage ? 0.72 : 0.58;
    if (rnd() > liftChance) {
      b.target.set([g.position.x, g.position.y, g.position.z], i * 3);
      b.targetQuat.set([g.quaternion.x, g.quaternion.y, g.quaternion.z, g.quaternion.w], i * 4);
      b.timing.set([appear, 1e9, 1, KIND_STAY], i * 4);
      b.scale.set([g.size, g.size], i * 2);
      stats.stays++;
      continue;
    }

    const dist = g.position.distanceTo(waveOrigin);
    const lineNoise = (Math.sin(g.line * 12.9898 + g.surfaceId * 78.233) * 0.5 + 0.5) * 0.45;
    const lift = TIMELINE.chaffLiftStart + Math.min(1, dist / 0.55) * TIMELINE.chaffLiftSpread + rnd() * 0.5 + lineNoise;
    const duration = 3.6 + rnd() * 4.2;

    // Drift destination: somewhere in front of the camera when the glyph gets there.
    cameraAt(lift + duration, frame);
    right.set(1, 0, 0).applyQuaternion(frame.quaternion);
    up.set(0, 1, 0).applyQuaternion(frame.quaternion);
    fwd.set(0, 0, -1).applyQuaternion(frame.quaternion);
    const fz = 2.5 + rnd() * 12;
    tgt
      .copy(frame.position)
      .addScaledVector(fwd, fz)
      .addScaledVector(right, (rnd() - 0.5) * 1.6 * fz)
      .addScaledVector(up, (rnd() - 0.5) * 1.0 * fz);
    q.setFromEuler(e.set(rnd() * Math.PI * 2, rnd() * Math.PI * 2, rnd() * Math.PI * 2));

    b.target.set([tgt.x, tgt.y, tgt.z], i * 3);
    b.targetQuat.set([q.x, q.y, q.z, q.w], i * 4);
    b.timing.set([appear, lift, duration, KIND_CHAFF], i * 4);
    b.scale.set([g.size, 0.08 + rnd() * 0.26], i * 2);
    stats.chaff++;
  }
  b.memberLinks = b.memberLinks.subarray(0, linkIdx * 6);
  stats.sources = n;
  return b;
}

export function emptyStats(): MappingStats {
  return { sources: 0, members: 0, chaff: 0, stays: 0, identityMapped: 0, searchMapped: 0, fallbackClones: 0 };
}
