const puppeteer = require("/tmp/node_modules/puppeteer");
const http = require("http"); const fs = require("fs"); const path = require("path");
const dist = path.join(__dirname, "..", "dist");
const server = http.createServer((req, res) => { const f = path.join(dist, req.url === "/" ? "index.html" : req.url); if (fs.existsSync(f) && fs.statSync(f).isFile()) { res.writeHead(200, {"Content-Type": "text/html"}); fs.createReadStream(f).pipe(res);} else { res.writeHead(404); res.end(); } });
(async () => {
  await new Promise((r) => server.listen(5058, r));
  const browser = await puppeteer.launch({ headless: true, args: ["--no-sandbox", "--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"] });
  const page = await browser.newPage(); await page.setViewport({ width: 1280, height: 720 });
  await page.goto("http://localhost:5058/", { waitUntil: "load" });
  await page.waitForFunction(() => window.__gatsby && window.__gatsby.particles, { timeout: 90000 });
  const variants = ["none", "sheet", "platen", "both"];
  for (const v of variants) {
    const r = await page.evaluate((v) => {
      const s = window.__gatsby; s.playing = false;
      const car = s.typewriter.carriage;
      const sheet = car.children.find(c => c.geometry && c.geometry.type === "BufferGeometry");
      const platen = car.children.find(c => c.geometry && c.geometry.type === "CylinderGeometry" && c.geometry.parameters.height === 0.34);
      sheet.visible = !(v === "sheet" || v === "both");
      platen.visible = !(v === "platen" || v === "both");
      s.setTime(3);
      return { sheet: !!sheet, platen: !!platen, sheetBox: (() => { sheet.geometry.computeBoundingBox(); return sheet.geometry.boundingBox.min.toArray().concat(sheet.geometry.boundingBox.max.toArray()).map(n=>n.toFixed(3)); })() };
    }, v);
    await new Promise((r) => setTimeout(r, 500));
    await page.screenshot({ path: `/tmp/shots/iso_${v}.png`, clip: { x: 300, y: 250, width: 600, height: 250 } });
    if (v === "none") console.log(JSON.stringify(r));
  }
  await browser.close(); server.close();
})().catch((e) => { console.error(e); process.exit(1); });
