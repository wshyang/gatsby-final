/* Headless screenshot helper (dev only): node scripts/shot.cjs [distDir] [times] [outDir] */
const puppeteer = require("/tmp/node_modules/puppeteer");
const http = require("http");
const fs = require("fs");
const path = require("path");

const dist = process.argv[2] || path.join(__dirname, "..", "dist");
const times = (process.argv[3] || "0.5,3,6.5,8,10,12,14.5,17,20,23").split(",").map(Number);
const outDir = process.argv[4] || "/tmp/shots";
fs.mkdirSync(outDir, { recursive: true });

const server = http.createServer((req, res) => {
  const file = path.join(dist, req.url === "/" ? "index.html" : req.url);
  if (fs.existsSync(file) && fs.statSync(file).isFile()) {
    res.writeHead(200, { "Content-Type": file.endsWith(".html") ? "text/html" : "application/octet-stream" });
    fs.createReadStream(file).pipe(res);
  } else {
    res.writeHead(404);
    res.end();
  }
});

(async () => {
  await new Promise((r) => server.listen(5055, r));
  const browser = await puppeteer.launch({
    headless: true,
    args: ["--no-sandbox", "--disable-setuid-sandbox", "--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist", "--window-size=1280,720"],
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 720, deviceScaleFactor: 1 });
  const logs = [];
  page.on("console", (m) => logs.push(`[${m.type()}] ${m.text()}`));
  page.on("pageerror", (e) => logs.push(`[pageerror] ${e.message}`));
  const t0 = Date.now();
  await page.goto("http://localhost:5055/", { waitUntil: "load", timeout: 60000 });
  try {
    await page.waitForFunction(() => window.__gatsby && window.__gatsby.particles, { timeout: 90000 });
  } catch (e) {
    logs.push("[timeout] scene not ready");
  }
  console.log("ready in", Date.now() - t0, "ms");
  for (const t of times) {
    await page.evaluate((t) => {
      const s = window.__gatsby;
      s.playing = false;
      s.setTime(t);
    }, t);
    await new Promise((r) => setTimeout(r, 500));
    const file = path.join(outDir, `t${t.toFixed(1).replace(".", "_")}.png`);
    await page.screenshot({ path: file });
    console.log("saved", file);
  }
  console.log(logs.slice(0, 40).join("\n"));
  await browser.close();
  server.close();
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
