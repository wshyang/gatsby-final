const puppeteer = require("/tmp/node_modules/puppeteer");
const http = require("http"); const fs = require("fs"); const path = require("path");
const dist = path.join(__dirname, "..", "dist");
const server = http.createServer((req, res) => { const f = path.join(dist, req.url === "/" ? "index.html" : req.url); if (fs.existsSync(f) && fs.statSync(f).isFile()) { res.writeHead(200, {"Content-Type": "text/html"}); fs.createReadStream(f).pipe(res);} else { res.writeHead(404); res.end(); } });
(async () => {
  await new Promise((r) => server.listen(5057, r));
  const browser = await puppeteer.launch({ headless: true, args: ["--no-sandbox", "--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"] });
  const page = await browser.newPage(); await page.setViewport({ width: 1280, height: 720 });
  await page.goto("http://localhost:5057/", { waitUntil: "load" });
  await page.waitForFunction(() => window.__gatsby && window.__gatsby.particles, { timeout: 90000 });
  const info = await page.evaluate(() => {
    const s = window.__gatsby; s.playing = false; s.setTime(3);
    const geo = s.particles.geometry;
    const timing = geo.getAttribute("aTiming").array, origin = geo.getAttribute("aOrigin").array, car = geo.getAttribute("aCarriage").array, oq = geo.getAttribute("aOriginQuat").array;
    const cx = s.particles.material.uniforms.uCarriageX.value;
    const out = [];
    for (let i = 0; i < geo.instanceCount; i++) {
      if (timing[i*4] >= 0 && timing[i*4] < 3) {
        const v = { x: origin[i*3] + cx * car[i], y: origin[i*3+1], z: origin[i*3+2] };
        const p = new (s.camera.position.constructor)(v.x, v.y, v.z).project(s.camera);
        out.push({ i, appear: timing[i*4].toFixed(2), kind: timing[i*4+3], car: car[i], world: [v.x.toFixed(4), v.y.toFixed(4), v.z.toFixed(4)], px: [((p.x+1)/2*1280).toFixed(0), ((1-p.y)/2*720).toFixed(0), p.z.toFixed(4)], quat: Array.from(oq.slice(i*4, i*4+4)).map(n=>n.toFixed(3)) });
      }
    }
    return { carriageX: cx, typedVisibleCount: out.length, first: out.slice(0, 3), last: out.slice(-2), camPos: s.camera.position.toArray().map(n=>n.toFixed(3)) };
  });
  console.log(JSON.stringify(info, null, 1));
  await browser.close(); server.close();
})().catch((e) => { console.error(e); process.exit(1); });
