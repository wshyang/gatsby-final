/* Dev-only runtime probe: node scripts/probe.cjs */
const puppeteer = require("/tmp/node_modules/puppeteer");
const http = require("http");
const fs = require("fs");
const path = require("path");
const dist = path.join(__dirname, "..", "dist");
const server = http.createServer((req, res) => {
  const file = path.join(dist, req.url === "/" ? "index.html" : req.url);
  if (fs.existsSync(file) && fs.statSync(file).isFile()) {
    res.writeHead(200, { "Content-Type": "text/html" });
    fs.createReadStream(file).pipe(res);
  } else {
    res.writeHead(404);
    res.end();
  }
});
(async () => {
  await new Promise((r) => server.listen(5056, r));
  const browser = await puppeteer.launch({ headless: true, args: ["--no-sandbox", "--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"] });
  const page = await browser.newPage();
  await page.setViewport({ width: 960, height: 540 });
  const logs = [];
  page.on("console", (m) => logs.push(`[${m.type()}] ${m.text().slice(0, 600)}`));
  page.on("pageerror", (e) => logs.push(`[pageerror] ${e.message}`));
  await page.goto("http://localhost:5056/", { waitUntil: "load" });
  await page.waitForFunction(() => window.__gatsby && window.__gatsby.particles, { timeout: 90000 });
  await page.evaluate(() => { window.__gatsby.playing = false; window.__gatsby.setTime(3); });
  await new Promise((r) => setTimeout(r, 600));
  const info = await page.evaluate(() => {
    const s = window.__gatsby;
    const tex = s.particles.material.uniforms.uAtlas.value;
    const c = tex.image;
    const ctx = c.getContext("2d");
    const d = ctx.getImageData(0, 0, c.width, c.height).data;
    let nz = 0;
    for (let i = 3; i < d.length; i += 4) if (d[i] > 0) nz++;
    const geo = s.particles.geometry;
    const timing = geo.getAttribute("aTiming").array;
    const scale = geo.getAttribute("aScale").array;
    const origin = geo.getAttribute("aOrigin").array;
    const glyph = geo.getAttribute("aGlyph").array;
    const r = s.renderer.info.render;
    const programs = s.renderer.info.programs.map((p) => ({ name: p.name, diag: p.diagnostics ? JSON.stringify(p.diagnostics).slice(0, 300) : null }));
    return {
      atlas: { w: c.width, h: c.height, nonZeroAlpha: nz },
      cellSize: tex && s.particles.material.uniforms.uCellSize.value,
      count: geo.instanceCount,
      timing0: Array.from(timing.slice(0, 8)),
      scale0: Array.from(scale.slice(0, 4)),
      origin0: Array.from(origin.slice(0, 6)),
      glyph0: Array.from(glyph.slice(0, 6)),
      render: { calls: r.calls, triangles: r.triangles },
      programs,
      meshVisible: s.particles.mesh.visible,
      parent: !!s.particles.mesh.parent,
      camera: s.camera.position.toArray(),
    };
  });
  console.log(JSON.stringify(info, null, 1));
  console.log(logs.join("\n"));
  await browser.close();
  server.close();
})().catch((e) => { console.error(e); process.exit(1); });
